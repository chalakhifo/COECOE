INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_PLT_EXT_TBL ' as TABLENAME, (case when COUNT(*) = 4 then 'OK' else 'KO' end) REMARKS from PS_PVT_PLT_EXT_TBL WHERE REPORT_NAME IN ('G0001_FIXRIAS_ECMMNA','G0001_FIXRIAS_ABP_DCM_AMD_SSL','G4604_FIXRIAS','G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_PLT_CRIT_SG ' as TABLENAME, (case when COUNT(*) = 35 then 'OK' else 'KO' end) REMARKS from PS_PVT_PLT_CRIT_SG WHERE REPORT_NAME IN ('G0001_FIXRIAS_ECMMNA','G0001_FIXRIAS_ABP_DCM_AMD_SSL','G4604_FIXRIAS','G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_PLT_SEL_TBL ' as TABLENAME, (case when COUNT(*) = 10 then 'OK' else 'KO' end) REMARKS from PS_PVT_PLT_SEL_TBL WHERE REPORT_NAME IN ('G0001_FIXRIAS_ECMMNA','G0001_FIXRIAS_ABP_DCM_AMD_SSL','G4604_FIXRIAS','G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_RUN_EXCT_SG ' as TABLENAME, (case when COUNT(*) = 14  then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_EXCT_SG where OPRID='BATCHPM' AND RUN_CNTL_ID IN ('SG_PVT_FIXRIAS','SG_PVT_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_RUN_HDR_SG ' as TABLENAME, (case when COUNT(*) = 1 then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_HDR_SG where OPRID='BATCHPM' AND RUN_CNTL_ID IN ('SG_PVT_FIXRIAS','SG_PVT_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_RUN_FTB_SG ' as TABLENAME, (case when COUNT(*) = 14 then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_FTB_SG where OPRID='BATCHPM' AND RUN_CNTL_ID IN ('SG_PVT_FIXRIAS','SG_PVT_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_RUN_EXCT_SG ' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_EXCT_SG where OPRID='BATCHSGEU' AND RUN_CNTL_ID IN ('SG_PVT_G4604_FIXRIAS','SG_PVT_G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_RUN_HDR_SG ' as TABLENAME, (case when COUNT(*) = 1 then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_HDR_SG where OPRID='BATCHSGEU' AND RUN_CNTL_ID IN ('SG_PVT_FIXRIAS ','SG_PVT_G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PVT_RUN_FTB_SG ' as TABLENAME, (case when COUNT(*) = 1 then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_FTB_SG where OPRID='BATCHSGEU' AND RUN_CNTL_ID IN ('SG_PVT_FIXRIAS ','SG_PVT_G0026_FIXRIAS');


INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PRCSRUNCNTL ' as TABLENAME, (case when COUNT(*) = 1 then 'OK' else 'KO' end) REMARKS from PS_PRCSRUNCNTL where OPRID='BATCHPM' AND RUN_CNTL_ID IN ('SG_PVT_FIXRIAS','SG_PVT_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PSPRCSRUNCNTLS ' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'KO' end) REMARKS from PSPRCSRUNCNTLS where OPRID='BATCHPM' AND RUNCNTLID IN ('SG_PVT_FIXRIAS','SG_PVT_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PRCSRUNCNTLDTL ' as TABLENAME, (case when COUNT(*) =1  then 'OK' else 'KO' end) REMARKS from PS_PRCSRUNCNTLDTL where OPRID='BATCHPM' AND RUNCNTLID IN ('SG_PVT_FIXRIAS','SG_PVT_FIXRIAS');


INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PRCSRUNCNTL ' as TABLENAME, (case when COUNT(*) = 2 then 'OK' else 'KO' end) REMARKS from PS_PRCSRUNCNTL where OPRID='BATCHSGEU' AND RUN_CNTL_ID IN ('SG_PVT_G4604_FIXRIAS','SG_PVT_G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PSPRCSRUNCNTLS ' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'KO' end) REMARKS from PSPRCSRUNCNTLS where OPRID='BATCHSGEU' AND RUNCNTLID IN ('SG_PVT_G4604_FIXRIAS','SG_PVT_G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_PRCSRUNCNTLDTL ' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'KO' end) REMARKS from PS_PRCSRUNCNTLDTL where OPRID='BATCHSGEU' AND RUNCNTLID IN ('SG_PVT_G4604_FIXRIAS','SG_PVT_G0026_FIXRIAS');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-144' as CO_Num, systimestamp, 'A', 'Create 4 FIXRIAS Pivot' as DESCR,'PS_UPROC_SG ' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'KO' end) REMARKS FROM PS_UPROC_SG WHERE RUN_CNTL_ID IN ('SG_PVT_G4604_FIXRIAS','SG_PVT_G0026_FIXRIAS') AND UNITE_GESTION_SG='T_COESGEU2';









