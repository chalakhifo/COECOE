INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A',  'GLTES-132' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQLTEXTDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLTEXTDEFN_SG  where SQLID like 'CHK83 - Running batch streams%';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A',  'GLTES-132' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQLCOLDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLCOLDEFN_SG  where SQLID like 'CHK83 - Running batch streams%';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A',  'GLTES-132' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQL_RUN_LINE_SG' as Tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQL_RUN_LINE_SG   where  OPRID = 'BATCHAA' and RUN_CNTL_ID = 'SG_QRY_CHK_07H30' AND SQLID like '%Running batch streams'; 

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A',  'GLTES-132' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQLTEXTDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLTEXTDEFN_SG  where SQLID like '%83- Balances on H7003 PTF%';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A',  'GLTES-132' as CO_Num, systimestamp, 'A','CHK83 - Running Batch Streams' as Descr , 'PS_SQLCOLDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLCOLDEFN_SG  where SQLID like '%83- Balances on H7003 PTF%';

-----------------------------------------------------------------------------------------------;
-- PS_FTP_FOLDER_SG :;
-----------------------------------------------------------------------------------------------;
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_FTP_FOLDER_SG'as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_FTP_FOLDER_SG  WHERE FTP_FOLDER_SG = 'MU2';

-----------------------------------------------------------------------------------------------;
-- PS_PVT_RUN_FTB_SG  :;
-----------------------------------------------------------------------------------------------;
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_DAILY' AND REPORT_NAME = 'G9276_CDR_BAL_DAILY_ACTLOCAL' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_DAILY' AND REPORT_NAME = 'G9276_CDR_BAL_DAILY_ACTUALS' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_DAILY' AND REPORT_NAME = 'G9276_CDR_BAL_DAILY_REPLOC' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_DAILY' AND REPORT_NAME = 'I9276_CDR_BAL_DAILY_INDIV' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_MONTHLY' AND REPORT_NAME = 'G9276_CDR_BAL_MONTHLY_ACTLOCAL' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_MONTHLY' AND REPORT_NAME = 'G9276_CDR_BAL_MONTHLY_ACTUALS' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_MONTHLY' AND REPORT_NAME = 'G9276_CDR_BAL_MONTHLY_REPLOC' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_BAL_MONTHLY' AND REPORT_NAME = 'I9276_CDR_BAL_MONTHLY_INDIV' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_ENTRIES' AND REPORT_NAME = 'G9276_CDR_ENTRIES_ACTLOCAL' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_ENTRIES' AND REPORT_NAME = 'G9276_CDR_ENTRIES_ACTUALS' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_ENTRIES' AND REPORT_NAME = 'G9276_CDR_ENTRIES_REPLOC' AND FTP_FOLDER_SG = 'MU2';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
Select '201603A', 'GLTES-141' as CO_Num, systimestamp, 'A', '[Mumbai] Add a new target FTR on the pivots dedicated to CDR' as Descr, 'PS_PVT_RUN_FTB_SG' as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PS_PVT_RUN_FTB_SG  WHERE OPRID = 'BATCHG9276' AND RUN_CNTL_ID = 'PVT_G9276_CDR_ENTRIES' AND REPORT_NAME = 'I9276_CDR_ENTRIES_INDIV' AND FTP_FOLDER_SG = 'MU2';


COMMIT;
/