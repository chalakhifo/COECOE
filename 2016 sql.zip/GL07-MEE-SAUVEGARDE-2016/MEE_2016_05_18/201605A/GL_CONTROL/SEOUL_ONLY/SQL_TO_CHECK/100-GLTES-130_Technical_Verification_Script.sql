INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-130' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQLTEXTDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_SQLTEXTDEFN_SG  where SQLID like 'CHK83 - Running batch streams%';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-130' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQLCOLDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLCOLDEFN_SG  where SQLID like 'CHK83 - Running batch streams%';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-130' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQL_RUN_LINE_SG' as Tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQL_RUN_LINE_SG   where  OPRID = 'BATCHAA' and RUN_CNTL_ID = 'SG_QRY_CHK_07H30' AND SQLID like '%Running batch streams'; 

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-130' as CO_Num, systimestamp, 'A', 'CHK83 - Running Batch Streams' as Descr , 'PS_SQLTEXTDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLTEXTDEFN_SG  where SQLID like '%83- Balances on H7003 PTF%';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-130' as CO_Num, systimestamp, 'A','CHK83 - Running Batch Streams' as Descr , 'PS_SQLCOLDEFN_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' 
END) Remarks FROM PS_SQLCOLDEFN_SG  where SQLID like '%83- Balances on H7003 PTF%';