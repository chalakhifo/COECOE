-- NOM DU SCRIPT        : 900-PostDelivery.sql
-- CREATED BY             : Mahmoud HEBBACHE
-- APPLICATION          : COE - GL
-- VALIDATED BY           : 

-- 1 : CHECKING INVALID OBJECTS
--############################################################################################################################--
-- CREATION DU FICHIER LOG 
-- SORTIE SI ERREUR

WHENEVER SQLERROR EXIT -1 ROLLBACK;
DECLARE
    l_step integer := 1;
BEGIN	
   PKG_POST_LIVRAISON_V3.PROC_CHK_COMP_INVALID_OBJECTS();
   l_step := 2;
   PKG_POST_LIVRAISON_V3.PROC_GRANT_PRIVILEGES();
   l_step := 3;
   PKG_POST_LIVRAISON_V3.PROC_CREATE_PUBLIC_SYNONYMS();   

   INSERT INTO PS_SCRIPT_SG(CASE_ID, RUNDTTM, FILENAME_SG, DESCR100, VERSION_CHAR, DMS_OPRID_SG, APPROVAL_OPRID)
   values (20160401, systimestamp, '900-PostDelivery.sql', '201604A - 900-PostDelivery.sql - Step '||l_step, 'V1.0', 'Mahmoud.HEBBACHE', 'Mahmoud.HEBBACHE');
   
END;
/  

