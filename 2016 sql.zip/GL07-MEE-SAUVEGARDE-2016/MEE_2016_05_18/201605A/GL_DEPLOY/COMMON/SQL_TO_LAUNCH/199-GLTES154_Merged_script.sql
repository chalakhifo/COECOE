WHENEVER SQLERROR CONTINUE;
Drop table PS_JRNL_DATES_DTM;
Drop table PS_JRNL_SCAN_DTM;
Drop table PS_RUN2_IT014_SG;
Drop table PS_RUN_IT014_SG;
DROP INDEX PS_PROJ_BDR_SG;
ALTER TABLE PS_AR4_DLY_GRA_SG MODIFY(PROCESS_INSTANCE NUMBER(10));

WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
CREATE OR REPLACE VIEW PS_DMS_BU_LD_VW_SG
(BUSINESS_UNIT, LEDGER, LEDGER_GROUP, OPENITEM_RECON_NBR)
AS 
SELECT lgt.business_unit , lgl.ledger , lgl.ledger_group , 'N' FROM PS_LED_GRP_LED_TBL lgl , PS_BU_LED_GRP_TBL lgt WHERE lgl.ledger_group = lgt.ledger_group UNION SELECT DISTINCT BUSINESS_UNIT , ledger , ' ' , 'N' FROM PS_BU_LED_GRP_TBL WHERE ledger <> ' '
/
CREATE OR REPLACE VIEW PS_DMS_DFLT_BU_VW
(DMS_TEMPLATE_SG, DOMAIN)
AS 
SELECT DISTINCT dms_template_sg , DOMAIN FROM PS_DMS_REC_BU_SG
/
CREATE OR REPLACE VIEW PS_DMS_FINBU_VW_SG
(BUSINESS_UNIT, ACCOUNT_SETID, ALTACCT_SETID, PRODUCT_SETID, OPER_UNIT_SETID, 
 OBJECT_SETID, DEPT_SETID, SETID_DEPR_ALLOC, SETID_CUR, RT_TYPE)
AS 
SELECT bugl.business_unit , scr1.setid AS setid_account , scr2.setid AS setid_altacct , scr3.setid AS setid_product , scr4.setid AS setid_oper /*, decode(scr4.setid , 'SHARE' , 'GOP' , 'PTF') AS dpt_level*/ , scr5.setid AS setid_objcode , scr6.setid AS setid_deptid , scr7.setid AS setid_alloc , scr8.setid AS setid_reeval , NVL(( SELECT ids.std_id_num FROM PS_BUS_UNIT_IDS_GL ids WHERE ids.std_id_num_qual = 'RTT' AND ids.business_unit = bugl.business_unit), ' ') AS rt_type FROM PS_BUS_UNIT_TBL_GL bugl , PS_SET_CNTRL_REC scr1 , PS_SET_CNTRL_REC scr2 , PS_SET_CNTRL_REC scr3 , PS_SET_CNTRL_REC scr4 , PS_SET_CNTRL_REC scr5 , PS_SET_CNTRL_REC scr6 , PS_SET_CNTRL_REC scr7, PS_SET_CNTRL_REC scr8 WHERE scr1.recname = 'GL_ACCOUNT_TBL' AND scr1.setcntrlvalue = bugl.business_unit AND scr2.recname = 'ALTACCT_TBL' AND scr2.setcntrlvalue = bugl.business_unit AND scr3.recname = 'PRODUCT_TBL' AND scr3.setcntrlvalue = bugl.business_unit AND scr4.recname = 'OPER_UNIT_TBL' AND scr4.setcntrlvalue = bugl.business_unit AND scr5.recname = 'CHARTFIELD1_TBL' AND scr5.setcntrlvalue = bugl.business_unit AND scr6.recname = 'DEPT_TBL' AND scr6.setcntrlvalue = bugl.business_unit AND scr7.recname = 'ALLOC_GROUP_TBL' AND scr7.setcntrlvalue = bugl.business_unit AND scr8.recname = 'CURR_GROUP_TBL' AND scr8.setcntrlvalue = bugl.business_unit
/
CREATE OR REPLACE VIEW PS_DMS_INDIV_VW_SG
(BUSINESS_UNIT, DESCR)
AS 
SELECT DISTINCT bugrp.indiv_bu_sg , fs.descr FROM PS_ME_RF_BU_GRP_SG bugrp , PS_BUS_UNIT_TBL_FS fs WHERE bugrp.indiv_bu_sg = fs.business_unit AND ( SYSDATE BETWEEN dt_deb_efft_sg AND dt_fin_efft_sg OR (dt_deb_efft_sg <= SYSDATE AND dt_fin_efft_sg IS NULL) )
/
CREATE OR REPLACE VIEW PS_DMS_REC_VW_SG
(DMS_TEMPLATE_SG, DOMAIN, RECNAME, PRIORITY, ACTIVE_STATUS, 
 DMS_CALC_TYPE_SG, SQL_SELECT_001, RECNAME1, FIELDNAME1, FIELDNAME2, 
 APP_CLASS_METHOD, DMS_WHERE_SG)
AS 
SELECT REC.DMS_TEMPLATE_SG , REC.DOMAIN , REC.RECNAME , (DOM.PRIORITY * 25) + REC.PRIORITY , REC.ACTIVE_STATUS , REC.DMS_CALC_TYPE_SG , REC.SQL_SELECT_001 , REC.RECNAME1 , REC.FIELDNAME1 , REC.FIELDNAME2 , REC.APP_CLASS_METHOD , REC.DMS_WHERE_SG FROM PS_DMS_REC_BU_SG REC , PS_DMS_DOM_BU_SG DOM WHERE REC.DMS_TEMPLATE_SG = DOM.DMS_TEMPLATE_SG AND REC.DOMAIN = DOM.DOMAIN
/
CREATE OR REPLACE VIEW PS_DMS_DOM_VW_SG
(DMS_TEMPLATE_SG, DOMAIN, DESCR, PRIORITY, DMS_DOM_TYPE_SG)
AS 
SELECT dms_template_sg , DOMAIN , descr , priority , dms_dom_type_sg FROM PS_DMS_DOM_BU_SG dom WHERE dom.active_status = 'A' AND EXISTS ( SELECT 1 FROM PS_DMS_REC_BU_SG rbs WHERE rbs.dms_template_sg = dom.dms_template_sg AND rbs.domain = dom.domain AND rbs.active_status = 'A')
/
CREATE OR REPLACE VIEW PS_DMS_FINBU_VW_SG
(BUSINESS_UNIT, ACCOUNT_SETID, ALTACCT_SETID, PRODUCT_SETID, OPER_UNIT_SETID, 
 OBJECT_SETID, DEPT_SETID, SETID_DEPR_ALLOC, SETID_CUR, RT_TYPE)
AS 
SELECT bugl.business_unit , scr1.setid AS setid_account , scr2.setid AS setid_altacct , scr3.setid AS setid_product , scr4.setid AS setid_oper , 
       scr5.setid AS setid_objcode , scr6.setid AS setid_deptid , scr7.setid AS setid_alloc , 
       scr8.setid AS setid_reeval , NVL(( SELECT ids.std_id_num 
FROM PS_BUS_UNIT_IDS_GL ids WHERE ids.std_id_num_qual = 'RTT' AND ids.business_unit = bugl.business_unit), ' ') AS rt_type FROM PS_BUS_UNIT_TBL_GL bugl , 
      PS_SET_CNTRL_REC scr1 , PS_SET_CNTRL_REC scr2 , PS_SET_CNTRL_REC scr3 , PS_SET_CNTRL_REC scr4 , PS_SET_CNTRL_REC scr5 , PS_SET_CNTRL_REC scr6 , 
      PS_SET_CNTRL_REC scr7, PS_SET_CNTRL_REC scr8 
WHERE scr1.recname = 'GL_ACCOUNT_TBL' AND scr1.setcntrlvalue = bugl.business_unit AND scr2.recname = 'ALTACCT_TBL' 
AND scr2.setcntrlvalue = bugl.business_unit AND scr3.recname = 'PRODUCT_TBL' AND scr3.setcntrlvalue = bugl.business_unit 
AND scr4.recname = 'OPER_UNIT_TBL' AND scr4.setcntrlvalue = bugl.business_unit AND scr5.recname = 'CHARTFIELD1_TBL' 
AND scr5.setcntrlvalue = bugl.business_unit AND scr6.recname = 'DEPT_TBL' AND scr6.setcntrlvalue = bugl.business_unit 
AND scr7.recname = 'ALLOC_GROUP_TBL' AND scr7.setcntrlvalue = bugl.business_unit AND scr8.recname = 'CURR_GROUP_TBL' 
AND scr8.setcntrlvalue = bugl.business_unit
/

INSERT INTO PS_SCRIPT_SG (CASE_ID, RUNDTTM, FILENAME_SG, DESCR100, VERSION_CHAR, DMS_OPRID_SG, APPROVAL_OPRID) 
VALUES (154, systimestamp, 'GLTES-154_Merged_script.sql', 'GLTES-154 - PreUpgrade Package', 'V1.0', 'Mahmoud.Hebbache', 'Mahmoud.Hebbache');
COMMIT;
/





