REM script select_mig_solde_BU_jnrl_status.sql
REM
REM Parametres en entree (3 parametres) :
REM     P1: Le proprietaire du schema (exp TUCSG00)
REM     P2: Un RUN-CONTROL_ID (exp SG_GLS9002)
REM     P3: Le nom d'un Operateur PS
REM     P4: date de traitement
REM     P5: Nombre de Parametres
REM     P6: fichier de spool
REM     P7: AXE en cours de migration
REM     P8: Type de journaux (SUSPENS/SOLDES)
REM

whenever sqlerror exit 13;
whenever oserror exit 13;

DEFINE NB_PARAM_SET = 8
select TEST_NB_PARAM (&5, &NB_PARAM_SET) from dual;

set heading off;
set trims on;
set newpage none;
set serverout off;
set termout off;
set verify off;
set feed on;
spool &6;

SELECT DISTINCT 'RESULTAT:'||BUSINESS_UNIT 
FROM &1..PS_JRNL_HEADER 
WHERE 
    JOURNAL_ID BETWEEN 
                        (SELECT JOURNAL_ID_FROM 
                         FROM &1..PS_MIG_HIST_SG 
                         WHERE 
                             FIELD_MIG_SG= '&7' 
                         AND MIG_TYPE_SG= '&8' 
                         AND MIG_PRCS_ID_SG = (SELECT MAX(MIG_PRCS_ID_SG) 
                                               FROM &1..PS_MIG_HIST_SG 
                                               WHERE 
                                                    FIELD_MIG_SG= '&7' 
                                               AND MIG_TYPE_SG= '&8'
                        )                     )
                    AND 
                        (SELECT JOURNAL_ID_TO 
                         FROM &1..PS_MIG_HIST_SG 
                         WHERE 
                             FIELD_MIG_SG= '&7' 
                         AND MIG_TYPE_SG= '&8' 
                         AND MIG_PRCS_ID_SG = (SELECT MAX(MIG_PRCS_ID_SG) 
                                               FROM &1..PS_MIG_HIST_SG 
                                               WHERE 
                                                   FIELD_MIG_SG= '&7' 
                                               AND MIG_TYPE_SG= '&8'
                        )                     )
AND JRNL_HDR_STATUS NOT IN ('P','U') 
AND SOURCE='MIG'
;

SPOOL OFF;

EXIT;
