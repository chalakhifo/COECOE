select 'GL-TES120' as JIRA_ID,'CD - Create new table for sql check' as DESCR,'ALL_TABLES' as  VIEWNAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS from ALL_TABLES where TABLE_NAME = 'PS_MEE_CHECK_SG';

select  'GL-TES120' as JIRA_ID,'CD - Create new table for sql check' as DESCR,'DBA_OBJECTS' as  VIEWNAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS from    DBA_OBJECTS where   OBJECT_TYPE = 'VIEW' AND OBJECT_NAME = 'PS_MEE_CHECK_VW_SG';

SELECT  'GL-TES120' as JIRA_ID,'CD - Create new table for sql check' as DESCR,'DBA_OBJECTS' as  VIEWNAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS from  DBA_OBJECTS where   OBJECT_TYPE = 'TRIGGER' AND OBJECT_NAME = 'MEE_CHECK_SG';

Select 'GL-TES120' as JIRA_ID,'CD - Create new table for sql check' as DESCR,'PSPROJECTDEFN' as  VIEWNAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS from PSPROJECTDEFN  where projectname ='SG_LOT1049';
        
select 'GL-TES120' as JIRA_ID,'CD - Create new table for sql check' as DESCR,'PSRECFIELD' as  VIEWNAME, (case when COUNT(*) = 7  then 'OK' else 'PROBLEM' end)    REMARKS from PSRECFIELD where RECNAME in ('MEE_CHECK_SG') and FIELDNAME in ('CONTEXT_SG','CO_NUM_SG','DESCR_CONTROL','EXEC_TIME','RELEASE_ID_SG','RESULTS','STATUS') order by FIELDNUM;
