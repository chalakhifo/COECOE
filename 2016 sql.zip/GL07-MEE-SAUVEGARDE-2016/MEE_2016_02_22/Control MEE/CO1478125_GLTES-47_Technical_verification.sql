SELECT 'GLTES-47' as JIRA_NUM,'[Dodd-Frank] PS_JL_FLDS_LOG_SG  Definition Update' as DESCR,'PS_JL_FLDS_LOG_SG' as 
RECORDNAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS  FROM PSPROJECTDEFN WHERE PROJECTNAME='SG_LOT1048';  

SELECT 'GLTES-47' as JIRA_NUM,'[Dodd-Frank] CHECK NEW FIELDS PRESENCE ' as DESCR,'POST_UTC_DTTM_SG AND UNPOST_UTC_DTTM_SG' as 
COLUMNNAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end)    REMARKS  FROM dba_tab_columns where upper(table_name) = 'PS_JL_FLDS_LOG_SG' and upper(COLUMN_NAME) in (upper('POST_UTC_DTTM_SG') ,upper('UNPOST_UTC_DTTM_SG') );  


SELECT 'GLTES-47' as JIRA_NUM,'[Dodd-Frank] CHECK TRIGGER CHANGES' as DESCR,'FEED_JRNLLN_CUSTOM_FIELDS_SG AND UNPOST_UTC_DTTM_SG' as 
TRIGGER_NAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS  FROM all_objects where upper(object_name) = upper('FEED_JRNLLN_CUSTOM_FIELDS_SG') and trunc(last_ddl_time) >= trunc(sysdate) - 7;  

