-- Nom du script        : GL_01430_102_4_2016CO1494620_MEE_CHECK_SG_create.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01430_102_4_2016CO1494620_MEE_CHECK_SG_create-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T
WHENEVER SQLERROR CONTINUE;

DROP TABLE PS_MEE_CHECK_SG;

-- ********** BUILD **********
whenever SQLERROR EXIT FAILURE rollback;

  create table PS_MEE_CHECK_SG
   (	RELEASE_ID_SG VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	CO_NUM_SG VARCHAR2(15 BYTE) NOT NULL ENABLE, 
	EXEC_TIME TIMESTAMP (6) NOT NULL ENABLE, 
	STATUS VARCHAR2(1 BYTE) NOT NULL ENABLE, 
	DESCR_CONTROL VARCHAR2(150 BYTE) NOT NULL ENABLE, 
	CONTEXT_SG VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	RESULTS VARCHAR2(15 BYTE) NOT NULL ENABLE
   ) 
  TABLESPACE GLAPP ;

  CREATE UNIQUE INDEX PS_MEE_CHECK_SG ON PS_MEE_CHECK_SG (RELEASE_ID_SG, CO_NUM_SG, EXEC_TIME)  
  TABLESPACE PSINDEX 
  PARALLEL ;

  CREATE OR REPLACE TRIGGER MEE_CHECK_SG BEFORE
  INSERT OR
  update of RELEASE_ID_SG on PS_MEE_CHECK_SG referencing new as new old as old for each row declare begin
  UPDATE PS_MEE_CHECK_SG A
  set a.STATUS       = 'I'
  WHERE A.RELEASE_ID_SG = :NEW.RELEASE_ID_SG
  AND A.CO_NUM_SG     = :NEW.CO_NUM_SG;
END;
/
ALTER TRIGGER MEE_CHECK_SG ENABLE;
/


-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
