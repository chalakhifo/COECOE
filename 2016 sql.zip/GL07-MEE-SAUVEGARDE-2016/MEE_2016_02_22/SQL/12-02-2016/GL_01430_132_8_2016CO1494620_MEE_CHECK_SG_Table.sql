-- Nom du script        : GL_01430_132_8_2016CO1494620_MEE_CHECK_SG_Table.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01430_132_8_2016CO1494620_MEE_CHECK_SG_Table-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T
WHENEVER SQLERROR CONTINUE;

DROP TABLE PS_MEE_CHECK_SG;

-- ********** BUILD **********
whenever SQLERROR EXIT FAILURE rollback;

CREATE TABLE PS_MEE_CHECK_SG 
   (	RELEASE_ID_SG VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	CO_NUM_SG VARCHAR2(15 BYTE) NOT NULL ENABLE, 
	EXEC_TIME TIMESTAMP (6) NOT NULL ENABLE, 
	STATUS VARCHAR2(1 BYTE) NOT NULL ENABLE, 
	DESCR_CONTROL VARCHAR2(150 BYTE) NOT NULL ENABLE, 
	CONTEXT_SG VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	RESULTS VARCHAR2(15 BYTE) NOT NULL ENABLE
   )
  TABLESPACE GLAPP ;

  CREATE UNIQUE INDEX PS_MEE_CHECK_SG ON PS_MEE_CHECK_SG (RELEASE_ID_SG, CO_NUM_SG, EXEC_TIME) 
  TABLESPACE PSINDEX
  PARALLEL ;

CREATE OR REPLACE TRIGGER MEE_CHECK_SG 
BEFORE INSERT ON PS_MEE_CHECK_SG 
REFERENCING NEW AS NEW OLD AS OLD 
FOR EACH ROW 
DECLARE 
V_COUNT VARCHAR2(3);
V_RELEASE_ID_SG PS_MEE_CHECK_SG.RELEASE_ID_SG%TYPE;
v_CO_NUM_SG PS_MEE_CHECK_SG.CO_NUM_SG%TYPE;
pragma autonomous_transaction;
BEGIN
      SELECT COUNT(*)
      INTO v_count
      FROM PS_MEE_CHECK_SG
      WHERE RELEASE_ID_SG= :NEW.RELEASE_ID_SG and CO_NUM_SG = :NEW.CO_NUM_SG;
      
      V_RELEASE_ID_SG := :NEW.RELEASE_ID_SG;
      V_CO_NUM_SG := :NEW.CO_NUM_SG;
      
      IF v_count > 0 THEN
        UPDATE PS_MEE_CHECK_SG A
        set a.STATUS          = 'I'
        WHERE a.RELEASE_ID_SG = V_RELEASE_ID_SG
        and a.CO_NUM_SG       = V_CO_NUM_SG;
        commit;
      end if;
END;
/
ALTER TRIGGER MEE_CHECK_SG ENABLE;
/

-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
