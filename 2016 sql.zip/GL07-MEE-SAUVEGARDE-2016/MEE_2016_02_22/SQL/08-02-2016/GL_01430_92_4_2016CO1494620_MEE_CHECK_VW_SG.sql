-- Nom du script        : GL_01430_92_4_2016CO1494620_MEE_CHECK_VW_SG.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01430_92_4_2016CO1494620_MEE_CHECK_VW_SG-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T

  CREATE OR REPLACE FORCE VIEW PS_MEE_CHECK_VW_SG (RELEASE_ID_SG, DATE_STAMP, NB_VALID_SG, NB_INVALID_SG) AS 
  SELECT B.RELEASE_ID_SG ,
  TO_CHAR(MAX(B.EXEC_TIME)) DATE_STAMP ,
  A.NB_VALID_SG ,
  A.NB_INVALID_SG
FROM
  (SELECT COUNT(NB_VALID_SG) NB_VALID_SG ,
    COUNT(NB_INVALID_SG) NB_INVALID_SG ,
    RELEASE_ID_SG
  FROM
    (SELECT DECODE(RESULTS ,'OK' , 1) NB_VALID_SG ,
      DECODE(RESULTS ,'KO' , 1) NB_INVALID_SG ,
      RELEASE_ID_SG
    from PS_MEE_CHECK_SG
    WHERE  STATUS = 'A'
    )
  GROUP BY RELEASE_ID_SG
  ) A ,
  PS_MEE_CHECK_SG B
where a.RELEASE_ID_SG=B.RELEASE_ID_SG
and STATUS = 'A'
GROUP BY B.RELEASE_ID_SG ,
  a.NB_VALID_SG ,
  A.NB_INVALID_SG;


-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
