-- Nom du script        : GL_01429_42_3_2016Update_ME_PRCSAC_VW_SG.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01429_42_3_2016Update_ME_PRCSAC_VW_SG-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T
------------------------------------------------------------------------------
-- Akanksha Prerna- 01/27/2016 - Technical update of ME processed Flag view.   --
------------------------------------------------------------------------------
CREATE OR REPLACE FORCE VIEW "COEPRD00"."PS_ME_PRCSAC_VW_SG" ("FILE_ID_SG", "RDJ_FILE_ID_SG", "COMPANY_SG", "SOURCE_APPL_SG", "SOURCE_DATA_SG", "SPLIT_VALUE_SG", "SPLIT_TOTAL_NUM_SG", "BUSINESS_UNIT", "SCHED_PRCS_DATE_SG", "FILENAME", "N_HDR", "NUM_ROWS", "N_SQLLDR_LD_LN_SG", "N_SQLLDR_REJ_LN_SG", "N_JGEN_DIST_LN_SG", "N_KEYS", "N_RECON_LINES", "PARALLEL_ID", "JOURNAL_ID_FROM", "JOURNAL_ID_TO", "JOURNAL_MIN_DT", "JOURNAL_MAX_DT", "SQLLDR_STATUS_SG", "SQLLDR_DTTM_SG", "SQLLDR_DURATION_SG", "LOAD_STATUS_SG", "LOAD_PI_SG", "LOAD_DTTM_SG", "LOAD_DURATION_SG", "EDIT_STATUS_SG", "EDIT_PI_SG", "EDIT_DTTM_SG", "EDIT_DURATION_SG", "EDIT_HDR_ERRORS_SG", "EDIT_LN_ERRORS_SG", "POST_STATUS_SG", "POST_PI_SG", "POST_DTTM_SG", "POST_DURATION_SG", "RETRY_STATUS_SG", "RETRY_FILE_ID_SG", "DESCR1", "BUSINESS_UNIT_GRP", "NUM_ROWS_SG", "DESCR_TRC", "THREAD_SG", "NEXT_SCAN_SG", "SQLLDR_DURATIO2_SG", "LOAD_DURATION2_SG", "EDIT_DURATION2_SG", "POST_DURATION2_SG", "N_JGEN_DIST_RAT_SG", "MESSAGE_TEXT", "MESSAGE_TEXT2") AS 
  SELECT a.file_id_sg, a.rdj_file_id_sg, a.company_sg, a.source_appl_sg, 
          a.source_data_sg, a.split_value_sg, a.split_total_num_sg, 
          a.business_unit, a.sched_prcs_date_sg, a.filename, a.n_hdr, 
          a.num_rows, a.n_sqlldr_ld_ln_sg, a.n_sqlldr_rej_ln_sg, 
          a.n_jgen_dist_ln_sg, a.n_keys, a.n_recon_lines, a.PARALLEL_ID, 
          a.journal_id_from, a.journal_id_to, a.journal_min_dt, 
          a.journal_max_dt, a.sqlldr_status_sg, a.sqlldr_dttm_sg, 
          a.sqlldr_duration_sg, a.load_status_sg, a.load_pi_sg, 
          a.load_dttm_sg, a.load_duration_sg, a.edit_status_sg, a.edit_pi_sg, 
          a.edit_dttm_sg, a.edit_duration_sg, a.edit_hdr_errors_sg, 
          a.edit_ln_errors_sg, a.post_status_sg, a.post_pi_sg, a.post_dttm_sg, 
          a.post_duration_sg, a.retry_status_sg, a.retry_file_id_sg, 
          CASE 
             WHEN b.part_load_activ_sg = 'Y' 
                THEN 'INTRADAY' 
             WHEN b.full_load_activ_sg = 'Y' 
                THEN 'FULL_LOAD' 
          END, 
          b.business_unit_grp, 
          CASE 
             WHEN n_jgen_dist_ln_sg != -1 
                THEN n_jgen_dist_ln_sg 
             WHEN n_sqlldr_ld_ln_sg != -1 
                THEN n_sqlldr_ld_ln_sg 
             WHEN a.num_rows != -1 
                THEN a.num_rows 
             ELSE NULL 
          END "Lines", 
          CASE 
             WHEN mfl.split_status_sg = 'D' 
                THEN '[9] Splitted (Discarded)' 
             WHEN mfl.split_status_sg = 'R' 
                THEN '[2] Split Running' 
             WHEN mfl.split_status_sg = 'P' 
                THEN '[3] Split Pending' 
             WHEN mfl.split_status_sg = 'E' 
                THEN '[0] Split Error' 
             WHEN a.split_value_sg = 'SPLITTED' 
                THEN '[9] File Splitted' 
             WHEN a.sqlldr_status_sg = 'D' 
                THEN '[9] SQL*Loader Discarded' 
             WHEN a.sqlldr_status_sg = 'R' 
                THEN '[2] SQL*Loader Running' 
             WHEN a.sqlldr_status_sg = 'P' 
                THEN '[3] SQL*Loader Pending' 
             WHEN a.sqlldr_status_sg = 'E' 
                THEN '[0] SQL*Loader Error' 
             WHEN a.sqlldr_status_sg = 'N' 
             AND a.load_status_sg IN ('N') 
                THEN '[4] File Queued' 
             WHEN a.load_status_sg = 'D' 
                THEN '[9] JGen Discarded' 
             WHEN a.load_status_sg = 'R' 
                THEN '[2] JGen Running' 
             WHEN a.load_status_sg = 'P' 
                THEN '[3] JGen Pending' 
             WHEN a.load_status_sg = 'E' 
                THEN '[0] JGen Error' 
             WHEN a.load_status_sg = 'N' 
                THEN '[4] JGen Queued' 
             WHEN a.edit_status_sg = 'D' 
                THEN '[9] Edit Discarded' 
             WHEN a.edit_status_sg = 'R' 
                THEN '[2] Edit Running' 
             WHEN a.edit_status_sg = 'P' 
                THEN '[3] Edit Pending' 
             WHEN a.edit_status_sg = 'E' 
                THEN '[0] Edit Error' 
             WHEN a.edit_status_sg = 'N' 
                THEN '[4] Edit Queued' 
             WHEN a.post_status_sg = 'S' 
                THEN '[5] Post Success' 
             WHEN a.post_status_sg = 'D' 
                THEN '[9] Post Discarded' 
             WHEN a.post_status_sg = 'R' 
                THEN '[2] Post Running' 
             WHEN a.post_status_sg = 'P' 
                THEN '[3] Post Pending' 
             WHEN a.post_status_sg = 'E' 
                THEN '[0] Post Error' 
             WHEN a.post_status_sg = 'N' 
                THEN '[4] Post Queued' 
             ELSE 'Step Not Defined' 
          END "Step / Status", 
          CASE 
             WHEN mfl.split_status_sg = 'R' 
              OR a.sqlldr_status_sg = 'R' 
              OR a.load_status_sg = 'R' 
              OR a.edit_status_sg = 'R' 
              OR a.post_status_sg = 'R' 
                THEN REPLACE (a.PARALLEL_ID, 'RUN', 'Thread') 
             ELSE NULL 
          END "#Thread", 
          TO_CHAR (mfl.next_analyze_sg, 'DD/MM HH24:MI') "Next Scan", 
          CASE 
             WHEN NVL (sqlldr_duration_sg, -1) != -1 
                THEN sqlldr_duration_sg 
             WHEN sqlldr_dttm_sg IS NOT NULL 
                THEN ROUND ((SYSDATE - CAST(sqlldr_dttm_sg AS DATE)) * 1440, 2) 
             ELSE NULL 
          END AS "Loader", 
          CASE 
             WHEN NVL (load_duration_sg, -1) != -1 
                THEN load_duration_sg 
             WHEN load_dttm_sg IS NOT NULL 
                THEN ROUND ((SYSDATE - CAST(load_dttm_sg AS DATE)) * 1440, 2) 
             ELSE NULL 
          END AS "JGen", 
          CASE 
             WHEN NVL (edit_duration_sg, -1) != -1 
                THEN edit_duration_sg 
             WHEN edit_dttm_sg IS NOT NULL 
                THEN ROUND ((SYSDATE - CAST(edit_dttm_sg AS DATE)) * 1440, 2) 
             ELSE NULL 
          END "Edit", 
          CASE 
             WHEN NVL (post_duration_sg, -1) != -1 
                THEN post_duration_sg 
             WHEN post_dttm_sg IS NOT NULL 
                THEN ROUND ((SYSDATE - CAST(post_dttm_sg AS DATE)) * 1440, 2) 
             ELSE NULL 
          END "Post", 
          CASE 
             WHEN n_jgen_dist_ln_sg > 0 
                THEN ROUND (  n_jgen_dist_ln_sg 
                            / (  NVL (ABS (sqlldr_duration_sg), 0.1) 
                               + NVL (ABS (load_duration_sg), 0.1) 
                               + NVL (ABS (edit_duration_sg), 0.1) 
                              ), 
                            0 
                           ) 
             ELSE NULL 
          END AS "Rate", 
          CASE 
             WHEN n_sqlldr_rej_ln_sg NOT IN (-1, 0) 
                THEN 'ERR> SQL*Ldr : ' || n_sqlldr_rej_ln_sg 
             WHEN   n_sqlldr_ld_ln_sg 
                  - (DECODE (n_jgen_dist_ln_sg, 
                             -1, n_sqlldr_ld_ln_sg, 
                             n_jgen_dist_ln_sg 
                            ) 
                    ) > 0 
                THEN    'ERR> JGen : ' 
                     || TO_CHAR (n_sqlldr_ld_ln_sg - n_jgen_dist_ln_sg) 
             WHEN edit_hdr_errors_sg = 0 
                THEN 'No Errors' 
             WHEN edit_hdr_errors_sg > 0 
                THEN    'ERR> Edit : ' 
                     || edit_hdr_errors_sg 
                     || ' Hd/' 
                     || edit_ln_errors_sg 
                     || ' Ln' 
             ELSE NULL 
          END AS "Message", 
          CASE 
             WHEN journal_id_from != ' ' 
                THEN    journal_id_from 
                     || ' to ' 
                     || journal_id_to 
             ELSE NULL 
          END AS "Journal Id." 
     FROM PS_ME_PROCESSED_SG a, 
          PS_ME_BU_STATUS_SG b, 
          PS_ME_RF_BU_GRP_SG e, 
          PS_ME_FILE_LOAD_SG mfl 
    WHERE a.business_unit = e.business_unit 
      AND b.business_unit_grp = e.business_unit_grp 
      AND a.file_id_sg = mfl.file_id_sg 
      AND a.business_unit = mfl.business_unit
      AND a.sched_prcs_date_sg = b.sched_prcs_date_sg;
      

-- Create public synonyms
CREATE OR REPLACE PUBLIC SYNONYM PS_ME_PRCSAC_VW_SG FOR COEPRD00.PS_ME_PRCSAC_VW_SG;

-- Give access 
GRANT SELECT ON PS_ME_PRCSAC_VW_SG TO COE_SEL_TOUT;
GRANT SELECT ON PS_ME_PRCSAC_VW_SG TO IT_COE_BEGINNER;
GRANT SELECT ON PS_ME_PRCSAC_VW_SG TO IT_COE_DEFAULT;

/


-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
