-- Nom du script        : GL_01426_32_3_2016SG_LOT1047_Trigger_alter.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01426_32_3_2016SG_LOT1047_Trigger_alter-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T
CREATE OR REPLACE TRIGGER FEED_JRNLLN_CUSTOM_FIELDS_SG
 BEFORE UPDATE OF JRNL_HDR_STATUS ON PS_JRNL_HEADER
 REFERENCING NEW AS New OLD AS Old
 FOR EACH ROW
DECLARE
  l_indic     INTEGER;
  l_indic_NY  INTEGER;
  l_begindttm DATE;
  l_rdj_dt    DATE;
  l_updlines  NUMBER;
  l_BO_DT_SG  DATE;
  l_AUDIT_OPRID VARCHAR2(64);
BEGIN
  -- This completion on JRNL_LN is triggered only once the journal is posted or unposted
  IF :new.JRNL_HDR_STATUS in ('P', 'U')
  THEN
      -- For any standard file the RDJ_DT_SG is compulsory.
      -- A null BO_DT_SG on line 1 indicates that it is a system generated journal (RVM, CLO etc.) and needs completion.
      SELECT count(BO_DT_SG), MIN(RDJ_DT_SG) into l_indic, l_rdj_dt
      FROM   PS_JRNL_LN
      WHERE  BUSINESS_UNIT = :new.BUSINESS_UNIT
      AND    JOURNAL_ID    = :new.JOURNAL_ID
      AND    JOURNAL_DATE  = :new.JOURNAL_DATE
      AND    UNPOST_SEQ    = :new.UNPOST_SEQ
      AND    JOURNAL_LINE  = 1;

      IF l_indic = 0
      THEN
         l_begindttm := SYSDATE;
         DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_AUDIT_OPRID);
         l_audit_oprid := GET_PS_OPRID(l_AUDIT_OPRID);

         -- NY business_unit are on specific SETID for ALTACCT. The feeding rules are different for them.
         SELECT COUNT(*) into l_indic_NY
         FROM   PS_SET_CNTRL_REC REC
         WHERE  RECNAME='ALTACCT_TBL'
         AND    SETID IN ('NYSUB', 'SGUSA', 'COWEN')
         AND    SETCNTRLVALUE=:new.BUSINESS_UNIT;

         IF l_indic_NY = 1 THEN
           -- BO_DT_SG : For NY it was given in the AE015_NY run cntrl. Which equalled the $U as of date.
           SELECT TO_DATE(SCHED_PRCS_DATE_SG, 'YYYYMMDD') INTO l_BO_DT_SG
           FROM PS_ME_BU_STATUS_SG WHERE BUSINESS_UNIT_GRP = 'SGUSA';

           UPDATE PS_JRNL_LN
           SET
             EVENT_DT_SG     = NVL(EVENT_DT_SG, TRUNC(SYSDATE, 'DD')),
             VALUE_DT_SG     = NVL(VALUE_DT_SG, :new.JOURNAL_DATE),
             BO_DT_SG        = NVL(l_BO_DT_SG, JOURNAL_DATE),
             USER1_SG        = DECODE(USER1_SG, ' ', LINE_DESCR,  USER1_SG),
             USER2_SG        = DECODE(USER2_SG, ' ', JRNL_LN_REF, USER2_SG),
             USER3_SG        = DECODE(USER3_SG, ' ', 'AC',        USER3_SG)
           WHERE  BUSINESS_UNIT = :new.BUSINESS_UNIT
           AND    JOURNAL_ID    = :new.JOURNAL_ID
           AND    JOURNAL_DATE  = :new.JOURNAL_DATE
           AND    UNPOST_SEQ    = :new.UNPOST_SEQ;

         ELSE
           UPDATE PS_JRNL_LN
           SET
             EVENT_DT_SG     = NVL(EVENT_DT_SG, :new.JOURNAL_DATE),
             VALUE_DT_SG     = NVL(VALUE_DT_SG,:new.JOURNAL_DATE),
             BO_DT_SG        = NVL(BO_DT_SG, :new.POSTED_DATE),
             RDJ_DT_SG       = NVL(RDJ_DT_SG, :new.POSTED_DATE),
             OPERATION_CD_SG = DECODE(OPERATION_CD_SG, ' ', :new.SOURCE, OPERATION_CD_SG),
             USER5_SG        = DECODE(USER5_SG, ' ', l_audit_oprid, USER5_SG)
           WHERE  BUSINESS_UNIT = :new.BUSINESS_UNIT
           AND    JOURNAL_ID    = :new.JOURNAL_ID
           AND    JOURNAL_DATE  = :new.JOURNAL_DATE
           AND    UNPOST_SEQ    = :new.UNPOST_SEQ;
         END IF;

      l_updlines := SQL%ROWCOUNT;

	  -- ALO @14/12/2015 Begin modification JIRA GLTES-47 	  
      /*INSERT INTO  PS_JL_FLDS_LOG_SG (BUSINESS_UNIT, JOURNAL_ID, JOURNAL_DATE, UNPOST_SEQ, NUM_ROWS, IN_SECONDS, OPRID)
                   VALUES  (:new.BUSINESS_UNIT, :new.JOURNAL_ID, :new.JOURNAL_DATE, :new.UNPOST_SEQ,
                           l_updlines, round ( (sysdate-l_begindttm)*24*60*60 ), l_audit_oprid );  */
						   
		IF :new.JRNL_HDR_STATUS in ('U') -- Need to Update an existing line PS_JL_FLDS_LOG_SG
		THEN
				INSERT INTO  PS_JL_FLDS_LOG_SG (BUSINESS_UNIT, JOURNAL_ID, JOURNAL_DATE, UNPOST_SEQ, NUM_ROWS, IN_SECONDS, OPRID, POST_UTC_DTTM_SG, UNPOST_UTC_DTTM_SG)
			VALUES  (:new.BUSINESS_UNIT, :new.JOURNAL_ID, :new.JOURNAL_DATE, :new.UNPOST_SEQ,
			l_updlines, round ( (sysdate-l_begindttm)*24*60*60 ), l_audit_oprid, NULL, cast(:new.DTTM_STAMP_SEC as timestamp) at time zone 'UTC' ); 								  
		ELSIF :new.JRNL_HDR_STATUS in ('P') -- Need to Insert a new existing line in PS_JL_FLDS_LOG_SG
		THEN
				INSERT INTO  PS_JL_FLDS_LOG_SG (BUSINESS_UNIT, JOURNAL_ID, JOURNAL_DATE, UNPOST_SEQ, NUM_ROWS, IN_SECONDS, OPRID, POST_UTC_DTTM_SG, UNPOST_UTC_DTTM_SG)
			VALUES  (:new.BUSINESS_UNIT, :new.JOURNAL_ID, :new.JOURNAL_DATE, :new.UNPOST_SEQ,
			l_updlines, round ( (sysdate-l_begindttm)*24*60*60 ), l_audit_oprid, cast(:new.DTTM_STAMP_SEC as timestamp) at time zone 'UTC' ,NULL); 	
		END IF;
	-- ALO @14/12/2015 End modification JIRA GLTES-47 	 							  
						  
      ELSE
        -- set transaction_date to rdj_date
        :new.TRANSACTION_DATE := l_rdj_dt;

      END IF;

   END IF;
END;
/



-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
