-- Nom du script        : GL_01426_22_3_2016SG_LOT1047_Table_alter.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01426_22_3_2016SG_LOT1047_Table_alter-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T
/* Adil LOUSKI - le 20/01/2016 */
/* add columns  */

-- ******** ROLLBACK *********
-- Drop the columns if they already exist in the table
WHENEVER SQLERROR CONTINUE ;
alter table PS_JL_FLDS_LOG_SG drop column POST_UTC_DTTM_SG ; 
alter table PS_JL_FLDS_LOG_SG drop column UNPOST_UTC_DTTM_SG; 

-- ********** BUILD **********
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;

alter table PS_JL_FLDS_LOG_SG add POST_UTC_DTTM_SG TIMESTAMP (6) 
/
alter table PS_JL_FLDS_LOG_SG add UNPOST_UTC_DTTM_SG TIMESTAMP (6) 
/



-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
