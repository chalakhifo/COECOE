-- Nom du script        : GL_01414_912_30_2015PS_AR4_DTM_SG.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
set head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
SET LINESIZE 1000;
spool spool.sql;
SELECT  'spool  GL_01414_912_30_2015PS_AR4_DTM_SG-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log' FROM    dual;
spool off;

--Variables d'environnements
set head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91;
SET PAGESIZE 500;
SET TIMI OFF;
set ECHO ON;
SET serveroutput on size 1000000;

--g�n�ration du fichier log
@spool;
select 'Debut du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;  
-- sortie si erreur
whenever sqlerror exit -1 rollback;

SET TIMI ON;
SET FEEDBACK ON;
-- debut du script
  
--  SSSSSSSSS  OOOOOOOOO  RRRRRRRRRRR  I  PPPPPPPPPP  TTTTTTTTTTTT
--  S          O          R         R  I  P        P       T
--  SSSSSSSSS  O          RRRRRRRRRRR  I  PPPPPPPPPP       T
--          S  O          R   R        I  P                T
--          S  O          R    R       I  P                T
--  SSSSSSSSS  OOOOOOOOO  R     R      I  P                T
create or replace 
PACKAGE Ps_Ar4_Dtm_Sg
AS
/*******************************************************************
-- MHE le 15/07/2015 Development in Progress
--
********************************************************************/


   PROCEDURE Ins_YTD_Period_1(i_process_instance INTEGER, fisyear NUMBER, RaN VARCHAR2, busunit VARCHAR2, ldgr VARCHAR2, drcr VARCHAR2);
   PROCEDURE Ins_AR4_Period_m (i_process_instance INTEGER, i_Bu VARCHAR2, i_user VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_From_date DATE, i_To_Date DATE, i_max_posted_dt DATE, i_last_dttm_stamp_sec TIMESTAMP, i_where_clause VARCHAR2, o_numrows OUT INTEGER);
   PROCEDURE Load_AR4_DLY_BU_Source (i_process_instance INTEGER, i_Bu VARCHAR2,  i_user VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_FromDttm TIMESTAMP, i_ToDttm TIMESTAMP,  i_calc_dly VARCHAR2, i_last_dttm_stamp_sec TIMESTAMP, i_max_posted_date DATE);
   PROCEDURE Load_AGG_BU_Source (i_process_instance INTEGER, i_Bu VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_user VARCHAR2, o_numrows OUT INTEGER);
   PROCEDURE Load_AR4_BU_Source (i_process_instance INTEGER, i_Bu VARCHAR2,  i_user VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_FromDttm TIMESTAMP, i_ToDttm TIMESTAMP, i_FORCE_INIT_SG VARCHAR2, i_DROP_INIT_SG VARCHAR2, i_last_dttm_stamp_sec TIMESTAMP, i_max_posted_date TIMESTAMP, where_clause VARCHAR2);
   PROCEDURE Load_AR4_BU (i_process_instance INTEGER, i_Bu VARCHAR2, i_user VARCHAR2, i_runCntlId VARCHAR2);
   PROCEDURE Load_AR4_BU_GRP (i_process_instance INTEGER, i_BUGrp VARCHAR2, i_reqdate DATE, i_user VARCHAR2, i_runCntlId VARCHAR2);

   -- technical procedure
   PROCEDURE AddLog(i_process_instance INTEGER, i_Bu VARCHAR2, i_Source VARCHAR2, i_log_dtl VARCHAR2, i_From_date DATE, i_To_Date DATE, i_max_posted_dt DATE, i_num_Rows INTEGER, i_msg VARCHAR2, i_user VARCHAR2);
   PROCEDURE ManagePartition(i_process_instance INTEGER, i_Bu VARCHAR2, i_Source VARCHAR2, i_tableName VARCHAR2);

   CST_MAX_LOOP CONSTANT INTEGER := 1200;
   CST_START_DATE CONSTANT TIMESTAMP := SYSTIMESTAMP;

END Ps_Ar4_Dtm_Sg;

create or replace 
PACKAGE BODY Ps_Ar4_Dtm_Sg AS
/*******************************************************************
-- MHE le 15/07/2015 Development in Progress
--
********************************************************************/

   /* Procedure dedicated to follow the procedure step by step */
   /* The table may be be cleaned totally when too big         */
   PROCEDURE AddLog(i_process_instance INTEGER, i_Bu VARCHAR2, i_Source VARCHAR2, i_log_dtl VARCHAR2, i_From_date DATE, i_To_Date DATE, i_max_posted_dt DATE, i_num_Rows INTEGER, i_msg VARCHAR2, i_user VARCHAR2)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      IF i_log_dtl = 'Y' THEN
         INSERT INTO PS_AR4_LOG_SG
            (BUSINESS_UNIT, SOURCE, FROM_DTTM6_SG, TO_DTTM6_SG, POSTED_DATE, NUMROWS, MESSAGE_CLAUSE, CREATEDTTM, OPRID, PROCESS_INSTANCE)
         VALUES(i_Bu, i_Source, i_From_date, i_To_Date, i_max_posted_dt, i_num_Rows, i_msg, SYSTIMESTAMP, i_user, i_process_instance);
         COMMIT;
      END IF;
   END;

   /* Create partition and subpartition if necessary */
   PROCEDURE ManagePartition(i_process_instance INTEGER, i_Bu VARCHAR2, i_Source VARCHAR2, i_tableName VARCHAR2)
   IS
      l_prefix                 VARCHAR2(3) := 'AR4';
      l_sql_statement          VARCHAR2(250);
      l_partition_name         VARCHAR2(20);
      l_partition_name_bis     VARCHAR2(20);
      l_subpartition_name      VARCHAR2(30);
      l_subpartition_name_bis  VARCHAR2(30);
      err_num      INTEGER;
      err_msg      VARCHAR2(250);
   BEGIN
      l_partition_name := l_prefix ||i_Bu;
      l_subpartition_name := l_prefix ||i_Bu||i_Source;
      -- Create partition on BU if necessary
      BEGIN
         SELECT p.partition_name
         INTO   l_partition_name_bis
         FROM   user_tab_partitions p
         WHERE  p.table_name = i_tableName
         AND    p.partition_name = l_partition_name;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
         -- Create new partition
         l_sql_statement := 'ALTER TABLE '|| i_tableName || ' ADD PARTITION '||l_partition_name ||' VALUES(''' ||i_Bu||''') (SUBPARTITION '||l_subpartition_name ||' VALUES ('''||i_Source||''')) ';
         EXECUTE IMMEDIATE l_sql_statement;
         WHEN OTHERS THEN
            err_num := SQLCODE;
            err_msg := SUBSTR('ERROR ManagePartition - '|| l_sql_statement ||' - ' || err_num||' - '|| SQLERRM, 1, 250);
            UPDATE PS_AR4_SCOPE_SG
            SET    msg_status_sg = 'E'
            WHERE  business_unit = i_Bu
            AND    SOURCE = i_Source;
            AddLog(i_process_instance, i_Bu, i_Source, 'Y', NULL, NULL, NULL, 0, err_msg, ' ');
      END;

      -- Create sub partition on source if necessary
      BEGIN
         SELECT s.subpartition_name
         INTO   l_partition_name_bis
         FROM   user_tab_subpartitions s
         WHERE  s.table_name = i_tableName
         AND    s.partition_name = l_partition_name
         AND    s.subpartition_name = l_subpartition_name;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            -- Create new partition
            l_sql_statement := 'ALTER TABLE '|| i_tableName || ' MODIFY PARTITION '|| l_partition_name ||' ADD SUBPARTITION '|| l_subpartition_name ||' VALUES(''' ||i_Source||''') ';
            EXECUTE IMMEDIATE l_sql_statement;
         WHEN OTHERS THEN
            err_num := SQLCODE;
            err_msg := SUBSTR('ERROR ManagePartition - '|| l_sql_statement ||' - ' || err_num||' - '|| SQLERRM, 1, 250);
            UPDATE PS_AR4_SCOPE_SG
            SET    msg_status_sg = 'E'
            WHERE  business_unit = i_Bu
            AND    SOURCE = i_Source;
            AddLog(i_process_instance, i_Bu, i_Source, 'Y', NULL, NULL, NULL, 0, err_msg, ' ');
      END;
   EXCEPTION
      WHEN OTHERS THEN
         err_num := SQLCODE;
         err_msg := SUBSTR('ERROR ManagePartition - unable to analyze or create partition - ' || err_num||' - '|| SQLERRM, 1, 250);
         UPDATE PS_AR4_SCOPE_SG
         SET    msg_status_sg = 'E'
         WHERE  business_unit = i_Bu
         AND    SOURCE = i_Source;
         AddLog(i_process_instance, i_Bu, i_Source, 'Y', NULL, NULL, NULL, 0, err_msg, ' ');
   END;


   PROCEDURE Ins_YTD_Period_1(i_process_instance INTEGER, fisyear NUMBER, RaN VARCHAR2, busunit VARCHAR2, ldgr VARCHAR2, drcr VARCHAR2)
   IS BEGIN
      NULL;
   END;


   PROCEDURE Load_AGG_BU_Source(i_process_instance INTEGER, i_Bu VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_user VARCHAR2, o_numrows OUT INTEGER)
   IS
      err_num      INTEGER;
      err_msg      VARCHAR2(250);
      V_NUMROWS    INTEGER := 0;
   BEGIN
      o_numrows := 0;
      AddLog(i_process_instance, i_Bu, i_Source, i_log_msg, NULL, NULL, NULL, 0, 'START Load_AGG_BU_Source', i_user);
      INSERT INTO PS_AR4_AGG_GRA_SG (
         business_unit, ACCOUNT, altacct, deptid, affiliate, OBJECT_CODE, product, operating_unit, bo_id_sg,
         EVENT_NATURE, FOREIGN_AMOUNT, FOREIGN_CURRENCY, GL_SOURCE, POSTED_DATE)
      SELECT
         BUSINESS_UNIT, ACCOUNT, ALTACCT, DEPTID, AFFILIATE, OBJECT_CODE, PRODUCT, OPERATING_UNIT, BO_ID_SG, EVENT_NATURE, SUM(FOREIGN_AMOUNT),
         FOREIGN_CURRENCY, GL_SOURCE, MAX(POSTED_DATE)
      FROM PS_AR4_JRNL_GRA_SG
      WHERE BUSINESS_UNIT = I_BU
      AND   GL_SOURCE = i_Source
      AND   ACCOUNTING_PERIOD BETWEEN 1 AND 12
      GROUP BY BUSINESS_UNIT, ACCOUNT, ALTACCT, DEPTID, AFFILIATE,  OBJECT_CODE, PRODUCT, OPERATING_UNIT, BO_ID_SG, EVENT_NATURE, FOREIGN_CURRENCY, GL_SOURCE;
      V_NUMROWS := SQL%ROWCOUNT;
      o_numrows := V_NUMROWS;
      AddLog(i_process_instance, i_Bu, i_Source, i_log_msg, NULL, NULL, NULL, V_NUMROWS, 'End Load_AGG_BU_Source', i_user);
      COMMIT;
   EXCEPTION
       WHEN OTHERS THEN
          err_num := SQLCODE;
          err_msg := SUBSTR('ERROR Load_AGG_BU_Source ' || err_num||' - '|| SQLERRM, 1, 250);
          UPDATE PS_AR4_SCOPE_SG
          SET    msg_status_sg = 'E'
          WHERE  business_unit = i_Bu
          AND    SOURCE = i_Source;
          AddLog(i_process_instance, i_Bu , i_Source, 'Y', NULL, NULL, NULL, 0, err_msg , i_user);
   END;


   PROCEDURE Ins_AR4_Period_m (i_process_instance INTEGER, i_Bu VARCHAR2, i_user VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_From_date DATE, i_To_Date DATE, i_max_posted_dt DATE, i_last_dttm_stamp_sec TIMESTAMP, i_where_clause VARCHAR2, o_numrows OUT INTEGER)
   IS
      err_num      INTEGER;
      err_msg      VARCHAR2(250);
      V_NUMROWS    INTEGER := 0;
   l_sql_statement VARCHAR2(4000) := '';
   BEGIN
      o_numrows := 0;
      AddLog(i_process_instance, i_Bu, i_Source, i_log_msg , i_From_date, i_To_Date, i_max_posted_dt, 0, 'Start Ins_AR4_Period_m - i_last_dttm_stamp_sec = '||i_last_dttm_stamp_sec, i_user);
       l_sql_statement := l_sql_statement || ' '||trim('INSERT INTO PS_AR4_JRNL_GRA_SG (business_unit, ACCOUNT, altacct, deptid, affiliate, ');
       l_sql_statement := l_sql_statement || ' '||trim('            OBJECT_CODE, PRODUCT, OPERATING_UNIT, BO_ID_SG, EVENT_NATURE , ACCOUNTING_PERIOD , ');
       l_sql_statement := l_sql_statement || ' '||trim('            fiscal_year, foreign_amount, foreign_currency, gl_source, posted_date ) ');
       l_sql_statement := l_sql_statement || ' '||trim(' SELECT ');
       l_sql_statement := l_sql_statement || ' '||trim('           LN.BUSINESS_UNIT, LN.ACCOUNT, LN.ALTACCT, LN.DEPTID, LN.AFFILIATE, LN.OBJECT_CODE, LN.PRODUCT, LN.OPERATING_UNIT, LN.BO_ID_SG, ');
       l_sql_statement := l_sql_statement || ' '||trim('  (CASE ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE IN (''ARI'',''BZF'',''CAT'',''CFD'',''CTG'',''CYN'',''ENT'',''GMI'',''LNS'',''PEC'',''PLT'',''SIR'',''SPB'',''SPX'',''TAU'',''TAV'',''TPE'',''USG'') ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''MPA'' AND LN.BUSINESS_UNIT <> ''G2986'' ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE IN (''CLS'',''CLT'',''FX1'',''LOA'',''OPS'',''QTZ'',''RFI'',''TES'',''TOP'') ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''BIR'' AND LN.BUSINESS_UNIT NOT IN (''G0001'',''I0001'') ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''MPA'' AND LN.BUSINESS_UNIT  = ''G2986'' ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''BIR'' AND LN.BUSINESS_UNIT IN (''G0001'',''I0001'') ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,7,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''PTS'' AND LN.BUSINESS_UNIT  = ''G9297'' ');
       l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
       l_sql_statement := l_sql_statement || ' '||trim('   ELSE LN.OPERATION_CD_SG ');
       l_sql_statement := l_sql_statement || ' '||trim('   END) AS EVENT_NATURE, ');

       -- l_sql_statement := l_sql_statement || ' '||trim('            WHEN HDR.SOURCE IN (''ARI'',''BZF'',''CAT'',''CFD'',''CTG'',''CYN'',''ENT'',''GMI'',''LNS'',''MPA'',''PEC'',''PLT'',''SIR'',''SPB'',''SPX'',''TAU'',''TAV'',''TPE'',''USG'') ');
       -- l_sql_statement := l_sql_statement || ' '||trim('               THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), '' '') ');
       -- l_sql_statement := l_sql_statement || ' '||trim('            WHEN HDR.SOURCE IN (''CLS'',''CLT'',''FX1'',''LOA'',''OPS'',''QTZ'',''RFI'',''TES'',''TOP'') THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
       -- l_sql_statement := l_sql_statement || ' '||trim('            WHEN HDR.SOURCE = ''BIR'' THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,7,3)), '' '') ');
       -- l_sql_statement := l_sql_statement || ' '||trim('            WHEN HDR.SOURCE = ''PTS'' THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
       -- l_sql_statement := l_sql_statement || ' '||trim('            ELSE NVL(LN.OPERATION_CD_SG, '' '') ');
       --l_sql_statement := l_sql_statement || ' '||trim('            END) AS EVENT_NATURE,

       l_sql_statement := l_sql_statement || ' '||trim('            HDR.ACCOUNTING_PERIOD, HDR.FISCAL_YEAR, SUM(LN.FOREIGN_AMOUNT), LN.FOREIGN_CURRENCY, ');
       l_sql_statement := l_sql_statement || ' '||trim('            hdr.SOURCE, MAX(nvl(HDR.POSTED_DATE, HDR.ADB_DATE ) ) ');
       l_sql_statement := l_sql_statement || ' '||trim('     FROM PS_JRNL_HEADER HDR, ');
       l_sql_statement := l_sql_statement || ' '||trim('          PS_JRNL_LN LN ');
       l_sql_statement := l_sql_statement || ' '||trim('     WHERE HDR.BUSINESS_UNIT = LN.BUSINESS_UNIT  ');
       l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.JOURNAL_ID = LN.JOURNAL_ID AND HDR.JOURNAL_DATE=LN.JOURNAL_DATE ');
       l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.UNPOST_SEQ = LN.UNPOST_SEQ AND HDR.JRNL_HDR_STATUS IN (''P'',''U'') ');
       l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.LEDGER_GROUP NOT IN (''INDIV'', ''CNTRPARTY'')   ');
       -- MHE 17/09/2015 if the take period 0 we will include duplicate data for comptes de bilan
        l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.ACCOUNTING_PERIOD NOT IN (0, 999) ');
        l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.SOURCE = '''|| i_source ||''' ');
        l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.BUSINESS_UNIT = '''|| i_bu ||''' ');
        l_sql_statement := l_sql_statement || ' '||trim('     AND   nvl(HDR.POSTED_DATE, hdr.adb_date) <= to_date('''|| TO_CHAR(i_max_posted_dt,'DD/MM/YYYY') ||''', ''DD/MM/YYYY'') ');
        -- AND   HDR.JOURNAL_DATE  BETWEEN  i_From_date AND i_To_date ';
        l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.JOURNAL_DATE  >=  to_date('''|| TO_CHAR(i_From_date,'DD/MM/YYYY') ||''', ''DD/MM/YYYY'') ');
        l_sql_statement := l_sql_statement || ' '||trim('     AND   HDR.JOURNAL_DATE  < to_date('''|| TO_CHAR(i_to_date,'DD/MM/YYYY') ||''', ''DD/MM/YYYY'') ');
        -- A recoder Asap
         -- l_sql_statement := l_sql_statement || trim('     AND   HDR.DTTM_STAMP_SEC < i_last_dttm_stamp_sec ');
         l_sql_statement := l_sql_statement || trim('     AND   HDR.DTTM_STAMP_SEC < to_timestamp('''|| TO_CHAR(i_last_dttm_stamp_sec, 'DD/MM/YYYY HH24:MI:SS.FF') || ''', ''DD/MM/YYYY HH24:MI:SS.FF'') ');
         IF i_WHERE_CLAUSE <> ' ' THEN
            l_sql_statement := l_sql_statement || ' '||trim(i_WHERE_CLAUSE) ;
         END IF;
         l_sql_statement := l_sql_statement || ' '||trim('     AND (       (      TRUNC(to_date('''|| TO_CHAR(i_From_date,'DD/MM/YYYY') ||''', ''DD/MM/YYYY''), ''YYYY'') = TRUNC(SYSDATE, ''YYYY'') ');

         -- AddLog(i_process_instance, i_Bu, i_Source, i_log_msg , i_From_date, i_To_Date, i_max_posted_dt, 0, 'DEBUG = '||trim('     AND (       (      TRUNC(to_date('''|| TO_CHAR(i_From_date,'DD/MM/YYYY') ||''', ''DD/MM/YYYY''), ''YYYY'') = TRUNC(SYSDATE, ''YYYY'') '), i_user);

         -- 27/10/2015 Nouvelle version
         IF i_bu = 'G0001' THEN
            l_sql_statement := l_sql_statement || ' '||trim('                   AND  SUBSTR(LN.altacct, 5,1) IN (6,7) ) ');
         ELSE
            l_sql_statement := l_sql_statement || ' '||trim('                   AND  SUBSTR(LN.ACCOUNT, 1,1) IN (6,7) ) ');
        END IF;
         l_sql_statement := l_sql_statement || ' '||trim('        OR   ');
         IF i_bu = 'G0001' THEN
            l_sql_statement := l_sql_statement || ' '||trim('                   SUBSTR(LN.altacct, 5,1) NOT IN (6,7) ) ');
         ELSE
            l_sql_statement := l_sql_statement || ' '||trim('                   SUBSTR(LN.ACCOUNT, 1,1) NOT IN (6,7) ) ');
        END IF;

-- 27/10/2015 Mise en commentaires
--         l_sql_statement := l_sql_statement || ' '||trim('     AND EXISTS ( SELECT 1  ');
--         l_sql_statement := l_sql_statement || ' '||trim('                  FROM PS_AR4_PERI_GLM_SG PG ');
--         l_sql_statement := l_sql_statement || ' '||trim('                  WHERE PG.BUSINESS_UNIT = LN.BUSINESS_UNIT ');
--   IF i_bu = 'G0001' THEN
--            l_sql_statement := l_sql_statement || ' '||trim('                   AND   PG.ACCOUNT = LN.altacct  ');
--         ELSE
--            l_sql_statement := l_sql_statement || ' '||trim('                   AND   PG.ACCOUNT = LN.ACCOUNT ');
--   END IF;
--         l_sql_statement := l_sql_statement || ' '||trim('                   AND   PG.DEPTID = LN.DEPTID ');
-- removed as asked on 14/10/2015
--       l_sql_statement := l_sql_statement || ' '||trim('     AND   PG.PRODUCT  = HDR.SOURCE    ');
--       l_sql_statement := l_sql_statement || ' '||trim('       ');
--
--         l_sql_statement := l_sql_statement || ' '||trim('                 ) ');
--         l_sql_statement := l_sql_statement || ' '||trim('        )  ');
--         l_sql_statement := l_sql_statement || ' '||trim('        OR   ');
--         l_sql_statement := l_sql_statement || ' '||trim('        EXISTS ( SELECT 1    ');
--         l_sql_statement := l_sql_statement || ' '||trim('                FROM PS_AR4_PERI_GLM_SG PG ');
--         l_sql_statement := l_sql_statement || ' '||trim('                WHERE PG.BUSINESS_UNIT = LN.BUSINESS_UNIT   ');
--      IF i_bu = 'G0001' THEN
--            l_sql_statement := l_sql_statement || ' '||trim('       AND   PG.ACCOUNT = LN.ALTACCT ');
--   ELSE
--            l_sql_statement := l_sql_statement || ' '||trim('       AND   PG.ACCOUNT = LN.ACCOUNT ');
--   END IF;
--        l_sql_statement := l_sql_statement || ' '||trim('       AND   PG.DEPTID = LN.DEPTID  ');
--        l_sql_statement := l_sql_statement || ' '||trim('       AND   PG.ACCT_TYPE = ''O'' ');
--        l_sql_statement := l_sql_statement || ' '||trim('       ) ');
--        l_sql_statement := l_sql_statement || ' '||trim('      )  ');


        l_sql_statement := l_sql_statement || ' '||trim('      GROUP BY LN.FOREIGN_CURRENCY, LN.BUSINESS_UNIT, LN.ACCOUNT, LN.ALTACCT, LN.DEPTID, LN.AFFILIATE, LN.OBJECT_CODE, LN.PRODUCT, LN.OPERATING_UNIT,');
        l_sql_statement := l_sql_statement || ' '||trim('               LN.BO_ID_SG,  (CASE ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE IN (''ARI'',''BZF'',''CAT'',''CFD'',''CTG'',''CYN'',''ENT'',''GMI'',''LNS'',''PEC'',''PLT'',''SIR'',''SPB'',''SPX'',''TAU'',''TAV'',''TPE'',''USG'') ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''MPA'' AND LN.BUSINESS_UNIT <> ''G2986'' ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE IN (''CLS'',''CLT'',''FX1'',''LOA'',''OPS'',''QTZ'',''RFI'',''TES'',''TOP'') ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''BIR'' AND LN.BUSINESS_UNIT NOT IN (''G0001'',''I0001'') ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''MPA'' AND LN.BUSINESS_UNIT  = ''G2986'' ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''BIR'' AND LN.BUSINESS_UNIT IN (''G0001'',''I0001'') ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,7,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   WHEN HDR.SOURCE = ''PTS'' AND LN.BUSINESS_UNIT  = ''G9297'' ');
        l_sql_statement := l_sql_statement || ' '||trim('      THEN nvl(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), '' '') ');
        l_sql_statement := l_sql_statement || ' '||trim('   ELSE LN.OPERATION_CD_SG ');
        l_sql_statement := l_sql_statement || ' '||trim('   END), HDR.ACCOUNTING_PERIOD, HDR.FISCAL_YEAR, HDR.SOURCE ');

       -- INSERT INTO mhe_test (mhe_sql) VALUES (l_sql_statement);
       -- COMMIT;

      EXECUTE IMMEDIATE l_sql_statement;

     V_NUMROWS := SQL%ROWCOUNT;
        o_numrows := V_NUMROWS;
        AddLog(i_process_instance, i_Bu, i_Source, i_log_msg, i_From_date, i_To_Date, i_max_posted_dt, V_NUMROWS, 'End Ins_AR4_Period_m', i_user);
       COMMIT;
    EXCEPTION
       WHEN OTHERS THEN
          err_num := SQLCODE;
          err_msg := SUBSTR('ERROR Ins_AR4_Period_m ' || err_num||' - '|| SQLERRM, 1, 250);
          UPDATE PS_AR4_SCOPE_SG
          SET    msg_status_sg = 'E'
          WHERE  business_unit = i_Bu
          AND    SOURCE = i_Source;
          AddLog(i_process_instance, i_Bu , i_Source,  'Y', i_From_date, i_To_Date, i_max_posted_dt, 0, err_msg , i_user);
    END;


   /**********************************************************************/
   /* This procedure deals with all source setup for a BU and a source   */
   /* It deals with data month by month                                  */
   /**********************************************************************/
   PROCEDURE  Load_AR4_BU_Source(i_process_instance INTEGER, i_Bu VARCHAR2,  i_user VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_FromDttm TIMESTAMP, i_ToDttm TIMESTAMP, i_FORCE_INIT_SG VARCHAR2, i_DROP_INIT_SG VARCHAR2, i_last_dttm_stamp_sec TIMESTAMP, i_max_posted_date TIMESTAMP, where_clause VARCHAR2)
   IS
      my_new_treated      VARCHAR2(1);
      l_current           INTEGER := 1;
      l_test              INTEGER;
      err_num             INTEGER;
      err_msg             VARCHAR2(250);
      l_start_date        DATE;
      l_end_date          DATE;
      l_curr_start_date   DATE;
      l_curr_end_date     DATE;
      l_max_posted_date   TIMESTAMP;
      l_nb_boucle         INTEGER ;
      l_bu                VARCHAR2(10);
      l_total_numrows     INTEGER;
      l_numrows           INTEGER;
      l_last_dttm_stamp_sec  TIMESTAMP;
      l_month_step        INTEGER := 1;
      l_stop_flag         VARCHAR2(1);
	  l_partition         VARCHAR2(100);/* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
   BEGIN

      AddLog(i_process_instance, i_Bu, i_Source, i_log_msg, i_FromDttm, i_ToDttm, i_max_posted_date, 0, 'START Load_AR4_BU_Source - i_max_posted_date = '||i_max_posted_date, i_user);

      -- Follow up
      UPDATE PS_AR4_SCOPE_SG
      SET    msg_status_sg = 'I'
      WHERE  business_unit = i_Bu
      AND    SOURCE = i_Source;

      l_nb_boucle := 0;
      l_max_posted_date := i_max_posted_date ;
      l_last_dttm_stamp_sec := i_last_dttm_stamp_sec;

      l_start_date := i_FromDttm;
      -- l_start_date := TRUNC(i_FromDttm, 'MM');
      -- l_end_date := TRUNC(ADD_MONTHS(i_ToDttm,1), 'MM') - 1;
      l_end_date := i_ToDttm;

      l_curr_start_date := l_start_date;

      SELECT TO_NUMBER(string_text)
      INTO l_month_step
      FROM PS_STRINGS_TBL WHERE program_id = 'DLYRC_SG' AND string_id = 'STEP';

      l_curr_end_date := LEAST(TRUNC(ADD_MONTHS(l_start_date, l_month_step), 'MM'), l_end_date);
      -- l_curr_end_date := TRUNC(ADD_MONTHS(l_start_date, 1), 'MM') - 1;
	  
	  /* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
	  
	  SELECT string_text
	  INTO l_partition
	  FROM PS_STRINGS_TBL WHERE program_id = 'DLYRC_SG' AND string_id = 'PARTIAL_FLG'; 
	  
      /* End CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
	  
      /* The cleaning should be done if asked by user */
      IF i_DROP_INIT_SG = 'Y' THEN
         -- clean temporary table
         BEGIN
		 /* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
		  IF l_partition = 'Y' Then 
            EXECUTE IMMEDIATE 'alter table PS_AR4_JRNL_GRA_SG truncate subpartition AR4'||i_Bu ||i_Source ||'';
		  ELSE 
            DELETE FROM PS_AR4_JRNL_GRA_SG WHERE business_unit = i_Bu AND gl_source = i_Source;
            COMMIT;
           END IF;
		   /* End CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
         EXCEPTION
            WHEN OTHERS THEN
               AddLog(i_process_instance, i_Bu, i_Source, 'Y', l_start_date, l_end_date, l_max_posted_date, 0, 'Truncate PS_AR4_JRNL_GRA_SG KO - Delete instead', i_user);
            DELETE FROM PS_AR4_JRNL_GRA_SG WHERE business_unit = i_Bu AND gl_source = i_Source;
            COMMIT;
         END;
      END IF;

      IF i_FORCE_INIT_SG = 'Y' OR i_DROP_INIT_SG = 'Y' THEN
         -- clean aggregated table
         BEGIN
		  /* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
		  IF l_partition = 'Y' Then 
            EXECUTE IMMEDIATE 'alter table PS_AR4_AGG_GRA_SG truncate subpartition AR4'||i_Bu ||i_Source ||'';
		  ELSE
		  DELETE  FROM PS_AR4_AGG_GRA_SG WHERE business_unit = i_Bu AND gl_source = i_Source;      
          COMMIT;
          END IF;
		 /* End CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
         EXCEPTION
            WHEN OTHERS THEN
               AddLog(i_process_instance, i_Bu, i_Source, 'Y', l_start_date, l_end_date, l_max_posted_date, 0, 'Truncate PS_AR4_AGG_GRA_SG KO - Delete instead', i_user);
               DELETE PS_AR4_AGG_GRA_SG WHERE business_unit = i_Bu AND gl_source = i_Source;
               COMMIT;
         END;

         -- Think of a cleaning method in order to clean part of the table considering journal_date
         -- for example if I want to relaunch just one month

         UPDATE PS_AR4_SCOPE_SG
         SET    DROP_INIT_SG = 'N',
                NUMROWS = 0,
                MSG_STATUS_SG = 'D'
         WHERE  BUSINESS_UNIT = i_bu
         AND    SOURCE = i_Source;
      END IF;
      COMMIT;

      /* If INIT has never been done or User ask for recalculate */
      IF i_FORCE_INIT_SG = 'Y' /* OR i_last_dttm_stamp_sec IS NULL */ THEN
         l_total_numrows := 0;
         WHILE l_curr_start_date < l_end_date AND l_nb_boucle < CST_MAX_LOOP
         LOOP

            -- This parameter enable the "killing" of the process, the loop will go on without extracting data
            SELECT string_text
            INTO l_stop_flag
            FROM PS_STRINGS_TBL WHERE program_id = 'DLYRC_SG' AND string_id = 'STOP_FLAG';

            IF l_stop_flag <> 'Y' THEN
               l_last_dttm_stamp_sec := i_ToDttm;
               Ins_AR4_Period_m (i_process_instance, i_Bu, i_user, i_Source, i_log_msg, l_curr_start_date, l_curr_end_date, l_max_posted_date, l_last_dttm_stamp_sec, where_clause, l_numrows);
            END IF;
            l_total_numrows := l_total_numrows + l_numrows;

            -- as linux database is faster then we will launch extraction year per yer instead of month per month
            -- l_curr_start_date := ADD_MONTHS(l_curr_start_date,1);
            l_curr_start_date := ADD_MONTHS(l_curr_start_date, l_month_step);

            -- try the process using the first day of the following month instead of the last day of the current month
            l_curr_end_date := LEAST(TRUNC(ADD_MONTHS(l_curr_start_date, l_month_step), 'MM'), l_end_date);
            -- l_curr_end_date := LEAST(TRUNC(ADD_MONTHS(l_curr_start_date, 1), 'MM') - 1, l_end_date);
            l_nb_boucle := l_nb_boucle + 1;
         END LOOP;

         IF l_stop_flag <> 'Y' THEN
            Load_AGG_BU_Source(i_process_instance, i_Bu, i_Source, i_log_msg, i_user, l_numrows);
         END IF;

         -- set last execution time for BU and source
         UPDATE PS_AR4_SCOPE_SG
         SET    LAST_DTTM_STAMP = SYSTIMESTAMP,
                FORCE_INIT_SG = 'N',
                DROP_INIT_SG = 'N',
                FROM_DTTM6_I_SG = l_start_date,
                TO_DTTM6_I_SG = l_end_date,
                -- user date setup is cleaned after init, so the next run and the daily calc will be OK
                FROM_DTTM6_SG = NULL,
                TO_DTTM6_SG = NULL,
                NUMROWS = NVL(l_numrows, 0),
                MSG_STATUS_SG = 'S'
         WHERE  BUSINESS_UNIT = i_bu
         AND    SOURCE = i_Source
         AND    MSG_STATUS_SG <> 'E';
         COMMIT;

      END IF;

   EXCEPTION
      WHEN OTHERS THEN
         err_num := SQLCODE;
         err_msg := SUBSTR('ERROR Load_AR4_BU_Source ' || err_num||' - '|| SQLERRM, 1, 250);
         UPDATE PS_AR4_SCOPE_SG
         SET    msg_status_sg = 'E'
         WHERE  business_unit = i_Bu
         AND    SOURCE = i_Source;
         AddLog(i_process_instance, i_Bu , i_Source,  'Y', NULL, NULL, NULL, 0, err_msg , i_user);
   END;



   /**********************************************************************/
   /* This procedure deals with all source setup for a BU and a source   */
   /* It deals with daily posted data                                    */
   /**********************************************************************/
   PROCEDURE  Load_AR4_DLY_BU_Source(i_process_instance INTEGER, i_Bu VARCHAR2,  i_user VARCHAR2, i_Source VARCHAR2, i_log_msg VARCHAR2, i_FromDttm TIMESTAMP, i_ToDttm TIMESTAMP, i_calc_dly VARCHAR2, i_last_dttm_stamp_sec TIMESTAMP, i_max_posted_date DATE)
   IS
      l_test              INTEGER;
      err_num             INTEGER;
      err_msg             VARCHAR2(250);
      l_start_date        TIMESTAMP;
      l_end_date          TIMESTAMP;
      l_max_posted_date   DATE;
      V_NUMROWS           INTEGER := 0;
      l_bu                VARCHAR2(10);
      l_total_numrows     INTEGER;
      l_numrows           INTEGER;
      l_min_journal_dt    DATE;
      l_max_journal_dt    DATE;
      l_nb_retentiondays  INTEGER := 5;
   BEGIN

      l_max_posted_date := i_max_posted_date;

      -- if user sets the value then use it
      IF i_FromDttm IS NOT NULL THEN
         l_start_date := i_FromDttm;
      END IF;
      -- l_start_date := TRUNC(i_FromDttm, 'MM');
      -- l_end_date := TRUNC(ADD_MONTHS(i_ToDttm,1), 'MM') - 1;
      l_end_date := i_ToDttm;

      -- l_curr_start_date := l_start_date;
      -- l_curr_end_date := TRUNC(ADD_MONTHS(l_start_date, 1), 'MM') - 1;

      AddLog(i_process_instance, i_Bu, i_Source, i_log_msg ,  l_min_journal_dt, l_max_journal_dt, l_max_posted_date, V_NUMROWS, 'Start Load_AR4_DLY_BU_Source', i_user);

      -- the daily calculation is launched only if a global init has already been done
      IF i_calc_dly = 'Y' /* or i_last_dttm_stamp_sec IS NOT NULL */ THEN

         SELECT TO_NUMBER(string_text)
         INTO l_nb_retentiondays
         FROM PS_STRINGS_TBL WHERE program_id = 'DLYRC_SG' AND string_id = 'RETENTIONDAYS';

         -- start cleaning the data
         DELETE PS_AR4_DLY_GRA_SG WHERE business_unit = i_Bu AND gl_source = i_Source
         AND    LAST_DTTM_STAMP < SYSDATE - l_nb_retentiondays;

         -- if the process is relaunched, then the data should be cleaned before insert
         DELETE PS_AR4_DLY_GRA_SG WHERE business_unit = i_Bu AND gl_source = i_Source
         AND posted_date > l_start_date AND posted_date <= l_end_date;

         -- the min and max journal_date are calculated to avoid performance issues
         SELECT MIN(journal_date), MAX(journal_date)
         INTO l_min_journal_dt, l_max_journal_dt
         FROM  PS_JRNL_HEADER
         WHERE business_unit = i_Bu
         AND   SOURCE = i_Source
         AND   jrnl_hdr_status IN ('P', 'U')
         AND   DTTM_STAMP_SEC > l_start_date
         AND   DTTM_STAMP_SEC <= l_end_date;

         INSERT INTO PS_AR4_DLY_GRA_SG
            (business_unit, ACCOUNT, altacct, deptid, affiliate, object_code, PRODUCT, OPERATING_UNIT, BO_ID_SG,
             EVENT_NATURE ,
             foreign_amount, foreign_currency, gl_source, posted_date, fiscal_year, ACCOUNTING_PERIOD ,
             process_instance, LAST_DTTM_STAMP )
         SELECT
                  LN.BUSINESS_UNIT, LN.ACCOUNT, LN.ALTACCT, LN.DEPTID, LN.AFFILIATE, LN.OBJECT_CODE, LN.PRODUCT, LN.OPERATING_UNIT, LN.BO_ID_SG,
                  (CASE
                      WHEN HDR.SOURCE IN ('ARI','BZF','CAT','CFD','CTG','CYN','ENT','GMI','LNS','PEC','PLT','SIR','SPB','SPX','TAU','TAV','TPE','USG')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), ' ')
                      WHEN HDR.SOURCE = 'MPA' AND LN.BUSINESS_UNIT <> 'G2986'
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), ' ')
                      WHEN HDR.SOURCE IN ('CLS','CLT','FX1','LOA','OPS','QTZ','RFI','TES','TOP')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      WHEN HDR.SOURCE = 'BIR' AND LN.BUSINESS_UNIT NOT IN ('G0001','I0001')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      WHEN HDR.SOURCE = 'MPA' AND LN.BUSINESS_UNIT  = 'G2986'
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      WHEN HDR.SOURCE = 'BIR' AND LN.BUSINESS_UNIT IN ('G0001','I0001')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,7,3)), ' ')
                      WHEN HDR.SOURCE = 'PTS' AND LN.BUSINESS_UNIT  = 'G9297'
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      ELSE LN.OPERATION_CD_SG
                   END) AS EVENT_NATURE,
                 SUM(LN.FOREIGN_AMOUNT), LN.FOREIGN_CURRENCY, hdr.SOURCE, HDR.POSTED_DATE, HDR.FISCAL_YEAR, HDR.ACCOUNTING_PERIOD,
                   0, SYSTIMESTAMP
           FROM PS_JRNL_HEADER HDR,
                PS_JRNL_LN LN
           WHERE HDR.BUSINESS_UNIT = LN.BUSINESS_UNIT
           AND   HDR.JOURNAL_ID = LN.JOURNAL_ID
           AND   HDR.JOURNAL_DATE = LN.JOURNAL_DATE
           AND   HDR.UNPOST_SEQ = LN.UNPOST_SEQ
           AND   HDR.JRNL_HDR_STATUS IN ('P','U')
           AND   HDR.LEDGER_GROUP NOT IN ('INDIV', 'CNTRPARTY')
           AND   HDR.SOURCE = i_Source
           AND   HDR.BUSINESS_UNIT = I_BU
           -- MHE 17/09/2015 if the take perdio we will include duplicate data for comptes de bilan
           AND   HDR.ACCOUNTING_PERIOD NOT IN (0, 999)
           -- AND   HDR.POSTED_DATE > i_FromDttm
           AND   HDR.DTTM_STAMP_SEC > l_start_date
           AND   HDR.DTTM_STAMP_SEC <= l_end_date
           -- AND   HDR.POSTED_DATE <= l_max_posted_date
           AND   HDR.JOURNAL_DATE >= l_min_journal_dt
           AND   HDR.JOURNAL_DATE <= l_max_journal_dt
        GROUP BY LN.BUSINESS_UNIT, LN.ACCOUNT, LN.ALTACCT, LN.DEPTID, LN.AFFILIATE, LN.OBJECT_CODE, LN.PRODUCT, LN.OPERATING_UNIT, LN.BO_ID_SG,
                  (CASE
                      WHEN HDR.SOURCE IN ('ARI','BZF','CAT','CFD','CTG','CYN','ENT','GMI','LNS','PEC','PLT','SIR','SPB','SPX','TAU','TAV','TPE','USG')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), ' ')
                      WHEN HDR.SOURCE = 'MPA' AND LN.BUSINESS_UNIT <> 'G2986'
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,6,3)), ' ')
                      WHEN HDR.SOURCE IN ('CLS','CLT','FX1','LOA','OPS','QTZ','RFI','TES','TOP')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      WHEN HDR.SOURCE = 'BIR' AND LN.BUSINESS_UNIT NOT IN ('G0001','I0001')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      WHEN HDR.SOURCE = 'MPA' AND LN.BUSINESS_UNIT  = 'G2986'
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      WHEN HDR.SOURCE = 'BIR' AND LN.BUSINESS_UNIT IN ('G0001','I0001')
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,7,3)), ' ')
                      WHEN HDR.SOURCE = 'PTS' AND LN.BUSINESS_UNIT  = 'G9297'
                         THEN NVL(TRIM(SUBSTR(LN.OPERATION_CD_SG,9,3)), ' ')
                      ELSE LN.OPERATION_CD_SG
                   END), LN.FOREIGN_CURRENCY, hdr.SOURCE, HDR.POSTED_DATE, HDR.FISCAL_YEAR, HDR.ACCOUNTING_PERIOD;

        V_NUMROWS := SQL%ROWCOUNT;

        -- set last execution time for BU and source
        UPDATE PS_AR4_SCOPE_SG
        SET    LAST_DTTM_STAMP = SYSTIMESTAMP,
               FROM_DTTM6_SG = NULL,
               TO_DTTM6_SG = NULL,
               FROM_DTTM6_I_SG = l_start_date,
               TO_DTTM6_I_SG = l_end_date,--l_max_posted_date,
               NUMROWS = NVL(V_NUMROWS, 0),
               MSG_STATUS_SG = 'S'
        WHERE  BUSINESS_UNIT = i_bu
        AND    SOURCE = i_Source
        AND    MSG_STATUS_SG <> 'E';


   END IF;

   COMMIT;
   AddLog(i_process_instance, i_Bu, i_Source, i_log_msg, i_FromDttm, i_ToDttm, l_max_posted_date, V_NUMROWS, 'End Load_AR4_DLY_BU_Source', i_user);

   EXCEPTION
      WHEN OTHERS THEN
         err_num := SQLCODE;
         err_msg := SUBSTR('ERROR Load_AR4_BU_Source ' || err_num||' - '|| SQLERRM, 1, 250);
         UPDATE PS_AR4_SCOPE_SG
         SET    msg_status_sg = 'E'
         WHERE  business_unit = i_Bu
         AND    SOURCE = i_Source;
         AddLog(i_process_instance, i_Bu , i_Source,  'Y', NULL, NULL, NULL, 0, err_msg , i_user);
   END;


   /**********************************************************************/
   /* This procedure deals with all source setup for a BU                */
   /**********************************************************************/
   PROCEDURE Load_AR4_BU(i_process_instance INTEGER, i_Bu VARCHAR2, i_user VARCHAR2, i_runCntlId VARCHAR2)
   IS
      err_num             INTEGER;
      err_msg             VARCHAR2(250);
      l_dttm_from         TIMESTAMP;
      l_dttm_to           TIMESTAMP;
      l_max_posted_date   DATE;
	  l_partition         VARCHAR2(100); /* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */

      CURSOR cur_source
      IS
      SELECT ars.SOURCE, ars.FROM_DTTM6_SG, ars.TO_DTTM6_SG,
             ars.FORCE_INIT_SG, ars.DROP_INIT_SG, ars.CALC_DLY_SG, ars.LAST_DTTM_STAMP, ars.log_msg_sg,
             ars.FROM_DTTM6_I_SG, ars.TO_DTTM6_I_SG,
             DECODE(ars.DROP_INIT_SG||ars.FORCE_INIT_SG, 'YN', 0, DECODE(ars.DROP_INIT_SG, 'Y', 1, 2)) AS sort_field,
             ars.where_clause
      FROM   PS_AR4_SCOPE_SG ars
      WHERE  ars.BUSINESS_UNIT = i_Bu
      AND    (ars.FORCE_INIT_SG = 'Y' OR ars.DROP_INIT_SG = 'Y' OR ars.CALC_DLY_SG = 'Y')
      AND    ars.MSG_STATUS_SG IN (' ', 'S', 'E', 'D')
      AND    EXISTS (SELECT 1
                     FROM   PS_LST_ENTRY_DPT_ACC_DTM leda
                     WHERE  leda.business_unit = ars.business_unit
      AND    leda.SOURCE = ars.SOURCE)
      ORDER BY sort_field, ars.SOURCE;
   BEGIN
      FOR rec_source IN cur_source LOOP
	     AddLog(i_process_instance, i_Bu, rec_source.SOURCE, rec_source.log_msg_sg, NULL, NULL, NULL, 0, 'START Load_AR4_BU_Source', i_user );
		 
		 /* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
		 
		 SELECT string_text
		 INTO l_partition 
		 FROM PS_STRINGS_TBL WHERE program_id = 'DLYRC_SG' AND string_id = 'PARTIAL_FLG';
		 /* End CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
		 
		 /* Begin CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
		 IF l_partition='Y' THEN
         ManagePartition(i_process_instance, i_Bu, rec_source.SOURCE, 'PS_AR4_JRNL_GRA_SG');
         ManagePartition(i_process_instance, i_Bu, rec_source.SOURCE, 'PS_AR4_AGG_GRA_SG');
		 -- ManagePartition(i_process_instance, i_Bu, rec_source.SOURCE, 'PS_AR4_DLY_GRA_SG');
		 END IF;
		 /* End CO1479415, Kirankumar Karusala, 14/12/2015, [Daily RCG] Adapt package to deal with absence of subpartition in Seoul production */
		 
         

         /***************** EXTRACT INITIAL SNAPSHOT *******************/
         -- if the user sets a value, then it must be used
         IF rec_source.FROM_DTTM6_SG IS NOT NULL THEN
            l_dttm_from := rec_source.FROM_DTTM6_SG;
         ELSE
            -- If the user has already been launched then, get the info
            IF rec_source.FROM_DTTM6_I_SG IS NOT NULL THEN
               l_dttm_from := rec_source.FROM_DTTM6_I_SG;
            ELSE
               SELECT FROM_DTTM6_SG INTO l_dttm_from FROM PS_RUN_AE066_SG
               WHERE OPRID = i_user AND RUN_CNTL_ID = i_runCntlId;
            END IF;
         END IF;

          -- if user sets a value, then it must be used
          IF rec_source.TO_DTTM6_SG IS NOT NULL THEN
             l_dttm_to := rec_source.TO_DTTM6_SG;
             IF rec_source.TO_DTTM6_SG IS NOT NULL THEN
                l_dttm_to := rec_source.TO_DTTM6_SG;
             ELSE
                SELECT TO_DTTM6_SG INTO l_dttm_to FROM PS_RUN_AE066_SG WHERE OPRID = i_user AND RUN_CNTL_ID = i_runCntlId;
             END IF;
          END IF;

          SELECT AS_OF_DATE INTO l_max_posted_date FROM PS_RUN_AE066_SG WHERE OPRID = i_user AND RUN_CNTL_ID = i_runCntlId;

          Load_AR4_BU_Source(i_process_instance, i_Bu, i_user, rec_source.SOURCE, rec_source.log_msg_sg, l_dttm_from, l_dttm_to, rec_source.FORCE_INIT_SG, rec_source.DROP_INIT_SG, rec_source.LAST_DTTM_STAMP, l_max_posted_date, rec_source.where_clause);
          AddLog(i_process_instance, i_Bu, rec_source.SOURCE, rec_source.log_msg_sg, NULL, NULL, NULL, 0, 'END Load_AR4_BU_Source',  i_user );
          /**************************************************************/

          /***************** EXTRACT Daily Data *************************/
          IF rec_source.CALC_DLY_SG = 'Y' THEN
             IF rec_source.FROM_DTTM6_SG IS NOT NULL THEN
                l_dttm_from := rec_source.FROM_DTTM6_SG;
             ELSE
                -- If the user has already been launched then, get the info
                IF rec_source.TO_DTTM6_I_SG IS NOT NULL THEN
                   l_dttm_from := rec_source.TO_DTTM6_I_SG;
                   -- ELSE
                   -- SELECT TO_DTTM6_SG INTO l_dttm_from FROM PS_RUN_AE066_SG WHERE OPRID = i_user AND RUN_CNTL_ID = i_runCntlId;
                END IF;
             END IF;

             -- if user sets a value, then it must be used
             IF rec_source.TO_DTTM6_SG IS NOT NULL THEN
                l_dttm_to := rec_source.TO_DTTM6_SG;
             ELSE
                l_dttm_to := SYSTIMESTAMP;
             END IF;

            /* prevoir une gestion specifique des bornes d extraction si un on lance un init et un daily dans la foulee */
             Load_AR4_DLY_BU_Source(i_process_instance, i_Bu,  i_user, rec_source.SOURCE, rec_source.log_msg_sg, l_dttm_from, l_dttm_to, rec_source.CALC_DLY_SG, rec_source.LAST_DTTM_STAMP, l_max_posted_date);
         END IF;
         /**************************************************************/
      END LOOP;
   EXCEPTION
      WHEN OTHERS THEN
         err_num := SQLCODE;
         err_msg := SUBSTR('ERROR Load_AR4_BU ' || err_num||' - '|| SQLERRM, 1, 250);
         UPDATE PS_AR4_SCOPE_SG
         SET    msg_status_sg = 'E'
         WHERE  business_unit = i_Bu;
         AddLog(i_process_instance, i_Bu , 'ALL', 'Y', NULL, NULL, NULL, 0, err_msg , i_user);
   END;


   /**********************************************************************/
   /* This procedure deals with all BU of a group                        */
   /**********************************************************************/
   PROCEDURE Load_AR4_BU_GRP  (i_process_instance INTEGER, i_BUGrp VARCHAR2, i_reqdate DATE, i_user VARCHAR2, i_runCntlId VARCHAR2)
   IS
      my_new_treated      VARCHAR2(1);
      l_current           INTEGER := 1;
      l_test              INTEGER;
      err_num             NUMBER;
      err_msg             VARCHAR2(250);
      l_start_date        DATE;
      l_end_date          DATE;
      l_curr_start_date   DATE;
      l_curr_end_date     DATE;
      l_nb_boucle         INTEGER := 0;
      l_bu                VARCHAR2(10);
   BEGIN
      /* Loops on BU of a group except INDIV and ELIM BU */
      FOR l_bu IN (SELECT DISTINCT VWG.BUSINESS_UNIT
                   FROM
                     (SELECT VW.BUSINESS_UNIT
                      FROM   PS_BUS_UNIT_VW_SG VW
                      WHERE  BUSINESS_UNIT_GRP = i_BUGrp
                      AND    BUSINESS_UNIT NOT LIKE 'I%'
                      AND    BUSINESS_UNIT NOT LIKE 'E%'
                      UNION
                      SELECT BUSINESS_UNIT
                      FROM   PS_BUS_UNIT_TBL_FS
                       WHERE  BUSINESS_UNIT = i_BUGrp
                      ) VWG
                   WHERE  EXISTS (SELECT 1
                                  FROM   PS_AR4_SCOPE_SG  ARS
                                  WHERE  ARS.BUSINESS_UNIT = VWG.BUSINESS_UNIT)
                    )
      LOOP
         AddLog(i_process_instance, l_bu.business_unit , 'ALL', 'Y', NULL, NULL, NULL, 0, 'START Load_AR4_BU_GRP = ' || i_BUGrp, i_user);
         Load_AR4_BU(i_process_instance, l_bu.business_unit, i_user, i_runCntlId) ;
         AddLog(i_process_instance, l_bu.business_unit , 'ALL', 'Y', NULL, NULL, NULL, 0, 'END Load_AR4_BU_GRP = ' || i_BUGrp, i_user);
      END LOOP;

   EXCEPTION
      WHEN OTHERS THEN
         err_num := SQLCODE;
         err_msg := SUBSTR('ERROR Load_AR4_BU_GRP ' || err_num||' - '|| SQLERRM, 1, 250);
         AddLog(i_process_instance, i_BUGrp , 'ALL', 'Y', NULL, NULL, NULL, 0,'ERROR' || err_num||' - '||err_msg, i_user);
   END;

END;

-- fin du script
SET TIMI OFF;

SET FEEDBACK OFF;
select 'Fin du script ..' || TO_CHAR(SysDate,'DD/MM/YYYY HH:MI:SS ') todays_date from dual;
SET FEEDBACK ON;
spool off;
