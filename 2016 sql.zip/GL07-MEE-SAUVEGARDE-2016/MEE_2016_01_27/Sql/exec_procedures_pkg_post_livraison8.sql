-- Nom du script        : exec_procedures_pkg_post_livraison.sql
-- Cr�r par             : XXX
-- Application          : COE - GL
-- Valid� par           : MOE-MOE-HUB..

-- cr�ation du fichier log 
SET head OFF;
SET FEEDBACK OFF;
SET TIMI OFF;
spool spool.SQL;
SELECT  'spool  exec_procedures_pkg_post_livraison8-'||USER||'-'||TO_CHAR(SYSDATE,'YYYYMMDDHHMI')||'.log;' FROM    dual;
spool OFF;

--Variables d'environnements
SET head ON;
SET VERIFY OFF; 
SET HEAD OFF; 
SET LINESIZE 91; 
SET PAGESIZE 500;
SET TIMI OFF;
SET serveroutput ON SIZE unlimited;

--g�n�ration du fichier log
@spool;
SELECT 'Debut du script ..' || TO_CHAR(SYSDATE,'DD/MM/YYYY HH:MI:SS ') todays_date FROM dual;
  
-- sortie si erreur
WHENEVER SQLERROR EXIT -1 ROLLBACK;

SET timi ON;
SET FEEDBACK ON; 
-- debut du script
  
BEGIN
pkg_post_livraison.proc_create_public_synonyms();
END;
/
-- fin du script
SET timi OFF;

SET FEEDBACK OFF;
SELECT 'Fin du script ..' || TO_CHAR(SYSDATE,'DD/MM/YYYY HH:MI:SS ') todays_date FROM dual;
spool OFF;
