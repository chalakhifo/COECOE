
--For Seoul environment

SELECT 'CO1479415' as CO_NUM,'CO1479415 -[Daily RCG] Adapt package to deal with absence of subpartition in Seoul production' as DESCR, 'PS_STRINGS_TBL' as TABLENAME,(case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)   REMARKS  FROM PS_STRINGS_TBL WHERE program_id = 'DLYRC_SG' AND string_id = 'PARTIAL_FLG' AND STRING_TEXT='N';

SELECT 'CO1479415' as CO_NUM, 'CO1479415 -[Daily RCG] Adapt package to deal with absence of subpartition in Seoul production' as DESCR, 'PS_SCRIPT_SG'      as TABLENAME,(case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS   FROM  PS_SCRIPT_SG       WHERE CASE_ID='1479415';

