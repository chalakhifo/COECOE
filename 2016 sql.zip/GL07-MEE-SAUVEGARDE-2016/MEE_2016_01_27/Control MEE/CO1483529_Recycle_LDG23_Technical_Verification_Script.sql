----------BUSINESS UNIT SETUP TABLES--;

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_BUS_UNIT_TBL_GL' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_BUS_UNIT_TBL_GL WHERE business_unit ='LDG23';

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_BUS_UNIT_TBL_FS' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_BUS_UNIT_TBL_FS WHERE business_unit ='LDG23' AND DESCR = 'HORDLE FINANCE BV' AND DESCRSHORT = 'HORDLE';

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_BUS_UNIT_IDS_GL' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_BUS_UNIT_IDS_GL WHERE business_unit ='LDG23' AND STD_ID_NUM_QUAL = 'BD1' AND STD_ID_NUM = '10955603';

-----SETID --------------

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_SETID_TBL' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_SETID_TBL WHERE SETID ='LDG23' AND DESCR = 'HORDLE FINANCE BV' AND DESCRSHORT = 'HORDLE';



--------Business Unit Group------;

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_ME_RF_BU_GRP_SG' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_ME_RF_BU_GRP_SG WHERE BUSINESS_UNIT='LDG23' AND COMPANY_SG = '1R';

--------Sub Conso Setup----------;

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_SUB_CONSO_BU_SG' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_SUB_CONSO_BU_SG  WHERE cust_id_sg='10955603' AND BUSINESS_UNIT = 'LDG23' AND CONSOL_BUS_UNIT = 'S0682' AND CONSO_SG = 'IG' ;

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_SUB_CONSO_BU_SG' as tablename, (CASE WHEN COUNT(*) = 0  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_SUB_CONSO_BU_SG  WHERE cust_id_sg='193007' AND BUSINESS_UNIT = ' ' ;

--------BDR Client file Setup----------;

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'ps_soc_bdr_fcli_sg' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from ps_soc_bdr_fcli_sg where cust_id_sg='10955603' AND DESCR100 = 'HORDLE FINANCE BV' AND BUSINESS_UNIT = 'LDG23' AND DESCR_SG = 'HORDLE' AND ATTACHED_CONSO_SG = 'S0682';

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'ps_soc_bdr_fcli_sg' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from ps_soc_bdr_fcli_sg where cust_id_sg='193007' AND BUSINESS_UNIT = ' ';

--PS_SCRIPT_SG--;

select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'ps_script_sg' as tablename, (CASE WHEN COUNT(*) >= 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from PS_SCRIPT_SG where case_id='1483529';




----As of DAte Change for LDG46 in BUSINESS UNIT SETUP---;


select 'CO1483529' as CO_Num,'HORDLE UK Recycle LDG23 Light Set up' as Descr,'PS_BUS_UNIT_TBL_GL' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM  PS_BUS_UNIT_TBL_GL WHERE business_unit ='LDG46' AND AS_OF_DATE = '01-JAN-1900';

