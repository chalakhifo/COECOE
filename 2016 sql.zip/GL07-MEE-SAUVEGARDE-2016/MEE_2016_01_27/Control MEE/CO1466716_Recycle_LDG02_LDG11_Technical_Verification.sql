--BU Definition--;
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_BUS_UNIT_TBL_GL' as tablename, (CASE WHEN COUNT(*) = 2  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_BUS_UNIT_TBL_GL WHERE business_unit IN ('LDG02','LDG11');
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_BUS_UNIT_TBL_FS' as tablename, (CASE WHEN COUNT(*) = 2  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_BUS_UNIT_TBL_FS WHERE business_unit IN ('LDG02','LDG11') AND descr IN ('JWB Leasing Limited Partnershi','JWB Lease Holdings Limited');
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_BUS_UNIT_IDS_GL' as tablename, (CASE WHEN COUNT(*) = 6  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_BUS_UNIT_IDS_GL WHERE business_unit IN ('LDG02','LDG11') AND STD_ID_NUM IN ('S','EUMNY','129107895','135285380');

--LEDGER setup--;
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_BU_LED_TBL' as tablename, (CASE WHEN COUNT(*) = 6  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_BU_LED_TBL WHERE business_unit IN ('LDG02','LDG11');
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_BU_LED_GRP_TBL' as tablename, (CASE WHEN COUNT(*) = 4  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_BU_LED_GRP_TBL WHERE business_unit IN ('LDG02','LDG11') AND CALENDAR_ID='01';

--OPEN PERIOD UPDATE SETUP--
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_FIN_OPEN_PERIOD' as tablename, (CASE WHEN COUNT(*) = 24  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_FIN_OPEN_PERIOD WHERE business_unit IN ('LDG02','LDG11') AND CALENDAR_ID='01';

---SETID Setup ----
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_SETID_TBL' as tablename, (CASE WHEN COUNT(*) = 2  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_SETID_TBL WHERE setid IN ('LDG02','LDG11') AND descr IN ('JWB Leasing Limited Partnershi','JWB Lease Holdings Limited');

--------BDR Client file Setup----------;
--Inactivate Existing Customer ID--
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'ps_soc_bdr_fcli_sg' as tablename, (CASE WHEN COUNT(*) = 2  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM ps_soc_bdr_fcli_sg where cust_id_sg in ('1528205','3883747') AND BUSINESS_UNIT NOT IN ('LDG02','LDG11') AND CONSOL_STATUS_SG='I';
--Create New Customer ID--
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'ps_soc_bdr_fcli_sg' as tablename, (CASE WHEN COUNT(*) = 2  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM ps_soc_bdr_fcli_sg where cust_id_sg in ('129107895','135285380') AND BUSINESS_UNIT IN ('LDG02','LDG11');

--------Sub Conso Setup----------;
--Inactivate Existing Customer ID--
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_SUB_CONSO_BU_SG' as tablename, (CASE WHEN COUNT(*) = 0  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_SUB_CONSO_BU_SG where cust_id_sg in ('1528205','3883747') AND BUSINESS_UNIT IN ('LDG02','LDG11') AND EFF_STATUS='I';
--Create New Customer ID--
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_SUB_CONSO_BU_SG' as tablename, (CASE WHEN COUNT(*) = 2  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_SUB_CONSO_BU_SG where cust_id_sg in ('129107895','135285380') AND BUSINESS_UNIT IN ('LDG02','LDG11');

---Business Unit Group Setup ----
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_ME_RF_BU_GRP_SG' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_ME_RF_BU_GRP_SG WHERE BUSINESS_UNIT='LDG02' AND BUSINESS_UNIT_GRP ='SGUKA' AND COMPANY_SG='G5';
select 'CO1466716' as CO_Num,'[HERM UK] Recycle LDG02 and LDG11 entities - Light Setup' as Descr,'PS_ME_RF_BU_GRP_SG' as tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_ME_RF_BU_GRP_SG WHERE BUSINESS_UNIT='LDG11' AND BUSINESS_UNIT_GRP ='SGUKA' AND COMPANY_SG='HE';