select 'CO1375879' as CO_NUM,'SellDown Amount Management' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PSPROJECTDEFN  where projectname ='SG_LOT1043';

select 'CO1375879' as CO_NUM,'SellDown Amount Management' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PSMSGSETDEFN  where MESSAGE_SET_NBR = '20005';

select 'CO1375879' as CO_NUM,'SellDown Amount Management' as TABLENAME, (case when COUNT(*) = 3  then 'OK' else 'PROBLEM' end) REMARKS from PSMSGCATDEFN WHERE MESSAGE_SET_NBR = '20005' AND MESSAGE_NBR IN ('17','18','19'); 


