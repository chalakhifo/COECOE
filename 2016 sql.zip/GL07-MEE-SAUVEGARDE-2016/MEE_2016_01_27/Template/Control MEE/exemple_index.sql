spool 694140_Check_Raz_PnLs.log                        
@694140_Check_Raz_PnLs.sql             
spool 715050_Switch_User_Verification.log              
@715050_Switch_User_Verification.sql   
spool 738896_Check_TFA_Paris_Autre_Prov.log            
@738896_Check_TFA_Paris_Autre_Prov.sql 
spool 751028_BCT_LOT1.log                             
@751028_BCT_LOT1.sql                  
spool 762345_check_SPOT_file_integration.log           
@762345_check_SPOT_file_integration.sql
spool 781632_Check_TFA_IEC.log                         
@781632_Check_TFA_IEC.sql              
spool 783134_GHK01.log                                 
@783134_GHK01.sql                      
spool 790581_Evolan_UK.log                             
@790581_Evolan_UK.sql                  
spool 791508_BCT_Lot2.log                            
@791508_BCT_Lot2.sql                 
spool 810517_Check_Pivot_HK.log                        
@810517_Check_Pivot_HK.sql             
spool 811292_check_HKDLY_Rate_BDR.log                  
@811292_check_HKDLY_Rate_BDR.sql       
spool 813464_AMER_PVT_SMT_INTELLIMATCH.log             
@813464_AMER_PVT_SMT_INTELLIMATCH.SQL  
spool 813902_R2D2_Brasil.log                           
@813902_R2D2_Brasil.SQL                
spool 817052_BCT_Referential.log                       
@817052_BCT_Referential.sql            
spool 820143_AS_Securing.log                           
@820143_AS_Securing.sql                
spool 823272_LDG49.log                                 
@823272_LDG49.sql                      
spool Check_CO795189_Dormant.log                       
@Check_CO795189_Dormant.sql            
