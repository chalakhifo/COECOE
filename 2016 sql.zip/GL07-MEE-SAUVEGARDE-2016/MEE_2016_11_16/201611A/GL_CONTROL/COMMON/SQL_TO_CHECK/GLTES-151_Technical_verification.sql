INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-151' as CO_NUM, systimestamp, 'A', 'BALANCES PRIVATE DEPTID' as Descr, 'PS_SQLTEXTDEFN_SG' as tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' END) Remarks from PS_SQLTEXTDEFN_SG where SQLID like '%BALANCES PRIVATE DEPTID';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-151' as CO_NUM, systimestamp, 'A', 'BALANCES PRIVATE DEPTID' as Descr, 'PS_SQLCOLDEFN_SG' as tablename, ( CASE WHEN COUNT(*) = 8 THEN 'OK' ELSE 'KO' END) Remarks from PS_SQLCOLDEFN_SG where SQLID like '%BALANCES PRIVATE DEPTID';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-151' as CO_NUM, systimestamp, 'A', 'BALANCES PRIVATE DEPTID' as Descr, 'PS_SQLVALUESET_SG' as tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' END) Remarks from PS_SQLVALUESET_SG where SQLID like '%BALANCES PRIVATE DEPTID';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-151' as CO_NUM, systimestamp, 'A', 'BALANCES PRIVATE DEPTID' as Descr, 'PS_SQLPARMVALUE_SG' as tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' END) Remarks from PS_SQLPARMVALUE_SG where SQLID like '%BALANCES PRIVATE DEPTID';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-151' as CO_NUM, systimestamp, 'A', 'BALANCES PRIVATE DEPTID' as Descr, 'PS_SQL_RUN_LINE_SG' as tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' END) Remarks from PS_SQL_RUN_LINE_SG where  OPRID = 'BATCHAA' and RUN_CNTL_ID = 'SG_QRY_CHK_07H30' AND SQLID like '%BALANCES PRIVATE DEPTID';


COMMIT;
/

