 
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201611A', 'GLTES-216' as CO_Num, systimestamp, 'A', ' [SUP] Issue on the GL pivot selection criteria when adding account' as Descr, 'PSPROJECTDEFN' as tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTDEFN WHERE PROJECTNAME = 'SG_LOT1078';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201611A', 'GLTES-216' as CO_Num, systimestamp, 'A', ' [SUP] Issue on the GL pivot selection criteria when adding account' as Descr, 'PSPROJECTITEM' as tablename, ( CASE WHEN COUNT(*) = 4 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTITEM WHERE PROJECTNAME = 'SG_LOT1078';



COMMIT;

/