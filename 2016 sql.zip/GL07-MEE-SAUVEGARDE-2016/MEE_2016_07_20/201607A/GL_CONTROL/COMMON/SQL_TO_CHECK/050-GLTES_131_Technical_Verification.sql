INSERT INTO ps_mee_check_sg (release_id_sg, co_num_sg, exec_time, status, descr_control,context_sg, results) SELECT '201607A', 'GLTES-131' AS co_num, SYSTIMESTAMP, 'A', 'GLTES-131 - [DODD FRANK V2]' AS descr,'PS_JL_FLDS_LOG_SG' AS tablename,(CASE WHEN COUNT (*) = 0 THEN 'OK' ELSE 'KO' END) remarks FROM ps_jrnl_header WHERE jrnl_hdr_status IN ('P', 'U') AND (business_unit, journal_id, unpost_seq) NOT IN (
 SELECT business_unit, journal_id, unpost_seq FROM ps_jl_flds_log_sg);

