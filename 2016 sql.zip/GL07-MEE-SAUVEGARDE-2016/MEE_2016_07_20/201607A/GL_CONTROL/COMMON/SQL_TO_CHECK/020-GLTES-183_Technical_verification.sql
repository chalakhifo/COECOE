INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201607A',  'GLTES-183' as CO_Num,systimestamp, 'A','Update the url of the ME template' as Descr,'PSPROJECTDEFN'as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTDEFN  where projectname ='SG_LOT1063';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201607A',  'GLTES-183' as CO_Num,systimestamp, 'A','Update the url of the ME template' as Descr,'PSPROJECTITEM'as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTITEM  where projectname ='SG_LOT1063';
COMMIT;
/

