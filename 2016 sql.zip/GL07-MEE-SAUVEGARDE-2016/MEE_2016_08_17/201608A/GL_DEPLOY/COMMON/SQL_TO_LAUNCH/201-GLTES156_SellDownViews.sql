---------------- Create views ------------------------;
-- PROJET : GLTES-156 Early Sell Down                 ;
-- SUJET : Create views                               ;
-- TITRE : 201-GLTES156_SellDownViews.sql             ;
-- DATE : 28/06/2016                                  ;
-- AUTEUR : Mahmoud HEBBACHE                          ;
-- DESCR : Create views for Early sell down lot 1     ;
---------------- Create views ------------------------;

WHENEVER SQLERROR CONTINUE;

CREATE OR REPLACE VIEW PS_CES_DEPT_VW_SG
(BUSINESS_UNIT, SETID, DEPTID, SELLDOWN_RATE, SPOT_RATE, 
 AFF_USE_SG, AFFILIATE, FIL_SNSQUOT_USE_SG, FISCAL_YEAR, ACCOUNTING_PERIOD, 
 TRSCES_SG, EARLY_SLD_SG, APPROVE_FLAG, EXTRACT_FLAG_SG)
AS 
SELECT distinct dpt.BUSINESS_UNIT , dpt.SETID , dpt.DEPTID , dpt.SELLDOWN_RATE , dpt.SPOT_RATE , bu.AFF_USE_SG , bu.AFFILIATE , bu.FIL_SNSQUOT_USE_SG , 
       bu.FISCAL_YEAR , bu.ACCOUNTING_PERIOD , dpt.TRSCES_SG , dpt.APPROVE_FLAG , dpt.EXTRACT_FLAG_SG , dpt.EARLY_SLD_SG 
  FROM PS_CESSION_BU_SG bu , PS_CES_DEPT_BU_SG dpt 
 WHERE dpt.business_unit = bu.business_unit
/

CREATE OR REPLACE VIEW PS_CES_RATE_DPT_VW
(SETID, BUSINESS_UNIT, FISCAL_YEAR, ACCOUNTING_PERIOD, DEPTID, TRSCES_SG, RT_TYPE)
AS 
SELECT DISTINCT setid ,business_unit ,FISCAL_YEAR ,ACCOUNTING_PERIOD ,deptid , trsces_sg ,SPOT_RATE 
FROM PS_CES_DEPT_VW_SG 
WHERE selldown_rate = SPOT_RATE
/

CREATE OR REPLACE VIEW PS_AL_CS_SPX_VW_SG
(BUSINESS_UNIT, FISCAL_YEAR, ACCOUNTING_PERIOD, TRSCES_SG, DEPTID, 
 PROD_TYPE_SG, PRODUCT, OBJECT_CODE, CURRENCY_CD, TOT_SPX_CESS_SG, PROCESS_INSTANCE, POSTED_BASE_AMT, SEQ_NUM)
AS 
SELECT B.BUSINESS_UNIT , A.FISCAL_YEAR , A.ACCOUNTING_PERIOD , A.TRSCES_SG , B.DEPTID , B.PROD_TYPE_SG ,' ' AS PRODUCT ,' ' AS OBJECT_CODE , B.CURRENCY_CD , (SUM (A.TOT_SPX_CESS_SG) * (SUM (B.AMOUNT ) / SUM (F.AMOUNT ))) MNT , A.PROCESS_INSTANCE ,0 AS POSTED_BASE_AMT , A.SEQ_NUM 
FROM PS_LED_CONF_CES_SG A , PS_AL_CS_SPB_VW_SG B , PS_SET_CNTRL_REC D , PS_AL_CS_SPBS_VWSG F , PS_CES_DEPT_VW_SG C 
WHERE A.CURRENCY_CD = B.CURRENCY_CD AND A.BUSINESS_UNIT = B.BUSINESS_UNIT AND A.FISCAL_YEAR = B.FISCAL_YEAR AND A.TRSCES_SG = B.TRSCES_SG 
  AND A.TRSCES_SG = F.TRSCES_SG AND A.ACCOUNTING_PERIOD = B.ACCOUNTING_PERIOD AND F.AMOUNT <> 0 AND C.BUSINESS_UNIT = A.BUSINESS_UNIT 
  AND C.DEPTID = A.DEPTID AND C.TRSCES_SG = A.TRSCES_SG AND C.FISCAL_YEAR = A.FISCAL_YEAR AND C.ACCOUNTING_PERIOD = A.ACCOUNTING_PERIOD 
  AND C.SETID = D.SETID AND F.CURRENCY_CD = B.CURRENCY_CD AND B.BUSINESS_UNIT = F.BUSINESS_UNIT AND D.SETCNTRLVALUE = A.BUSINESS_UNIT 
  AND D.RECNAME = 'DEPT_TBL' 
GROUP BY B.PROD_TYPE_SG, B.DEPTID, B.CURRENCY_CD, B.BUSINESS_UNIT, A.TRSCES_SG, A.FISCAL_YEAR , A.ACCOUNTING_PERIOD,A.PROCESS_INSTANCE , A.SEQ_NUM 
HAVING SUM (F.AMOUNT) <> 0 ORDER BY 1,2,3,4,5
/

CREATE OR REPLACE VIEW PS_ALCES_TRA_VW_SG
(BUSINESS_UNIT, FISCAL_YEAR, ACCOUNTING_PERIOD, TRSCES_SG, SEQ_NUM, 
 DEPTID, ACCOUNT, ALTACCT, AFFILIATE, PROD_TYPE_SG, 
 PRODUCT, OBJECT_CODE, CURRENCY_CD, SELLDOWN_CURR_AMT, RT_TYPE, 
 RATE_MULT, RATE_DIV, EFFDT, BASE_CURRENCY, SELLDOWN_BASE_AMT)
AS 
SELECT a.business_unit , a.fiscal_year , a.accounting_period , a.trsces_sg , a.seq_num , a.deptid , f.account_2 AS ACCOUNT , 
       DECODE (a.business_unit , 'G0001' , f.altacct_2 , ' ') AS altacct , b.affiliate , a.prod_type_sg , 
       DECODE (a.business_unit , 'G0001' , f.product , 'G5000' , f.product , ' ' ) AS product , a.object_code , a.currency_cd , 
       a.tot_rep_cess_sg AS amount_cession_cur , b.selldown_rate AS rt_type , e.rate_mult , e.rate_div , e.effdt , c.base_currency , 
       (a.tot_rep_cess_sg * e.rate_mult / e.rate_div ) AS amount_cession_bas 
       FROM PS_LED_CES_ALC_SG a , PS_CES_DEPT_VW_SG b , PS_BUS_UNIT_TBL_GL c , PS_RT_RATE_TBL e , PS_CES_PROD_SG_TBL f , PS_SET_CNTRL_GROUP g 
       WHERE a.business_unit = b.business_unit AND a.fiscal_year = b.fiscal_year AND a.accounting_period = b.accounting_period 
       AND a.trsces_sg = b.trsces_sg AND a.business_unit = c.business_unit AND g.setcntrlvalue = a.business_unit 
       AND g.rec_group_id = 'GL_03' AND f.setid = g.setid AND a.prod_type_sg = f.prod_type_sg AND b.selldown_rate = b.spot_rate 
       AND b.selldown_rate = e.rt_type AND e.effdt = ( SELECT MAX (f.effdt) FROM PS_RT_RATE_TBL f WHERE e.rt_rate_index = f.rt_rate_index AND e.term = f.term AND e.from_cur = f.from_cur AND e.to_cur = f.to_cur AND e.rt_type = f.rt_type AND f.effdt < (TRUNC (ADD_MONTHS (TO_DATE ( a.accounting_period || '-' || a.fiscal_year, 'MM-YYYY' ), 2 ), 'MM' ) )) AND a.currency_cd = e.from_cur AND c.base_currency = e.to_cur 
UNION 
SELECT /*+ ordered */ a.business_unit , a.fiscal_year , a.accounting_period , a.trsces_sg , a.seq_num , a.deptid , f.account_2 AS ACCOUNT , 
       DECODE (a.business_unit , 'G0001' , f.altacct_2 , ' ') AS altacct , b.affiliate , a.prod_type_sg , 
       DECODE (a.business_unit , 'G0001' , f.product , 'G5000' , f.product , ' ' ) AS product , a.object_code , a.currency_cd , 
       a.tot_rep_cess_sg AS amount_cession_cur , b.selldown_rate AS rt_type , e.rate_mult , e.rate_div , h.effdt , c.base_currency , 
       (a.tot_rep_cess_sg * e.rate_mult / e.rate_div ) AS amount_cession_bas 
FROM PS_LED_CES_ALC_SG a , PS_CES_DEPT_VW_SG b , PS_BUS_UNIT_TBL_GL c , PS_CES_PROD_SG_TBL f , PS_SET_CNTRL_GROUP g , PS_RT_RATE_TBL e , PS_RT_RATE_TBL h 
WHERE a.business_unit = b.business_unit AND a.fiscal_year = b.fiscal_year AND a.accounting_period = b.accounting_period AND a.trsces_sg = b.trsces_sg 
  AND a.business_unit = c.business_unit AND g.setcntrlvalue = a.business_unit AND g.rec_group_id = 'GL_03' AND f.setid = g.setid 
  AND a.prod_type_sg = f.prod_type_sg AND b.selldown_rate <> b.spot_rate AND b.selldown_rate = e.rt_type 
  AND e.effdt = ( SELECT MAX (f.effdt) FROM PS_RT_RATE_TBL f WHERE e.rt_rate_index = f.rt_rate_index AND e.term = f.term 
  AND e.from_cur = f.from_cur AND e.to_cur = f.to_cur AND e.rt_type = f.rt_type AND f.effdt < (TRUNC (ADD_MONTHS (TO_DATE ( a.accounting_period || '-' || a.fiscal_year, 'MM-YYYY' ), 1 ), 'MM' ) )) 
  AND a.currency_cd = e.from_cur AND c.base_currency = e.to_cur AND b.spot_rate = h.rt_type 
  AND h.effdt = ( SELECT MAX (f.effdt) FROM PS_RT_RATE_TBL f WHERE h.rt_rate_index = f.rt_rate_index 
  AND h.term = f.term AND h.from_cur = f.from_cur AND h.to_cur = f.to_cur AND h.rt_type = f.rt_type 
  AND f.effdt < (TRUNC (ADD_MONTHS (TO_DATE ( a.accounting_period || '-' || a.fiscal_year, 'MM-YYYY' ), 2 ), 'MM' ) )) 
  AND a.currency_cd = h.from_cur AND c.base_currency = h.to_cur
/

CREATE OR REPLACE VIEW PS_AL_CS_SPBS_VWSG
(CURRENCY_CD, BUSINESS_UNIT, TRSCES_SG, AMOUNT, FISCAL_YEAR)
AS 
SELECT A.CURRENCY_CD , A.BUSINESS_UNIT , A.TRSCES_SG , SUM (A.APPROV_AMT_CESS_SG) BASIS_AMOUNT , A.FISCAL_YEAR 
FROM PS_LED_CONF_CES_SG A , PS_CES_DEPT_VW_SG C 
WHERE A.FISCAL_YEAR = C.FISCAL_YEAR AND A.ACCOUNTING_PERIOD = C.ACCOUNTING_PERIOD AND A.BUSINESS_UNIT = C.BUSINESS_UNIT AND A.TRSCES_SG = C.TRSCES_SG 
GROUP BY A.CURRENCY_CD , A.BUSINESS_UNIT , A.FISCAL_YEAR ,A.TRSCES_SG 
HAVING SUM (A.APPROV_AMT_CESS_SG) <> 0
/

CREATE OR REPLACE VIEW PS_AL_CS_SPBS_VWSG
(CURRENCY_CD, BUSINESS_UNIT, TRSCES_SG, AMOUNT, FISCAL_YEAR)
AS 
SELECT A.CURRENCY_CD , A.BUSINESS_UNIT , A.TRSCES_SG , SUM (A.APPROV_AMT_CESS_SG) BASIS_AMOUNT , A.FISCAL_YEAR 
FROM PS_LED_CONF_CES_SG A , PS_CES_DEPT_VW_SG C 
WHERE A.FISCAL_YEAR = C.FISCAL_YEAR AND A.ACCOUNTING_PERIOD = C.ACCOUNTING_PERIOD AND A.BUSINESS_UNIT = C.BUSINESS_UNIT AND A.TRSCES_SG = C.TRSCES_SG GROUP BY A.CURRENCY_CD , A.BUSINESS_UNIT , A.FISCAL_YEAR ,A.TRSCES_SG 
HAVING SUM (A.APPROV_AMT_CESS_SG) <> 0
/
CREATE OR REPLACE VIEW PS_CESSION_SPX_VW2
(OPRID, BUSINESS_UNIT, DEPTID, TRSCES_SG)
AS 
SELECT DISTINCT A.oprid , b.business_unit , B.DEPTID ,A.trsces_sg 
FROM PS_CESSION_SECU_SG A , PS_CES_DEPT_BU_SG B 
WHERE A.trsces_sg = B.trsces_sg
/

CREATE OR REPLACE VIEW PS_AL_CS_SPB_VW_SG
(PROD_TYPE_SG, CURRENCY_CD, DEPTID, TRSCES_SG, AMOUNT, 
 BUSINESS_UNIT, FISCAL_YEAR, ACCOUNTING_PERIOD)
AS 
SELECT A.PROD_TYPE_SG , A.CURRENCY_CD , A.DEPTID , A.TRSCES_SG , SUM( A.APPROV_AMT_CESS_SG ) Basis_Amount , A.BUSINESS_UNIT , A.FISCAL_YEAR , A.ACCOUNTING_PERIOD 
FROM PS_LED_CONF_CES_SG A , PS_CES_DEPT_VW_SG B 
WHERE A.BUSINESS_UNIT = B.BUSINESS_UNIT AND A.FISCAL_YEAR = B.FISCAL_YEAR AND A.ACCOUNTING_PERIOD = B.ACCOUNTING_PERIOD AND A.TRSCES_SG = B.TRSCES_SG GROUP BY A.PROD_TYPE_SG , A.CURRENCY_CD , A.DEPTID , A.TRSCES_SG , A.BUSINESS_UNIT , A.FISCAL_YEAR , A.ACCOUNTING_PERIOD 
HAVING SUM( A.APPROV_AMT_CESS_SG ) <> 0
/

CREATE OR REPLACE VIEW PS_ALCES_COL_VW_SG
(BUSINESS_UNIT, FISCAL_YEAR, ACCOUNTING_PERIOD, TRSCES_SG, SEQ_NUM, 
 DEPTID, ACCOUNT, ALTACCT, AFFILIATE, PROD_TYPE_SG, 
 PRODUCT, OBJECT_CODE, CURRENCY_CD, SELLDOWN_CURR_AMT, RT_TYPE, 
 RATE_MULT, RATE_DIV, EFFDT, BASE_CURRENCY, SELLDOWN_BASE_AMT)
AS 
SELECT y.business_unit , y.fiscal_year , y.accounting_period , y.trsces_sg , y.seq_num , y.deptid , w.account_2 AS ACCOUNT , DECODE (y.business_unit , 'G0001' , altacct_2 , ' ') AS altacct , y.affiliate , y.prod_type_sg , y.product , y.object_code , y.currency_cd , y.amount_cession_cur , y.rt_type , y.rate_mult , y.rate_div , y.effdt , y.base_currency , y.amount_cession_bas
 FROM ( SELECT a.business_unit , a.fiscal_year , a.accounting_period , a.trsces_sg , a.seq_num , b.deptid , b.affiliate , a.prod_type_sg , a.product , a.object_code , a.currency_cd , -SUM (a.tot_rep_cess_sg) AS amount_cession_cur , b.selldown_rate AS rt_type , z.rate_mult , z.rate_div , z.effdt , x.base_currency , - (SUM (a.tot_rep_cess_sg) * z.rate_mult / z.rate_div ) AS amount_cession_bas 
        FROM PS_LED_CES_ALC_SG a , PS_CES_DEPT_VW_SG b , PS_BUS_UNIT_TBL_GL x , PS_RT_RATE_TBL z 
        WHERE a.business_unit = b.business_unit AND a.fiscal_year = b.fiscal_year AND a.accounting_period = b.accounting_period 
        AND a.trsces_sg = b.trsces_sg AND b.business_unit = a.business_unit AND a.business_unit = x.business_unit AND b.selldown_rate = b.spot_rate 
        AND b.selldown_rate = z.rt_type AND z.effdt = ( SELECT MAX (f.effdt) 
                                                        FROM PS_RT_RATE_TBL f 
                                                        WHERE z.rt_rate_index = f.rt_rate_index AND z.term = f.term AND z.from_cur = f.from_cur 
                                                        AND z.to_cur = f.to_cur AND z.rt_type = f.rt_type 
                                                        AND f.effdt < (TRUNC (ADD_MONTHS (TO_DATE ( a.accounting_period || '-' || a.fiscal_year, 'MM-YYYY' ), 2 ), 'MM' ) )) AND a.currency_cd = z.from_cur AND x.base_currency = z.to_cur 
        GROUP BY a.business_unit, a.fiscal_year, a.accounting_period, a.trsces_sg, a.seq_num, b.deptid, b.affiliate, a.prod_type_sg, a.product, a.object_code, a.currency_cd, b.selldown_rate, z.rate_mult, z.rate_div, x.base_currency, z.effdt 
        UNION 
        SELECT /*+ ordered */ a.business_unit , a.fiscal_year , a.accounting_period ,a.trsces_sg , a.seq_num , b.deptid , b.affiliate , a.prod_type_sg , a.product , a.object_code , a.currency_cd , -SUM (a.tot_rep_cess_sg) AS amount_cession_cur , b.selldown_rate AS rt_type , z.rate_mult , z.rate_div , h.effdt , x.base_currency , - (SUM (a.tot_rep_cess_sg) * z.rate_mult / z.rate_div ) AS amount_cession_bas 
        FROM PS_LED_CES_ALC_SG a , PS_CES_DEPT_VW_SG b , PS_BUS_UNIT_TBL_GL x , PS_RT_RATE_TBL z , PS_RT_RATE_TBL h 
        WHERE a.business_unit = b.business_unit AND a.fiscal_year = b.fiscal_year AND a.accounting_period = b.accounting_period AND a.trsces_sg = b.trsces_sg 
          AND b.business_unit = a.business_unit AND a.business_unit = x.business_unit AND b.selldown_rate <> b.spot_rate 
          AND b.selldown_rate = z.rt_type AND z.effdt = ( SELECT MAX (f.effdt) 
                                                          FROM PS_RT_RATE_TBL f 
                                                          WHERE z.rt_rate_index = f.rt_rate_index AND z.term = f.term AND z.from_cur = f.from_cur AND z.to_cur = f.to_cur AND z.rt_type = f.rt_type 
                                                          AND f.effdt < (TRUNC (ADD_MONTHS (TO_DATE ( a.accounting_period || '-' || a.fiscal_year, 'MM-YYYY' ), 1 ), 'MM' ) )) AND a.currency_cd = z.from_cur AND x.base_currency = z.to_cur AND b.spot_rate = h.rt_type 
                                                          AND h.effdt = ( SELECT MAX (f.effdt) FROM PS_RT_RATE_TBL f WHERE h.rt_rate_index = f.rt_rate_index AND h.term = f.term AND h.from_cur = f.from_cur AND h.to_cur = f.to_cur AND h.rt_type = f.rt_type 
                                                          AND f.effdt < (TRUNC (ADD_MONTHS (TO_DATE ( a.accounting_period || '-' || a.fiscal_year, 'MM-YYYY' ), 2 ), 'MM' ) )) AND a.currency_cd = h.from_cur AND x.base_currency = h.to_cur 
                                                          GROUP BY a.business_unit, a.fiscal_year, a.accounting_period, a.trsces_sg, a.seq_num, b.deptid, b.affiliate, a.prod_type_sg, a.product, a.object_code, a.currency_cd, z.rt_type, b.selldown_rate, z.rate_mult, z.rate_div, x.base_currency, h.effdt) y, 
        PS_CES_PROD_SG_TBL w, PS_SET_CNTRL_GROUP g 
        WHERE y.business_unit = g.setcntrlvalue AND g.rec_group_id = 'GL_03' AND g.setid = w.setid AND w.dflt = 'Y'
/


INSERT INTO PS_SCRIPT_SG (CASE_ID, RUNDTTM, FILENAME_SG, DESCR100, VERSION_CHAR, DMS_OPRID_SG, APPROVAL_OPRID)
 VALUES (156, sysdate, '202-SellDownCreateView.sql', 'Create views for Early SellDown', 'V1.0', 'mahmoud.hebbache', 'mahmoud.hebbache');

COMMIT
/
