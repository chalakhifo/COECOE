---------------- Create views ------------------------;
-- PROJET : GLTES-156 Early Sell Down                 ;
-- SUJET : Create views                               ;
-- TITRE : 200-GLTES156_Alter_ces_dept_bu_sg.sql             ;
-- DATE : 28/06/2016                                  ;
-- AUTEUR : Mahmoud HEBBACHE                          ;
-- DESCR : Create views for Early sell down lot 1     ;
---------------- Create views ------------------------;
WHENEVER SQLERROR CONTINUE;

DECLARE
   l_nb_myObject INTEGER; 
   l_str_sql     VARCHAR2(4000) := ' ';   
BEGIN
   
   SELECT COUNT(1) INTO l_nb_myObject FROM all_objects WHERE object_name = 'PS_CESSION_BU_SG';
   
   IF l_nb_myObject = 0 THEN 
      -- create table if it does not exist
      l_str_sql :=              ' CREATE TABLE PS_CESSION_BU_SG (';
      l_str_sql := l_str_sql || '   BUSINESS_UNIT       VARCHAR2(5 BYTE)          NOT NULL,';
      l_str_sql := l_str_sql || '   AFF_USE_SG          VARCHAR2(1 BYTE)          NOT NULL,';
      l_str_sql := l_str_sql || '   AFFILIATE           VARCHAR2(5 BYTE)          NOT NULL,';
      l_str_sql := l_str_sql || '   FIL_SNSQUOT_USE_SG  VARCHAR2(1 BYTE)          NOT NULL,';
      l_str_sql := l_str_sql || '   FISCAL_YEAR         INTEGER                   NOT NULL,';
      l_str_sql := l_str_sql || '   ACCOUNTING_PERIOD   INTEGER                   NOT NULL';
      l_str_sql := l_str_sql || ' )';
      l_str_sql := l_str_sql || ' TABLESPACE GLLARGE';

	  
      EXECUTE IMMEDIATE l_str_sql;
      
	  DBMS_OUTPUT.PUT_LINE ('Create table ps_cession_bu_sg : '||l_str_sql);
  	  
      l_str_sql := 'INSERT INTO PS_CESSION_BU_SG (BUSINESS_UNIT, AFF_USE_SG, AFFILIATE, FIL_SNSQUOT_USE_SG, FISCAL_YEAR, ACCOUNTING_PERIOD) ';
	  l_str_sql := l_str_sql || ' SELECT DISTINCT BUSINESS_UNIT, AFF_USE_SG, AFFILIATE, FIL_SNSQUOT_USE_SG, FISCAL_YEAR, ACCOUNTING_PERIOD FROM PS_CES_DEPT_BU_SG ';
      EXECUTE IMMEDIATE l_str_sql;
	  
      COMMIT;
	  
	  DBMS_OUTPUT.PUT_LINE ('Fill data : '||l_str_sql);
      
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;
   
   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'EARLY_SLD_SG';
   IF l_nb_myObject = 0 THEN 
      
      -- add column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG ADD EARLY_SLD_SG VARCHAR2(1)';      
      EXECUTE IMMEDIATE l_str_sql;
      l_str_sql :=              '       UPDATE PS_CES_DEPT_BU_SG SET EARLY_SLD_SG = ''N''';
	  EXECUTE IMMEDIATE l_str_sql;
	  COMMIT;
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG MODIFY EARLY_SLD_SG NOT NULL';      
      EXECUTE IMMEDIATE l_str_sql;
            
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;
   
   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'FISCAL_YEAR';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN FISCAL_YEAR ';      
      EXECUTE IMMEDIATE l_str_sql;	            
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;

   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'ACCOUNTING_PERIOD';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN ACCOUNTING_PERIOD ';      
      EXECUTE IMMEDIATE l_str_sql;          
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;      

   /* MHE 28/06/2016 Not necessary anymore due to G9353 setup START 
   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'SELLDOWN_RATE';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN SELLDOWN_RATE ';      
      EXECUTE IMMEDIATE l_str_sql;          
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;     

   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'SPOT_RATE';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN SPOT_RATE ';      
      EXECUTE IMMEDIATE l_str_sql;          
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;   
   MHE 28/06/2016 Not necessary anymore due to G9353 setup END */
   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'AFF_USE_SG';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN AFF_USE_SG ';      
      EXECUTE IMMEDIATE l_str_sql;          
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF; 

   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'AFFILIATE';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN AFFILIATE ';      
      EXECUTE IMMEDIATE l_str_sql;          
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;    
   
   SELECT COUNT(1) INTO l_nb_myObject FROM all_tab_columns WHERE table_name = 'PS_CES_DEPT_BU_SG' AND column_name = 'FIL_SNSQUOT_USE_SG';
   IF l_nb_myObject > 0 THEN 
      
      -- drop column if it does not exist
      l_str_sql :=              ' ALTER TABLE PS_CES_DEPT_BU_SG DROP COLUMN FIL_SNSQUOT_USE_SG ';      
      EXECUTE IMMEDIATE l_str_sql;          
   ELSE 
      -- write alter sql if necessary;
      NULL; 
   END IF;      
   
END;