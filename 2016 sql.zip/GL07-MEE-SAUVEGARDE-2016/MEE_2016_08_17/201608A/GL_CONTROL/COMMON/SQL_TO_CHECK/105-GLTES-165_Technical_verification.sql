-----------------------------------------------------------------------------------------------;
--PROJECT DEFN :;
-----------------------------------------------------------------------------------------------;
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201608A',  'GLTES-165' as CO_Num,systimestamp, 'A','Automation of thin key migration' as Descr,'PSPROJECTDEFN'as tablename, (CASE WHEN COUNT(*) = 1   THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTDEFN  where projectname ='SG_LOT1066';

-----------------------------------------------------------------------------------------------;
--PROJECT ITEMS :;
-----------------------------------------------------------------------------------------------;
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201608A',  'GLTES-165' as CO_Num,systimestamp, 'A','Automation of thin key migration' as Descr,'PSPROJECTITEM'as tablename, (CASE WHEN COUNT(*) = 5   THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTITEM  where projectname ='SG_LOT1066';

