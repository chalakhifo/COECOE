 
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-221' as CO_Num, systimestamp, 'A', '[Early Sell Down] Lot 2 Full Fonctionnality' as Descr, 'PSPROJECTDEFN' as tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTDEFN WHERE PROJECTNAME = 'SG_LOT1068';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-221' as CO_Num, systimestamp, 'A', '[Early Sell Down] Lot 2 Full Fonctionnality' as Descr, 'PSPROJECTITEM' as tablename, ( CASE WHEN COUNT(*) = 94 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTITEM WHERE PROJECTNAME = 'SG_LOT1068';



COMMIT;

/