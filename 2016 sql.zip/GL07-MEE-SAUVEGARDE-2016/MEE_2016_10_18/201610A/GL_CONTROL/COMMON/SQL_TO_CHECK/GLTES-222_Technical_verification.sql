INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-222' as CO_Num, systimestamp, 'A', 'Update the URL of ME Template' as Descr, 'PSPROJECTDEFN' as tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTDEFN WHERE PROJECTNAME = 'SG_LOT1063';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-222' as CO_Num, systimestamp, 'A', 'Update the URL of ME Template' as Descr, 'PSPROJECTITEM' as tablename, ( CASE WHEN COUNT(*) = 2 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTITEM WHERE PROJECTNAME = 'SG_LOT1063';

COMMIT;
/

