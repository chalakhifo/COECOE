INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-186' as CO_Num, systimestamp, 'A', '[SUP] RFI Extract Modification' as Descr, 'PSPROJECTDEFN' as tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTDEFN WHERE PROJECTNAME= 'SG_LOT1074';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201610A', 'GLTES-186' as CO_Num, systimestamp, 'A', '[SUP] RFI Extract Modification' as Descr, 'PSPROJECTITEM' as tablename, ( CASE WHEN COUNT(*) = 72 THEN 'OK' ELSE 'KO' END) Remarks from PSPROJECTITEM WHERE PROJECTNAME= 'SG_LOT1074';

Commit;
/
