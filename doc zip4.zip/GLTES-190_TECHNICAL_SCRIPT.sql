INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201608A', 'GLTES-190' as CO_Num, systimestamp, 'A', 'New check control for Monthly Asian FX Rates' as Descr, 'PS_PARAM_BATCH_SG' as tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks from from PS_PARAM_BATCH_SG where SESSION_SG = 'COEJAAASRF' and UPROC_SG = 'COELRRATEM' and PARAM_ID='ASAAA_SOIR-WARN';

Commit;

/