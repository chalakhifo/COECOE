select * from  PS_RUN_CNTL_PAR_SG  where run_cntl_id = �SG_MAN5_EXTRACT_PCRM';
select * FROM PS_UPROC_SG WHERE  RUN_CNTL_ID = 'SG_MAN5_EXTRACT_PCRM';
