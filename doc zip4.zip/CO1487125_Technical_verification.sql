SELECT 'GLTES-83' as JIRA_ID,'[SUP] PS_ME_PROCESSED_SG  Active_only flag' as DESCR,'PS_ME_PRCSAC_VW_SG' as 
VIEWNAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end)    REMARKS  FROM PSPROJECTDEFN WHERE PROJECTNAME='SG_LOT1048';

SELECT 'GLTES-83' as JIRA_ID,'[SUP] PS_ME_PROCESSED_SG  Active_only flag' as DESCR,'PS_ME_PRCSAC_VW_SG' as 
VIEWNAME, (case when count(*) = 0  then 'OK' else 'PROBLEM' end) REMARKS FROM PS_ME_PRCSAC_VW_SG where file_id_sg NOT IN  ( select A.file_id_sg  FROM PS_ME_PROCESSED_SG A 
  , PS_ME_BU_STATUS_SG B 
  , PS_ME_RF_BU_GRP_SG E 
  ,ps_me_file_load_sg mfl 
 WHERE A.business_unit = E.business_unit 
   AND b.business_unit_grp= e.business_unit_grp 
   AND A.file_id_sg = mfl.file_id_sg 
   AND A.business_unit = mfl.business_unit
   AND a.sched_prcs_date_sg = b.sched_prcs_date_sg);
   