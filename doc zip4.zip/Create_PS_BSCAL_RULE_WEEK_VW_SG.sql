CREATE OR REPLACE VIEW PS_BSCAL_RULE_WEEK_VW_SG
(RULE_NAME_SG, DAY_ORDER, DAY_NAME, RULE_DAY_OPEN, RULE_STATUS_SG)
AS 
SELECT rul.rule_name_sg, l_row AS day_order
     , CASE WHEN l_row = 1 THEN 'MONDAY'
            WHEN l_row = 2 THEN 'TUESDAY'
            WHEN l_row = 3 THEN 'WEDNESDAY'
            WHEN l_row = 4 THEN 'THURSDAY'
            WHEN l_row = 5 THEN 'FRIDAY'
            WHEN l_row = 6 THEN 'SATURDAY'
            WHEN l_row = 7 THEN 'SUNDAY'
            ELSE 'OTHERS'
       END day_name
     , CASE WHEN l_row = 1 THEN week_monday
            WHEN l_row = 2 THEN week_tuesday
            WHEN l_row = 3 THEN week_wednesday
            WHEN l_row = 4 THEN week_thursday
            WHEN l_row = 5 THEN week_friday
            WHEN l_row = 6 THEN week_saturday
            WHEN l_row = 7 THEN week_sunday
            ELSE 'N'
       END rule_day_open
     , rul.rule_status_sg
  FROM PS_BSCAL_RL_CAL_SG rul
       CROSS JOIN ( SELECT LEVEL AS l_row FROM DUAL CONNECT BY LEVEL <= 7 )
/