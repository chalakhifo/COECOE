SELECT * from PSPROJECTDEFN  where projectname ='SG_LOT1063';

SELECT * from PSPROJECTITEM  where projectname ='SG_LOT1063';

