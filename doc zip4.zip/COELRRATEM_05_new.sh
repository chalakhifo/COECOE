#!/bin/ksh
# #############################################################################
# DESCRIPTION
#   Load Monthly Rates for entities
#
# RELEASES
#   29/05/2007 JL GOGUET - Creation
#   02/08/2011 M LLOPIS  - X Computation Process (AE099_SG) for HK / NY rates
#
# #############################################################################

# Init. Librairie Fonctions
. ${HOME}/app/shell/upr_lib.sh || return 3

# -----------------------------------------------------------------------------
# Envoi d'un mail d'alerte a NY
# -----------------------------------------------------------------------------
SEND_MAIL_TO_USERS()
{
 typeset mail_type=$1

 typeset sender

 case ${ID_ENV_BATCH} in
 prd) # Production
      sender="PRODUCTION-COE@noreply-`hostname`"
      ;;
 prf) # Performance
      sender="PERFORMANCE-COE@noreply-`hostname`"
      ;;
 *)   # Others
      sender="TEST-COE@noreply-`hostname`"
      ;;
 esac

 # generation d'un mail d'alerte
 typeset mail_file=${BASE_ARBORESCENCE}/${S_PROCEXE}/out/mailfile_${S_DATRAIT}_$$.txt

 echo "" > ${mail_file}
 echo "At lest one monthly rate file is missing." >> ${mail_file}

 echo ""  >> ${mail_file}
 echo "This is an automatic mail."  >> ${mail_file}

 case ${mail_type} in
 WARNING)
    echo "Another mail will be sent when the cut-off will be reached !" >> ${mail_file}
    ;;

 ERROR)
    echo "`date '+%H:%M'` Cut-off reached." >> ${mail_file}

    if [ "A${FAIL_IF_MISSING_FILE}" = "AYES" ]
    then
      echo "The process is no longer running." >> ${mail_file}
      echo "Process failure required. Batch stream stopped !" >> ${mail_file}
    else
      echo "Process failure not required. Batch stream continue !" >> ${mail_file}
    fi
    ;;

 *)
    ;;
 esac

 echo "" >> ${mail_file}
 echo "Regards," >> ${mail_file}
 echo "APF team" >> ${mail_file}
 echo "" >> ${mail_file}

 # Envoi du mail au differents destinataires
 WRITE_LOG Y I "Sending mail report to the mailing list <missing_rate_file_${ZONE}>"

 typeset subject="`date '+%d-%m-%Y %H:%M:%S'` - ALERT ${mail_type} - Monthly ${ZONE} rates file missing"

 for addr in `cat ${PARTAGE}/env/coe_list_mail_dest.dat | grep "^${ID_ENV_BATCH}:missing_rate_file_${ZONE}:" | awk -F: '{print $3}' `
 do
   WRITE_LOG Y I "Sending mail to : ${addr}"

   cat ${mail_file} | mailx -r "${sender}" -s "${subject}" ${addr}

   [ $? -ne 0 ] &&  WRITE_LOG Y E "Failed to send mail to ${addr}"

 done

 return 0
}

# -----------------------------------------------------------------------------
# Rename File Function
# -----------------------------------------------------------------------------
RENAME_FILE()
{
 typeset filename=$1
 typeset suffix=$2

 mv ${filename} ${filename}${suffix}

 if [ $? -ne 0 ]
 then
   WRITE_LOG Y E "Unable to rename file"
   WRITE_LOG Y E "Source : ${filename}"
   WRITE_LOG Y E "Target : ${filename}${suffix}"

   return 3
 fi

 return 0
}

# -----------------------------------------------------------------------------
# Code
# -----------------------------------------------------------------------------
WRITE_LOG Y I "Step ${Iscn} - Loading monthly rate Files"

typeset continue_looping 
typeset rate_file_suffix=`eval echo '${'${S_CODSESS}_FILE_SUFF'}' `

REST_VAR Y LOAD_FILE_DAY Y
[ $? -ne 0 ] && return 3

WRITE_LOG Y I "Rate suffix used : ${rate_file_suffix}"

LIST_RATE_ZONE=`eval echo '${'${S_PROCEXE}_LIST_RATE_ZONE${rate_file_suffix}'}' `

WRITE_LOG Y I "Loading rate file for : ${LIST_RATE_ZONE}"

FAIL_IF_MISSING_FILE=`eval echo '${'${S_PROCEXE}_FAIL_IF_MISSING_FILE${rate_file_suffix}'}' `

WRITE_LOG Y I "Fail if file missing : ${FAIL_IF_MISSING_FILE}"

[ "A${COELRRATEM_SLEEP_TIME}" = "A" ] && COELRRATEM_SLEEP_TIME=120

WRITE_LOG N I "Sleep time : ${COELRRATEM_SLEEP_TIME}"

typeset continue_looping=Y
typeset sent_warn_mail=N

# Traitement des Fichiers
while [ "A${continue_looping}" = "AY" ]
do
  missing_rate_file=N
  
  for rate_zone in ${LIST_RATE_ZONE}
  do

    eval export TMP_VALUE='${'${S_PROCEXE}_RATE_SRC_FILE_M_${rate_zone}'}'
    EOP_PUBLISHF_SRC_FILE=`eval ls -t ${TMP_VALUE}|head -1`

    EOP_PUBLISHF_FLAG_FILE=${PARTAGE}/scheduler/flag/${ID_ENV_BATCH}/EOP_PUB_RT_${S_DATRAIT}_${rate_zone}_MTH${rate_file_suffix}.flag

    # Test des fichiers sans suffixe
    if [ "A${EOP_PUBLISHF_SRC_FILE}" != "A" ]
    then
      # Rename des fichiers
      RENAME_FILE ${EOP_PUBLISHF_SRC_FILE} ${rate_file_suffix}
      [ $? -ne 0 ] && return 3
    fi

    # Test des fichiers avec suffixe en cas d'echec au 1er test
    # ou pour valider les rename
    export EOP_PUBLISHF_IN_FILE=${EOP_PUBLISHF_SRC_FILE}${rate_file_suffix}

    if [ -f ${EOP_PUBLISHF_FLAG_FILE} ]
    then
       WRITE_LOG N I "Rate file already loaded for ${rate_zone}" 
    else
 
      # Test de presence du fichier de taux
      if [ ! -s ${EOP_PUBLISHF_IN_FILE} ]
      then
        WRITE_LOG N I "Missing rate file for ${rate_zone}"
        missing_rate_file=Y
      else
        # Fichier Existe et Non Traite
        WRITE_LOG Y I "Processing rate file for ${rate_zone}"
        WRITE_LOG Y I "${EOP_PUBLISHF_IN_FILE}"

        # fichier de taux mensuel recu
        if [ "A${LOAD_FILE_DAY}" = "ANO" ]
        then
          WRITE_LOG Y E "Not a good day to receive ${EOP_PUBLISHF_IN_FILE} "
          return 3
        fi

        WRITE_LOG Y I "Writing right required for EOP PUB, changing right on rate file"

        # passage du fichier en lecture/ecriture pour l'EOP publish
        chmod 666 ${EOP_PUBLISHF_IN_FILE}
        if [ $? -ne 0 ]
        then
          WRITE_LOG Y I "Failed to change unix right 666 on ${EOP_PUBLISHF_IN_FILE}, copying file "

          cp ${EOP_PUBLISHF_IN_FILE} ${EOP_PUBLISHF_IN_FILE}.$$
          if [ $? -ne 0 ]
          then
            WRITE_LOG Y E "failed to cp ${EOP_PUBLISHF_IN_FILE} ${EOP_PUBLISHF_IN_FILE}.$$ "
            return 3
          fi

          # passage du fichier en lecture/ecriture pour l'EOP publish
          chmod 666 ${EOP_PUBLISHF_IN_FILE}.$$
          if [ $? -ne 0 ]
          then
            WRITE_LOG Y I "Failed to change unix right 666 on ${EOP_PUBLISHF_IN_FILE}.$$ "
            return 3
          fi

          mv ${EOP_PUBLISHF_IN_FILE} ${EOP_PUBLISHF_IN_FILE}.$$.ori
          if [ $? -ne 0 ]
          then
            WRITE_LOG Y E "failed to mv ${EOP_PUBLISHF_IN_FILE} ${EOP_PUBLISHF_IN_FILE}.$$.ori"
            return 3
          fi

          mv ${EOP_PUBLISHF_IN_FILE}.$$ ${EOP_PUBLISHF_IN_FILE}
          if [ $? -ne 0 ]
          then
            WRITE_LOG Y E "failed to mv ${EOP_PUBLISHF_IN_FILE}.$$ ${EOP_PUBLISHF_IN_FILE}"
            return 3
          fi

        fi
        
        # Identify the process by using ${rate_zone}
        case "A${rate_zone}" in
        AAS|AHK|ANY)
          WRITE_LOG N I "Rate Zone=${rate_zone} - EOP_PUBLISHF replaced by AE099_SG"

          RUNCNTLID=SG_RATE_${rate_zone}_MTH
          PRCSNAME=AE099_SG

          LAUNCH_SQL Y BATCH update_PS_LOAD_RATE_SG ${RUNCNTLID} ${EOP_PUBLISHF_IN_FILE}
          [ $? -ne 0 ] && return 3
          ;;

        A??)
          RUNCNTLID=SG_EOP_PUB_RT_${rate_zone}_MTH
          PRCSNAME=EOP_PUBLISHF

          LAUNCH_SQL Y BATCH update_PS_EO_FLOINDEFN ${RUNCNTLID} ${EOP_PUBLISHF_IN_FILE}
          [ $? -ne 0 ] && return 3
          ;;

        *) WRITE_LOG Y E "Rate Zone [${rate_zone}] not supported."
           return 3
           ;;
        esac

        # Launch the process
        AE_STD NONE YES NO
        [ $? -ne 0 ] && return 3

        # Creation Fichier Flag Deja Traite pour ne pas Recharger le Fichier Indefiniment
        touch ${EOP_PUBLISHF_FLAG_FILE}

      fi
    fi
  done

  if [ "A${missing_rate_file}" != "AY" ]
  then
    continue_looping=N
  else

    # Test d'envoi du mail d'alarme
    TEST_DB_TIME_RANGE N WARN "${BUSINESS_UNIT}${rate_file_suffix}-WARN" 600 Y N
    [ $? -ne 0 ] && return 3

    if [ "A${WARN_INSIDE_RANGE}" = "AN" ] && [ "A${sent_warn_mail}" = "AN" ]
    then
      WRITE_LOG Y W "Reached end of warn time and process still locking"

      SEND_MAIL_TO_USERS WARNING
      [ $? -ne 0 ] && return 3

      sent_warn_mail=Y
    fi

    # test de la periode de bouclage
    TEST_DB_TIME_RANGE N NONE ${BUSINESS_UNIT}${rate_file_suffix} 300 N Y
    [ $? -ne 0 ] && return 3

    if [ "A${INSIDE_RANGE}" = "AN" ]
    then
      WRITE_LOG Y I "Reached end of loop time"
      continue_looping=N

      SEND_MAIL_TO_USERS ERROR
      [ $? -ne 0 ] && return 3
    else
      WRITE_LOG N I "Missing rate file, sleeping ${COELRRATEM_SLEEP_TIME} sec."
      sleep  ${COELRRATEM_SLEEP_TIME}
    fi
  fi

done

if [ "A${missing_rate_file}" = "AY" ]
then

   # fichier de taux mensuel non recu
   if [ "A${LOAD_FILE_DAY}" = "AYES" ]
   then
     if [ "A${FAIL_IF_MISSING_FILE}" = "AYES" ]
     then
       # Files not received and not a regular day : Skipping processes
       if [ -f ${FLAG_SKIP_REFRESH_IF_NEEDED} ]
       then
         WRITE_LOG Y W "Some required files are missing but Skip Refresh Flag exists"
         WRITE_LOG Y W "Skip Processes of this uproc."
         return 2
       else
         WRITE_LOG Y E "Some required files are missing. Process Stopped !"
         return 3
       fi
     else
       WRITE_LOG Y W "Missing monthly rate file"
       WRITE_LOG Y W "Monthly rate load skipped"
       WRITE_LOG Y W "Process ${S_PROCEXE} OK"
       return 2
     fi
   else
     WRITE_LOG Y I "Monthly rate file does not exists"
     WRITE_LOG Y I "Monthly rate load skipped"
     WRITE_LOG Y I "Process ${S_PROCEXE} OK"
     return 2
   fi
fi

return 0
