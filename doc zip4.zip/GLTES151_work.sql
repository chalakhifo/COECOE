---- Requetes GLTES151
---- New_morning_check

---- requete donn�e par Hugues dans le JIRA

SELECT l.deptid,
  s.estabid,
  l.business_unit,
  SUM(l.ytd_base_amt),
  SUM(l.ytd_tran_amt),
  l.currency_cd
FROM ps_ledger_dtm l,
  ps_dept_sav_sg s,
  ps_ledger_setid_dtm d
WHERE l.fiscal_year            = 2016
AND l.accounting_period        =6
AND l.ledger                  <> 'REPLOC'
AND l.business_unit            = d.business_unit
AND l.ledger                   = d.ledger
AND l.deptid                   = s.deptid
AND s.setid                    = d.dept_setid
AND (s.deptid, s.estabid) NOT IN
  (SELECT a.deptid,
    a.estabid
  FROM ps_dept_tbl_dtd a,
    ps_dept_1_sg_dtd b
  WHERE a.setid = b.setid
  AND a.deptid  = b.deptid
  )
GROUP BY l.business_unit,
  l.deptid,
  s.estabid,
  l.currency_cd
HAVING NOT(SUM(l.ytd_tran_amt) = 0
AND SUM(l.ytd_base_amt)        = 0)
ORDER BY l.deptid,
  s.estabid,
  l.business_unit;

-- table des requ�tes SQL
-- with BATCHAA swith user
-- APF Support Control Processes > Daily Monitoring > Use > SQL Definition

select * from ps_SQLTEXTDEFN_SG
order by 1;

-- les CHK et les DET vont jusqu'� 125 inclus
-- je prends le creneau 126

-- CHK126-Balances on Private DEPTID
-- DET126-Balances on Private DEPTID

select * from ps_dept_sav_sg;
-- ps_dept_sav_sg table is to define in SAV and emergency new DEPTID that should be created in the days after in the referential
-- it is maintained manually (it was cleaned by GLTES-48)
-- it contains the private deptid
-- usually we should not have any accounting entries on these deptid but sometimes the deptid isn't created in referential 
-- and at this moment there is a desynchronisation between the GL values and the referential deptid values.


select * from ps_dept_1_sg_dtd;


SELECT L.DEPTID,
  S.ESTABID,
  L.BUSINESS_UNIT,
  SUM(L.YTD_BASE_AMT),
  SUM(L.YTD_TRAN_AMT),
  L.CURRENCY_CD
FROM PS_LEDGER_DTM L,
  PS_DEPT_SAV_SG S,
  PS_LEDGER_SETID_DTM D
WHERE L.FISCAL_YEAR            =  EXTRACT (YEAR FROM ADD_MONTHS(:00,-D.CAL_OFFSET))
AND L.ACCOUNTING_PERIOD        = EXTRACT (MONTH FROM ADD_MONTHS(:00,-D.CAL_OFFSET))
AND L.LEDGER                  <> 'REPLOC'
AND L.BUSINESS_UNIT            = D.BUSINESS_UNIT
AND L.LEDGER                   = D.LEDGER
AND L.DEPTID                   = S.DEPTID
AND S.SETID                    = D.DEPT_SETID
AND (S.DEPTID, S.ESTABID) NOT IN
  (SELECT A.DEPTID,
    A.ESTABID
  FROM PS_DEPT_TBL_DTD A,
    PS_DEPT_1_SG_DTD B
  WHERE A.SETID = B.SETID
  AND A.DEPTID  = B.DEPTID
  )
GROUP BY L.BUSINESS_UNIT,
  L.DEPTID,
  S.ESTABID,
  L.CURRENCY_CD
HAVING NOT(SUM(L.YTD_TRAN_AMT) = 0
AND SUM(L.YTD_BASE_AMT)        = 0)
ORDER BY L.DEPTID,
  S.ESTABID,
  L.BUSINESS_UNIT;


-- 
select * from ps_SQLTEXTDEFN_SG where SQLID like 'CHK126%' ;

select * from ps_SQLVALUESET_SG where SQLID like 'CHK126%';

select * from ps_SQLPARMVALUE_SG where SQLID like 'CHK126%';

select * from ps_SQLCOLDEFN_SG where SQLID like 'CHK126%';

select * from ps_SQLTEXTDEFN_SG where SQLID like 'DET126%' ;

select * from ps_SQLVALUESET_SG where SQLID like 'DET126%';

select * from ps_SQLPARMVALUE_SG where SQLID like 'DET126%';

select * from ps_SQLCOLDEFN_SG where SQLID like 'DET126%';

select * from ps_SQLTEXTINFO_SG where SQLID like '%126%';




