INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A', 'NEFA Inactivation' as Descr , 'PS_ME_RF_BU_GRP_SG' as Tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_ME_RF_BU_GRP_SG  where dt_fin_efft_sg = '18-APR-16' AND business_unit IN ('G0402', 'I0402');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A', 'NEFA Inactivation' as Descr , 'PS_UGB_CHAINE_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_UGB_CHAINE_SG  WHERE business_unit = 'G0402' AND DOL_U_UNIT_GEST_SG in ('SGEUA','SGEU2');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A','NEFA Inactivation' as Descr , 'PS_SUB_CONSO_BU_SG' as Tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_SUB_CONSO_BU_SG WHERE  eff_status = 'I' AND business_unit IN ('G0402', 'I0402'); 

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A', 'NEFA Inactivation' as Descr , 'PS_RAN_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_RAN_SG WHERE business_unit IN ('G0402', 'I0402');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A', 'Inactivation' as Descr , 'PS_SOC_BDR_FCLI_SG' as Tablename, ( CASE WHEN COUNT(*) = 1 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_SOC_BDR_FCLI_SG WHERE eff_status = 'I' AND cust_id_sg IN (SELECT cust_id_sg FROM ps_bdr_bus_vw_sg WHERE business_unit IN ('G0402', 
'I0402'));


INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A','NEFA Inactivation' as Descr , 'PS_RECO_TRS_CRE_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks from  PS_RECO_TRS_CRE_SG where business_unit  IN ('G0402','I0402');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A','NEFA Inactivation' as Descr , 'PS_RUN_RCN_CRE_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_RUN_RCN_CRE_SG where business_unit IN ('G0402','I0402');

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A','NEFA Inactivation' as Descr , 'ps_close_request' as Tablename, ( CASE WHEN COUNT(*) = 3 THEN 'OK' ELSE 'KO' END) Remarks FROM ps_close_request WHERE business_unit IN ('G0402', 'I0402') and Process_Frequency = 'N' ;


INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A','NEFA Inactivation' as Descr , 'PS_RUN_AE083_BU_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_RUN_AE083_BU_SG where  BUSINESS_UNIT IN ('G0402','I0402') and OPRID = 'BATCHSGEU';


INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT '201604A',  'GLTES-133' as CO_Num, systimestamp, 'A','NEFA Inactivation' as Descr , 'PS_RUN_AE082_SG' as Tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks FROM PS_RUN_AE082_SG Where  BUSINESS_UNIT IN ('G0402','I0402');


COMMIT;
/