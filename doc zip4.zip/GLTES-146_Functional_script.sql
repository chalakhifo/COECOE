
select * from PS_SOURCE_TBL where source = 'ONE';
select * from PS_SQLDEFN_SG where SQLID in('INTERNES_MTM_PARIS','SG_EXTRACT_BO_JNRL','SG_EXT_DEAL_ID_IEC','SG_EXT_DEAL_ID_SG_PM');