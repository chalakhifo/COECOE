/*******************************************/
/* SCRIPT FOR GLTES-227                    */
/* Valerie Delay                           */
/* 15-SEPT-2016                            */
/*******************************************/


-- The aim : delete from PS GLAPF Tables the object_code with special charaters : ";" "," "|"

-- 85 rows on PRD base the 15/09/2016
/*select * from PS_OBJECTC_BDR_SG 
where (object_code like ('%;%') or object_code like('%|%') or object_code like('%,%'))
;*/

delete from PS_OBJECTC_BDR_SG 
where (object_code like ('%;%') or object_code like('%|%') or object_code like('%,%'))
;

-- 158 rows on PRD base the 15/09/2016
/*select * from PS_CHARTF1_TBL_EDT
where (object_code like ('%;%') or object_code like('%|%') or object_code like('%,%')) order by 2
;*/

delete from PS_CHARTF1_TBL_EDT
where (object_code like ('%;%') or object_code like('%|%') or object_code like('%,%'))
;

-- 158 rows on PRD the 15/09/2016
/*select * from PS_CF_ATTR_TBL_EDT where FIELDNAME = 'OBJECT_CODE' 
and (CHARTFIELD_VALUE like ('%;%') or CHARTFIELD_VALUE like ('%|%') or CHARTFIELD_VALUE like ('%,%'))
;*/

delete from PS_CF_ATTR_TBL_EDT where FIELDNAME = 'OBJECT_CODE' 
and (CHARTFIELD_VALUE like ('%;%') or CHARTFIELD_VALUE like ('%|%') or CHARTFIELD_VALUE like ('%,%'))
;

--85 rows on PRD the 15/09/2016
/*select * from PS_CHARTFIELD1_TBL 
where (object_code like ('%;%') or object_code like('%|%') or object_code like('%,%'))
;*/

delete from PS_CHARTFIELD1_TBL 
where (object_code like ('%;%') or object_code like('%|%') or object_code like('%,%'))
;

--85 rows on PRD the 15/09/2016
/*select * from PS_CF_ATTRIB_TBL 
where (CHARTFIELD_VALUE like ('%;%') or CHARTFIELD_VALUE like ('%|%') or CHARTFIELD_VALUE like ('%,%'))
;*/

delete from PS_CF_ATTRIB_TBL 
where (CHARTFIELD_VALUE like ('%;%') or CHARTFIELD_VALUE like ('%|%') or CHARTFIELD_VALUE like ('%,%'))
;