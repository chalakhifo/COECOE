create or replace 
TRIGGER FEED_JRNLLN_CUSTOM_FIELDS_SG
 BEFORE UPDATE OF JRNL_HDR_STATUS ON PS_JRNL_HEADER
 REFERENCING NEW AS NEW OLD AS OLD
 FOR EACH ROW
DECLARE
  l_indic     INTEGER;
  l_indic_NY  INTEGER;
  l_begindttm DATE;
  l_rdj_dt    DATE;
  l_updlines  NUMBER;
  l_BO_DT_SG  DATE;
  l_AUDIT_OPRID VARCHAR2(64);
BEGIN
  -- This completion on JRNL_LN is triggered only once the journal is posted or unposted
  IF :NEW.JRNL_HDR_STATUS IN ('P', 'U')
  THEN
      -- For any standard file the RDJ_DT_SG is compulsory.
      -- A null BO_DT_SG on line 1 indicates that it is a system generated journal (RVM, CLO etc.) and needs completion.
      SELECT COUNT(BO_DT_SG), MIN(RDJ_DT_SG) INTO l_indic, l_rdj_dt
      FROM   PS_JRNL_LN
      WHERE  BUSINESS_UNIT = :NEW.BUSINESS_UNIT
      AND    JOURNAL_ID    = :NEW.JOURNAL_ID
      AND    JOURNAL_DATE  = :NEW.JOURNAL_DATE
      AND    UNPOST_SEQ    = :NEW.UNPOST_SEQ
      AND    JOURNAL_LINE  = 1;

      IF l_indic = 0
      THEN
         l_begindttm := SYSDATE;
         DBMS_APPLICATION_INFO.READ_CLIENT_INFO(l_AUDIT_OPRID);
         l_audit_oprid := Get_Ps_Oprid(l_AUDIT_OPRID);

         -- NY business_unit are on specific SETID for ALTACCT. The feeding rules are different for them.
         SELECT COUNT(*) INTO l_indic_NY
         FROM   PS_SET_CNTRL_REC REC
         WHERE  RECNAME='ALTACCT_TBL'
         AND    SETID IN ('NYSUB', 'SGUSA', 'COWEN')
         AND    SETCNTRLVALUE=:NEW.BUSINESS_UNIT;

         IF l_indic_NY = 1 THEN
           -- BO_DT_SG : For NY it was given in the AE015_NY run cntrl. Which equalled the $U as of date.
           SELECT TO_DATE(SCHED_PRCS_DATE_SG, 'YYYYMMDD') INTO l_BO_DT_SG
           FROM PS_ME_BU_STATUS_SG WHERE BUSINESS_UNIT_GRP = 'SGUSA';

           UPDATE PS_JRNL_LN
           SET
             EVENT_DT_SG     = NVL(EVENT_DT_SG, TRUNC(SYSDATE, 'DD')),
             VALUE_DT_SG     = NVL(VALUE_DT_SG, :NEW.JOURNAL_DATE),
             BO_DT_SG        = NVL(l_BO_DT_SG, JOURNAL_DATE),
             USER1_SG        = DECODE(USER1_SG, ' ', LINE_DESCR,  USER1_SG),
             USER2_SG        = DECODE(USER2_SG, ' ', JRNL_LN_REF, USER2_SG),
             USER3_SG        = DECODE(USER3_SG, ' ', 'AC',        USER3_SG)
           WHERE  BUSINESS_UNIT = :NEW.BUSINESS_UNIT
           AND    JOURNAL_ID    = :NEW.JOURNAL_ID
           AND    JOURNAL_DATE  = :NEW.JOURNAL_DATE
           AND    UNPOST_SEQ    = :NEW.UNPOST_SEQ;

         ELSE
           UPDATE PS_JRNL_LN
           SET
             EVENT_DT_SG     = NVL(EVENT_DT_SG, :NEW.JOURNAL_DATE),
             VALUE_DT_SG     = NVL(VALUE_DT_SG,:NEW.JOURNAL_DATE),
             BO_DT_SG        = NVL(BO_DT_SG, :NEW.POSTED_DATE),
             RDJ_DT_SG       = NVL(RDJ_DT_SG, :NEW.POSTED_DATE),
             OPERATION_CD_SG = DECODE(OPERATION_CD_SG, ' ', :NEW.SOURCE, OPERATION_CD_SG),
             USER5_SG        = DECODE(USER5_SG, ' ', l_audit_oprid, USER5_SG)
           WHERE  BUSINESS_UNIT = :NEW.BUSINESS_UNIT
           AND    JOURNAL_ID    = :NEW.JOURNAL_ID
           AND    JOURNAL_DATE  = :NEW.JOURNAL_DATE
           AND    UNPOST_SEQ    = :NEW.UNPOST_SEQ;
         END IF;

      l_updlines := SQL%ROWCOUNT;

      ELSE
        -- set transaction_date to rdj_date
        :NEW.TRANSACTION_DATE := l_rdj_dt;

      END IF;

   END IF;
      -- ALO @14/12/2015 Begin modification JIRA GLTES-47    
      /*INSERT INTO  PS_JL_FLDS_LOG_SG (BUSINESS_UNIT, JOURNAL_ID, JOURNAL_DATE, UNPOST_SEQ, NUM_ROWS, IN_SECONDS, OPRID)
                   VALUES  (:new.BUSINESS_UNIT, :new.JOURNAL_ID, :new.JOURNAL_DATE, :new.UNPOST_SEQ,
                           l_updlines, round ( (sysdate-l_begindttm)*24*60*60 ), l_audit_oprid );  */
         
  IF :NEW.JRNL_HDR_STATUS IN ('U') -- Need to Update an existing line PS_JL_FLDS_LOG_SG
  THEN
    INSERT INTO  PS_JL_FLDS_LOG_SG (BUSINESS_UNIT, JOURNAL_ID, JOURNAL_DATE, UNPOST_SEQ, NUM_ROWS, IN_SECONDS, OPRID, POST_UTC_DTTM_SG, UNPOST_UTC_DTTM_SG)
   VALUES  (:NEW.BUSINESS_UNIT, :NEW.JOURNAL_ID, :NEW.JOURNAL_DATE, :NEW.UNPOST_SEQ,
   l_updlines, ROUND ( (SYSDATE-l_begindttm)*24*60*60 ), l_audit_oprid, NULL, CAST(:NEW.DTTM_STAMP_SEC AS TIMESTAMP) AT TIME ZONE 'UTC' );           
  ELSIF :NEW.JRNL_HDR_STATUS IN ('P') -- Need to Insert a new existing line in PS_JL_FLDS_LOG_SG
  THEN
    INSERT INTO  PS_JL_FLDS_LOG_SG (BUSINESS_UNIT, JOURNAL_ID, JOURNAL_DATE, UNPOST_SEQ, NUM_ROWS, IN_SECONDS, OPRID, POST_UTC_DTTM_SG, UNPOST_UTC_DTTM_SG)
   VALUES  (:NEW.BUSINESS_UNIT, :NEW.JOURNAL_ID, :NEW.JOURNAL_DATE, :NEW.UNPOST_SEQ,
   l_updlines, ROUND ( (SYSDATE-l_begindttm)*24*60*60 ), l_audit_oprid, CAST(:NEW.DTTM_STAMP_SEC AS TIMESTAMP) AT TIME ZONE 'UTC' ,NULL);  
  END IF;
 -- ALO @14/12/2015 End modification JIRA GLTES-47 
   
END;