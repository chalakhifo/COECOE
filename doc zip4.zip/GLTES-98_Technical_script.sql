----- checks-----;
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLTEXTDEFN_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTDEFN_SG where SQLID like 'CHK127%' ;
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLVALUESET_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLVALUESET_SG where SQLID like 'CHK127%';
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLPARMVALUE_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLPARMVALUE_SG where SQLID like 'CHK127%';
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLCOLDEFN_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLCOLDEFN_SG where SQLID like 'CHK127%';
--details-----;
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLTEXTDEFN_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTDEFN_SG where SQLID like 'DET127%' ;
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLVALUESET_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLVALUESET_SG where SQLID like 'DET127%';
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLPARMVALUE_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLPARMVALUE_SG where SQLID like 'DET127%';
select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLCOLDEFN_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLCOLDEFN_SG where SQLID like 'DET127%';

select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQLTEXTINFO_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTINFO_SG where SQLID like '%127%';

select 'GLTES-98' as JIRA_ID,'[CAB 2016-Q4] Check if all business unit have a default adjusting period' as DESCR,'PS_SQL_RUN_LINE_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQL_RUN_LINE_SG where SQLID like '%127%';

