--BU Definition--;
select * from  PS_BUS_UNIT_TBL_GL where BUSINESS_UNIT in ('G9296','I9296') and PROCESS_DATE = '18-MAY-16';--2
SELECT * FROM  PS_BUS_UNIT_TBL_FS WHERE business_unit in ('G9296','I9296');
SELECT * FROM  PS_BUS_UNIT_IDS_GL WHERE business_unit in ('G9296','I9296');

--Ledger/Period Setup--;
select * from PS_BU_LED_TBL where BUSINESS_UNIT in ('G9296','I9296');
select * from PS_BU_LED_GRP_TBL  where BUSINESS_UNIT in ('G9296','I9296') and CALENDAR_ID = '01' and ADB_REPORTING = 'N' and CALENDAR_ID_ADB = ' ';--4
select * from PS_BU_LED_GRP_TBL  where BUSINESS_UNIT in ('G9296','I9296') and LEDGER = 'REC_I9296' and BASE_CURRENCY = 'SGD';
select * from PS_FIN_OPEN_ADJ    where PSFT_PRODUCT = 'GL' and BUSINESS_UNIT in ('G9296','I9296') and FISCAL_YEAR = 2016 and IS_OPEN = 'N';
select * from PS_FIN_BU_LGRP_TBL where BUSINESS_UNIT in ('G9296','I9296') and CALENDAR_ID = '01';--3
SELECT * FROM PS_FIN_OPEN_PERIOD WHERE PSFT_PRODUCT = 'GL' AND business_unit in ('G9296','I9296') and OPEN_YEAR_FROM = 2016 and OPEN_PERIOD_FROM = 5;

--Set control setup--;
SELECT * FROM PS_SETID_TBL        WHERE setid in ('G9296','I9296');
select * from PS_SET_CNTRL_TBL    where SETCNTRLVALUE in ('G9296','I9296');
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'FS_02' and SETID = 'SHARE';
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'FS_05' and SETID in ('SHARE','I9296');
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'FS_06' and SETID = 'PARIS';
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'FS_10' and SETID = 'PARIS';
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'FS_40' and SETID = 'SHARE';
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'FS_45' and SETID = 'SHARE';
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'GL_03' and SETID = 'PASHR';---2
select * from PS_SET_CNTRL_GROUP  where SETCNTRLVALUE in ('G9296','I9296') and REC_GROUP_ID = 'GL_06' and SETID = 'PASHR';--2
SELECT * FROM PS_SET_CNTRL_REC 	  WHERE setcntrlvalue in ('G9296','I9296');

--Business unit group--;
select * from  PS_ME_RF_BU_GRP_SG where BUSINESS_UNIT = 'G9296' and BUSINESS_UNIT_GRP = 'G9296' and INDIV_BU_SG = 'I9296';--1
--Sun conso setup--;
Select  * from PS_SUB_CONSO_BU_SG WHERE cust_id_sg ='150';

--------BDR Client file Setup----------;
select * from ps_soc_bdr_fcli_sg where cust_id_sg ='150';
