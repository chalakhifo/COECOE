-- GLTES-151 - [CAB 2016-Q4] New morning check: Balances on private Deptid
-- requete developp�e

SELECT L.DEPTID,
  S.ESTABID,
  L.BUSINESS_UNIT,
  SUM(L.YTD_BASE_AMT),
  SUM(L.YTD_TRAN_AMT),
  L.CURRENCY_CD
FROM PS_LEDGER_DTM L,
  PS_DEPT_SAV_SG S,
  PS_LEDGER_SETID_DTM D
WHERE L.FISCAL_YEAR =  2016
AND L.ACCOUNTING_PERIOD  = 10
AND L.LEDGER  != 'REPLOC'
AND L.BUSINESS_UNIT  = D.BUSINESS_UNIT
AND L.LEDGER  = D.LEDGER
AND L.DEPTID  = S.DEPTID
AND S.SETID  = D.DEPT_SETID
AND (S.DEPTID, S.ESTABID) NOT IN
  (SELECT A.DEPTID,
    A.ESTABID
  FROM PS_DEPT_TBL_DTD A,
    PS_DEPT_1_SG_DTD B
  WHERE A.SETID = B.SETID
  AND A.DEPTID  = B.DEPTID
  )
GROUP BY L.BUSINESS_UNIT,
  L.DEPTID,
  S.ESTABID,
  L.CURRENCY_CD
HAVING NOT(SUM(L.YTD_TRAN_AMT) = 0
AND SUM(L.YTD_BASE_AMT)  = 0)
ORDER BY L.DEPTID,
  S.ESTABID,
  L.BUSINESS_UNIT;




-- sur 2016 - periode 9 => il ressort cette valeur CHGRCTTDA1  
select * from PS_DEPT_SAV_SG where deptid = 'CHGRCTTDA1';
select * from PS_DEPT_TBL_DTD where deptid = 'CHGRCTTDA1';
-- effectivement il s'agit d'un DEPTID priv�

-- sur 2016 - periode 10 PRF01 => il ressort cette valeur 
-- 'ACCPAY','ACFI','D100','EFFTEX','PEOPLESOFT'
select * from PS_DEPT_SAV_SG where deptid in ('ACCPAY','ACFI','D100','EFFTEX','PEOPLESOFT');

select * from PS_DEPT_TBL_DTD where deptid in ('ACCPAY','ACFI','D100','EFFTEX','PEOPLESOFT');
-- ce sont bien des DEPTID priv�s
-- ressortent bien dans le morning check PI = 8746947 PRF01 02/11/2016


--- sur 2016 - periode 8 => il ressort ('ACCPAY','ACFI','D100','EFFTEX','PEOPLESOFT')
select * from PS_DEPT_SAV_SG where deptid in ('ACCPAY','ACFI','D100','EFFTEX','PEOPLESOFT');

select * from PS_DEPT_TBL_DTD where deptid in ('ACCPAY','ACFI','D100','EFFTEX','PEOPLESOFT');
-- effectivement il s'agit d'un DEPTID priv�

-- search d'un DEPTID ayant des soldes tests previous on UAT
SELECT L.DEPTID,
--  L.ESTABID,
  L.BUSINESS_UNIT,
  SUM(L.YTD_BASE_AMT),
  SUM(L.YTD_TRAN_AMT),
  L.CURRENCY_CD
FROM PS_LEDGER_DTM L
WHERE L.FISCAL_YEAR =  2016
AND L.ACCOUNTING_PERIOD  = 07
AND L.LEDGER  != 'REPLOC'
GROUP BY L.BUSINESS_UNIT,
  L.DEPTID,
  L.CURRENCY_CD
HAVING NOT(SUM(L.YTD_TRAN_AMT) = 0
AND SUM(L.YTD_BASE_AMT)  = 0)
ORDER BY L.DEPTID,
--  L.ESTABID,
  L.BUSINESS_UNIT;
  
  
select * from PS_DEPT_SAV_SG where deptid = '100_SGIC';

select * from PS_DEPT_TBL_DTD where deptid = '100_SGIC';-- estabid = RCN

update PS_DEPT_TBL_DTD set deptid = '100_SGIC' where setid = 'NYSHR' and deptid = '100_SGI';  

-- run sur PRF01 02/11/2016
-- search d'un DEPTID ayant des soldes
SELECT L.DEPTID,
--  L.ESTABID,
  L.BUSINESS_UNIT,
  SUM(L.YTD_BASE_AMT),
  SUM(L.YTD_TRAN_AMT),
  L.CURRENCY_CD
FROM PS_LEDGER_DTM L
WHERE L.FISCAL_YEAR =  2016
AND L.ACCOUNTING_PERIOD  = 10
AND L.LEDGER  != 'REPLOC'
GROUP BY L.BUSINESS_UNIT,
  L.DEPTID,
  L.CURRENCY_CD
HAVING NOT(SUM(L.YTD_TRAN_AMT) = 0
AND SUM(L.YTD_BASE_AMT)  = 0)
ORDER BY L.DEPTID,
--  L.ESTABID,
  L.BUSINESS_UNIT;
  
  
  
select * from PS_DEPT_SAV_SG where deptid in ('0T','0T_CONF','1002','100_SGAI','100_SGFC','1021','1022','1074');

select * from PS_DEPT_TBL_DTD where deptid in ('0T','0T_CONF','1002','100_SGAI','100_SGFC','1021','1022','1074');  

-- 0T
select * from PS_DEPT_SAV_SG where deptid ='0T';


select * from PS_DEPT_TBL_DTD where deptid ='0T';
-- SETID = SHARE
-- DEPTID = 0T
-- EFFDT = 01-OCT-2016
-- descr = LONDON FACILITATION
-- short_descr = 0T
-- ESTABID = GOP

-- creation du deptid 0T ds table SAV
select * from PS_DEPT_SAV_SG where deptid ='0T';

update PS_DEPT_TBL_DTD set deptid = 'VDE_0T' 
where setid = 'SHARE'
and deptid ='0T';

select * from PS_DEPT_TBL_DTD where deptid ='VDE_0T';

--update back deptid 
update PS_DEPT_TBL_DTD set deptid = '0T' 
where setid = 'SHARE'
and deptid ='VDE_0T';








