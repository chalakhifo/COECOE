
  CREATE MATERIALIZED VIEW "COEPRD00"."PS_DEPT_DTM" ("SETID", "DEPTID", "EFFDT", "ENDDT", "EFF_STATUS", "DESCR", "DESCRSHORT", "LOCATION", "ESTABID", "CLASS_SG", "GOP_SG", "TRSCES_SG", "TRSCESTPZ_SG", "ACT_SG", "PTFGEN_SG", "GUIRPTF_SG", "GOPMNEGEN_SG", "ACTPTF_SG", "FRAFINECO_SG", "IASDRVVALMET_SG", "IASFINECO_SG", "IASFONFINECO_SG", "IASDRVUSE_SG", "IASFONVALMET_SG", "IASVALMET_SG", "PERMOR_SG", "MDECLCCBL_SG", "MDECLCFRT_SG", "MNEAPPTRB_SG", "MNEPTFTRB_SG", "FRAMJRFINECO_SG", "IASMJRFINECO_SG", "CODBCK_SG", "MNEMLEPER_SG", "MNEPRUCLA_SG", "MNERISFOLMET_SG", "MNESTRRISBLO_SG", "MNEUNIBAS_SG", "MODVAL_SG", "PLTCPT_SG", "CODBOKNTT_SG", "MNETYPCCENRSP_SG", "MNEALGBUS_SG", "CODDIR_SG", "MNEMETALC_SG", "LIBDIRRSP_SG", "CODCENPRF_SG", "MNECENPRF_SG", "LIBCENPF_SG", "GOP_TYPOLOGY_SG", "TP_METHODOLOGY_SG", "NEGOTIATION_ORI_SG", "LOCAL_ID_SG")
  ORGANIZATION HEAP PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS NOLOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "GLLARGE" 
  BUILD IMMEDIATE
  USING INDEX 
  REFRESH COMPLETE ON DEMAND
  USING DEFAULT LOCAL ROLLBACK SEGMENT
  USING ENFORCED CONSTRAINTS DISABLE QUERY REWRITE
  AS SELECT    setid,              deptid,           effdt,
          NVL(LEAD(effdt, 1) OVER (PARTITION BY setid,deptid  ORDER BY effdt), TO_DATE('31129999','ddmmyyyy')) AS enddt,
          D.eff_status,       D.descr,             D.descrshort,         D.LOCATION,       D.estabid,
          D1.class_sg,        D1.gop_sg,           D1.trsces_sg,         D1.trscestpz_sg,  D1.act_sg,
          D1.ptfgen_sg,       D1.guirptf_sg,       D1.gopmnegen_sg,      D1.actptf_sg,     D1.frafineco_sg,
          D1.iasdrvvalmet_sg, D1.iasfineco_sg,     D1.iasfonfineco_sg,   D1.iasdrvuse_sg,  D1.iasfonvalmet_sg,
          D1.iasvalmet_sg,    D1.permor_sg,        D1.mdeclccbl_sg,      D1.mdeclcfrt_sg,  D1.mneapptrb_sg,
          D1.mneptftrb_sg,    D1.framjrfineco_sg,  D1.iasmjrfineco_sg,   D1.codbck_sg,     D1.mnemleper_sg,
          D1.mneprucla_sg,    D1.mnerisfolmet_sg,  D1.mnestrrisblo_sg,   D1.mneunibas_sg,  D1.modval_sg,
          D1.pltcpt_sg,       D1.codbokntt_sg,     D1.mnetypccenrsp_sg,  D1.mnealgbus_sg,  D1.coddir_sg,
          D1.mnemetalc_sg,    D1.libdirrsp_sg,     D1.codcenprf_sg,      D1.mnecenprf_sg,  D1.libcenpf_sg, D1.GOP_TYPOLOGY_SG,D1.TP_METHODOLOGY_SG,
          D1.NEGOTIATION_ORI_SG, D1.LOCAL_ID_SG
FROM      PS_DEPT_TBL_EDT D
          LEFT OUTER JOIN PS_DEPT_1_SG_EDT D1 USING( setid, deptid, effdt )
          /** SAV PROCESSING **/ WHERE (setid, deptid) NOT IN (SELECT setid, deptid FROM PS_DEPT_SAV_SG)
UNION ALL
SELECT    setid,              deptid,           effdt,
          NVL(LEAD(effdt, 1) OVER (PARTITION BY setid,deptid  ORDER BY effdt), TO_DATE('31129999','ddmmyyyy')) AS enddt,
          D.eff_status,       D.descr,            D.descrshort,         ' ',       D.estabid,
          D1.class_sg,        D1.gop_sg,          D.trsces_sg,          D1.trscestpz_sg,  D1.act_sg,
          D1.ptfgen_sg,       D1.guirptf_sg,      D1.gopmnegen_sg,      D1.actptf_sg,     D1.frafineco_sg,
          D1.iasdrvvalmet_sg, D1.iasfineco_sg,    D1.iasfonfineco_sg,   D1.iasdrvuse_sg,  D1.iasfonvalmet_sg,
          D1.iasvalmet_sg,    D1.permor_sg,       D1.mdeclccbl_sg,      D1.mdeclcfrt_sg,  D1.mneapptrb_sg,
          D1.mneptftrb_sg,    D1.framjrfineco_sg, D1.iasmjrfineco_sg,   D1.codbck_sg,     D1.mnemleper_sg,
          D1.mneprucla_sg,    D1.mnerisfolmet_sg, D1.mnestrrisblo_sg,   D1.mneunibas_sg,  D1.modval_sg,
          D1.pltcpt_sg,       D1.codbokntt_sg,    D1.mnetypccenrsp_sg,  D1.mnealgbus_sg,  D1.coddir_sg,
          D1.mnemetalc_sg,    D1.libdirrsp_sg,    D1.codcenprf_sg,      D1.mnecenprf_sg,  D1.libcenpf_sg , D1.GOP_TYPOLOGY_SG,D1.TP_METHODOLOGY_SG,
          D1.NEGOTIATION_ORI_SG, D1.LOCAL_ID_SG
FROM      PS_DEPT_SAV_SG D
          LEFT OUTER JOIN PS_DEPT_1_SG D1 USING( setid, deptid, effdt )
UNION ALL
SELECT    DISTINCT dept_setid, ' ',          TO_DATE('01011900','DDMMYYYY'),
          TO_DATE('31129999','DDMMYYYY'),
          ' ',    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',     0 ,     0 ,    ' ',
           0 ,    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',    ' ',    ' ',    ' ',
          ' ',    ' ',    ' ',    ' ',    ' ', ' ', ' ', 0, ' '
FROM      PS_LEDGER_SETID_DTM;

  CREATE UNIQUE INDEX "COEPRD00"."PS_DEPT_DTM" ON "COEPRD00"."PS_DEPT_DTM" ("SETID", "DEPTID", "EFFDT") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "PSINDEX" ;

   COMMENT ON MATERIALIZED VIEW "COEPRD00"."PS_DEPT_DTM"  IS 'snapshot table for snapshot COEPRD00.PS_DEPT_DTM';
