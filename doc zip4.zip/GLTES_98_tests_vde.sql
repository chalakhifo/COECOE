-- GLTES-098 - [CAB 2016-Q4] Check if all business unit have a default adjusting period
-- requete developp�e 1 

SELECT CASE WHEN COUNT (*) > 0 THEN 'YES' ELSE 'NO' END, COUNT (*) 
FROM (
SELECT DISTINCT BUSINESS_UNIT, LEDGER_GROUP 
FROM PS_FIN_OPEN_ADJ
WHERE PSFT_PRODUCT = ':1'
 MINUS 
SELECT DISTINCT BUSINESS_UNIT, LEDGER_GROUP 
FROM PS_FIN_OPEN_ADJ 
WHERE PSFT_PRODUCT = ':1'
AND DEFAULT_FLAG ='Y');

--=> failed ds PS good en SQL


-------
-- CHK127

SELECT
  CASE
    WHEN COUNT (*) > 0
    THEN 'YES'
    ELSE 'NO'
  END,
  COUNT (*)
FROM
  ( SELECT DISTINCT A.BUSINESS_UNIT,
    A.LEDGER_GROUP
  FROM PS_FIN_OPEN_ADJ A
  WHERE A.PSFT_PRODUCT = ':1'
  AND NOT EXISTS
    (SELECT 'X'
    FROM PS_FIN_OPEN_ADJ B
    WHERE B.PSFT_PRODUCT = A.PSFT_PRODUCT 
    AND A.BUSINESS_UNIT  = B.BUSINESS_UNIT
    AND A.LEDGER_GROUP   = B.LEDGER_GROUP
    AND B.DEFAULT_FLAG   ='Y'
    )
  );
  
  
-- DET 127

  SELECT DISTINCT A.BUSINESS_UNIT,
    A.LEDGER_GROUP
  FROM PS_FIN_OPEN_ADJ A
  WHERE A.PSFT_PRODUCT = ':1'
  AND NOT EXISTS
    (SELECT 'X'
    FROM PS_FIN_OPEN_ADJ B
    WHERE B.PSFT_PRODUCT = A.PSFT_PRODUCT 
    AND A.BUSINESS_UNIT  = B.BUSINESS_UNIT
    AND A.LEDGER_GROUP   = B.LEDGER_GROUP
    AND B.DEFAULT_FLAG   ='Y'
    );


-- Jeu de tests

------------------
select * from PS_FIN_OPEN_ADJ
where BUSINESS_UNIT = 'CAG01'
and LEDGER_GROUP = 'ACTLOCAL'
and DEFAULT_FLAG = 'Y';

update PS_FIN_OPEN_ADJ
set default_flag = 'N'
where BUSINESS_UNIT = 'CAG01'
and LEDGER_GROUP = 'ACTLOCAL'
and accounting_period = '998'
and DEFAULT_FLAG = 'Y';

update PS_FIN_OPEN_ADJ
set default_flag = 'Y'
where BUSINESS_UNIT = 'CAG01'
and LEDGER_GROUP = 'ACTLOCAL'
and accounting_period = '998'
and DEFAULT_FLAG = 'N';

SELECT DISTINCT BUSINESS_UNIT, LEDGER_GROUP 
FROM PS_FIN_OPEN_ADJ
WHERE PSFT_PRODUCT = 'GL'
and DEFAULT_FLAG !='Y'
order by 1,2
;
--and business_unit = 'CAG01';

SELECT DISTINCT BUSINESS_UNIT, LEDGER_GROUP 
FROM PS_FIN_OPEN_ADJ
WHERE PSFT_PRODUCT = 'GL'
and DEFAULT_FLAG !='Y'
order by 1,2
;

SELECT DISTINCT business_unit, ledger_group FROM PS_FIN_OPEN_ADJ 
MINUS SELECT DISTINCT business_unit, ledger_group FROM PS_FIN_OPEN_ADJ WHERE default_flag ='Y';

select * from PS_LDG_P_IN_UC1_DTM;

select * from PS_LDG_INT_UC1_VW ;

select * from PS_LDG_INT_UCC_VW;

SELECT * FROM TABLE(Ps_Kbscal_Sg.GetCalendar('20161101', 'G5314')); 


select * from ps_bdr_cal_dtd_sg where business_unit = 'LDG73' 
and source = 'QTU'
and fiscal_year = '2016'
and accounting_period = '11';


SELECT * FROM  PS_ME_RF_BU_GRP_SG WHERE BUSINESS_UNIT = 'LDG73' AND BUSINESS_UNIT_GRP ='SGUKA';

SELECT DISTINCT A.BUSINESS_UNIT,
    A.LEDGER_GROUP
  FROM PS_FIN_OPEN_ADJ A
  WHERE A.PSFT_PRODUCT = 'GL'
  AND NOT EXISTS
    (SELECT 'X'
    FROM PS_FIN_OPEN_ADJ B
    WHERE B.PSFT_PRODUCT = A.PSFT_PRODUCT 
    AND A.BUSINESS_UNIT  = B.BUSINESS_UNIT
    AND A.LEDGER_GROUP   = B.LEDGER_GROUP
    AND B.DEFAULT_FLAG   ='Y'
    );
    

update PS_FIN_OPEN_ADJ
set default_flag = 'Y'
where BUSINESS_UNIT = 'CAG01'
and LEDGER_GROUP = 'ACTLOCAL'
and accounting_period = '998'
and DEFAULT_FLAG = 'N';


select * from ps_ledger where business_unit = 'LDG73'
and process_instance = 8758921;

select * from ps_ledger_dtm
where business_unit = 'LDG73'
and fiscal_year = 2016
and deptid = '0TJP';
and accounting_period = 7;

select * from PS_YTD_DTM
where business_unit = 'LDG73'
and fiscal_year = 2016;
and deptid = '0TJP';
and accounting_period = 7;

select * from PS_LST_ENTRY_DPT_ACC_DTM
where business_unit = 'LDG73'
and fiscal_year = 2016;
and accounting_period = 7;



select business_unit, journal_id, JOURNAL_DATE, fiscal_year, accounting_period, 
ledger, JRNL_HDR_STATUS, source, posted_date, process_instance, transaction_date,
oprid, DTTM_STAMP_SEC, descr, CURRENCY_CD
from ps_jrnl_header where business_unit = 'LDG73'
order by 2;

select *
from ps_jrnl_header where business_unit = 'LDG73'
order by 2;

select *
from ps_jrnl_vw_sg where business_unit = 'LDG73';


select * from ps_jrnl_ln 
where business_unit = 'LDG73'
order by 2,5;
and journal_id in('0009035787','0009035788');

SELECT * FROM PS_RUN_AE066_SG WHERE oprid='BATCHSGUK' ;

SELECT * FROM  PS_ME_RF_BU_GRP_SG WHERE BUSINESS_UNIT in ('LDG73','LDG38');


select * from PS_BDR_CAL_DTD_SG
where business_unit = 'LDG73';

select * from PS_BDR_CAL_DTD_SG
where business_unit = 'G5314'
and fiscal_year = 2016 ;



