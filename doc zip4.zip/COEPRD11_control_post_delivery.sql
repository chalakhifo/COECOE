select * from PS_OBJECTC_BDR_SG
where (object_code like ('%'||chr(59)||'%') or object_code like('%|%') or object_code like('%,%'));

select * from PS_CHARTF1_TBL_EDT bdr
where (object_code like ('%'||chr(59)||'%') or object_code like('%|%') or object_code like('%,%'))
;

select * from PS_CHARTF1_TBL_DTD
where (object_code like ('%'||chr(59)||'%') or object_code like('%|%') or object_code like('%,%'));

select * from PS_CF_ATTR_TBL_DTD 
where FIELDNAME = 'OBJECT_CODE'
and (CHARTFIELD_VALUE like ('%;%') or chartfield_value like ('%|%')or chartfield_value like ('%,%'))
;

select * from PS_CHARTF1_TBL_EDT
where (object_code like ('%'||chr(59)||'%') or object_code like('%|%') or object_code like('%,%'))
;

select * from PS_CF_ATTR_TBL_EDT where FIELDNAME = 'OBJECT_CODE' 
and (CHARTFIELD_VALUE like ('%;%') or chartfield_value like ('%|%')or chartfield_value like ('%,%'))
;

select * from PS_CHARTFIELD1_TBL
where  (object_code like ('%'||chr(59)||'%') or object_code like('%|%') or object_code like('%,%'))
;

select * from PS_MIG_HEADER_SG
where FIELD_MIG_SG = 'OBJECT_CODE'
and (oldvalue like ('%'||chr(59)||'%') or oldvalue like('%|%') or oldvalue like('%,%'))
union 
select * from PS_MIG_HEADER_SG
where FIELD_MIG_SG = 'OBJECT_CODE'
and (newvalue like ('%'||chr(59)||'%') or newvalue like('%|%') or newvalue like('%,%'))
;

select * from PS_CF_ATTRIB_TBL
where (CHARTFIELD_VALUE like ('%;%') or chartfield_value like ('%|%')or chartfield_value like ('%,%'))
;

select * from PS_IAM_ERR_TBL_SG
order by effdt desc;

