----- checks-----;
select * from PS_SQLTEXTDEFN_SG where SQLID like 'CHK127%' ;
select * from PS_SQLVALUESET_SG where SQLID like 'CHK127%';
select * from PS_SQLPARMVALUE_SG where SQLID like 'CHK127%';
select * from PS_SQLCOLDEFN_SG where SQLID like 'CHK127%';
--details-----;
select * from PS_SQLTEXTDEFN_SG where SQLID like 'DET127%' ;
select * from PS_SQLVALUESET_SG where SQLID like 'DET127%';
select * from PS_SQLPARMVALUE_SG where SQLID like 'DET127%';
select * from PS_SQLCOLDEFN_SG where SQLID like 'DET127%';

select * from PS_SQLTEXTINFO_SG where SQLID like '%127%';

select * from PS_SQL_RUN_LINE_SG where SQLID like '%127%';