/* tests GLTES-255 */
/* Morning check process with traces */

/* dev Ankit */
/* requete on UAT */

/* CHK 128 */

SELECT
  CASE
    WHEN COUNT (*) > 0
    THEN 'YES'
    ELSE 'NO'
  END,
  COUNT (*)
FROM PS_PRCSDEFN
WHERE (PRCSTYPE  = 'Application Engine'
AND PARMLISTTYPE = '3'
AND UPPER(PARMLIST) LIKE '%TRACE%')
OR ( PRCSTYPE LIKE 'SQR%'
AND PARMLISTTYPE = '3'
AND LOWER(PARMLIST) LIKE '%debug%')
OR (PRCSTYPE LIKE 'COBOL%'
AND PARMLISTTYPE = '1');

/* UAT already cleaning done */
/* on PRD count = 7 */

/* DET-128 */
SELECT PRCSTYPE,
  PRCSNAME,
  PARMLIST,
  PARMLISTTYPE
FROM PS_PRCSDEFN
WHERE (PRCSTYPE  = 'Application Engine'
AND PARMLISTTYPE = '3'
AND UPPER(PARMLIST) LIKE '%TRACE%')
OR ( PRCSTYPE LIKE 'SQR%'
AND PARMLISTTYPE = '3'
AND LOWER(PARMLIST) LIKE '%debug%')
OR ( PRCSTYPE LIKE 'COBOL%'
AND PARMLISTTYPE = '1');

