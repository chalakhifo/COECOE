INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201605A','GLTES-48' AS CO_Num,SYSTIMESTAMP,'A', 'GLTES-48 - Delete 3 GOP from PS_DEPT_TBL' AS Descr , 'PS_DEPT_TBL' AS Tablename, 
    ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks 
    FROM PS_DEPT_TBL  WHERE setid = 'SHARE' AND deptid IN ('SGSLXP', 'MUE', 'RISK');
    
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201605A','GLTES-48' AS CO_Num,SYSTIMESTAMP,'A', 'GLTES-48 - Delete 3 GOP from PS_DEPT_TBL_EDT' AS Descr , 'PS_DEPT_TBL_EDT' AS Tablename, 
    ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks 
    FROM PS_DEPT_TBL_EDT  WHERE setid = 'SHARE' AND deptid IN ('SGSLXP', 'MUE', 'RISK');   

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201605A','GLTES-48' AS CO_Num,SYSTIMESTAMP,'A', 'GLTES-48 - Delete 3 GOP from PS_DEPT_1_SG' AS Descr , 'PS_DEPT_1_SG' AS Tablename, 
    ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks 
    FROM PS_DEPT_1_SG  WHERE setid = 'SHARE' AND deptid IN ('SGSLXP', 'MUE', 'RISK'); 
	
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201605A','GLTES-48' AS CO_Num,SYSTIMESTAMP,'A', 'GLTES-48 - Delete 3 GOP from PS_DEPT_1_SG_EDT' AS Descr , 'PS_DEPT_1_SG_EDT' AS Tablename, 
    ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks 
    FROM PS_DEPT_1_SG_EDT  WHERE setid = 'SHARE' AND deptid IN ('SGSLXP', 'MUE', 'RISK'); 

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201605A','GLTES-48' AS CO_Num,SYSTIMESTAMP,'A', 'GLTES-48 - Update PS_DEPT_SAV_SG status I to A' AS Descr , 'PS_DEPT_SAV_SG' AS Tablename, 
    ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks 
FROM  PS_DEPT_SAV_SG
WHERE eff_status = 'I'
AND (setid, deptid, descr, descrshort, estabid, trsces_sg)  IN (
SELECT a.setid, a.deptid, a.descr, a.descrshort, a.estabid, b.trsces_sg 
FROM PS_DEPT_TBL_DTD a, PS_DEPT_1_SG_DTD b
WHERE a.setid = b.setid AND a.deptid = b.deptid
AND a.eff_status = 'A');    
    
    
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201605A','GLTES-48' AS CO_Num,SYSTIMESTAMP,'A', 'GLTES-48 - Update PS_DEPT_SAV_SG status A to I' AS Descr , 'PS_DEPT_SAV_SG' AS Tablename, 
    ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks 
    FROM  PS_DEPT_SAV_SG
WHERE eff_status = 'A'
AND (setid, deptid, descr, descrshort, estabid, trsces_sg)  IN (
SELECT a.setid, a.deptid, a.descr, a.descrshort, a.estabid, b.trsces_sg 
FROM PS_DEPT_TBL_DTD a, PS_DEPT_1_SG_DTD b
WHERE a.setid = b.setid AND a.deptid = b.deptid
AND a.eff_status = 'I');

COMMIT
/

