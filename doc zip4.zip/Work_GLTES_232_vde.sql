  select business_unit, process_date from ps_bus_unit_tbl_gl where business_unit in('GFR01','IFR01');

-- GLTES-232 [CAB 2016-Q4] Adjusting amounts updated dynamically in GL view 
-- SQL _ LEDGER_P_IN_DTM
-- Vue dynamique utilis�e par R2D2

SELECT business_unit 
 , ledger 
 , ACCOUNT 
 , altacct 
 , operating_unit 
 , deptid 
 , product 
 , object_code 
 , affiliate 
 , currency_cd 
 , fiscal_year 
 , accounting_period 
 , ytd_base_amt_1+mtd_base_amt 
 , ytd_tran_dr_1+mtd_tran_dr 
 , ytd_tran_cr_1+mtd_tran_cr 
 , ytd_tran_dr_1+ytd_tran_cr_1+mtd_tran_dr+mtd_tran_cr 
 , mtd_base_amt 
 , mtd_tran_dr 
 , mtd_tran_cr 
 , mtd_tran_dr+mtd_tran_cr 
 , 0 
 , 0 
 , 0 
 , 0 
 , ytd_base_amt_1 
 , ytd_tran_dr_1 
 , ytd_tran_cr_1 
 , ytd_tran_dr_1+ytd_tran_cr_1 
 , adj_base_amt_1 
 , adj_tran_dr_1 
 , adj_tran_cr_1 
 , adj_tran_dr_1+adj_tran_cr_1 
 , bcf_base_amt 
 , bcf_tran_dr 
 , bcf_tran_cr 
 , bcf_tran_dr+bcf_tran_cr 
 , base_currency 
 , dttm_stamp_sec 
 , last_modified 
  FROM PS_YTD_PARI_DTM 
  UNION ALL 
 SELECT business_unit 
 , ledger 
 , ACCOUNT 
 , altacct 
 , operating_unit 
 , deptid 
 , product 
 , object_code 
 , affiliate 
 , currency_cd 
 , fiscal_year 
 , accounting_period-900 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , posted_base_amt 
 , posted_tran_dr 
 , posted_tran_cr 
 , posted_tran_amt 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , 0 
 , base_currency 
 , dttm_stamp_sec 
 , fiscal_year*100+(accounting_period-900) 
  FROM PS_LEDGER 
 WHERE accounting_period BETWEEN 901 AND 912;

--- vue interrog�e par Granite 
-- YTD_PARI_DTM_VW avant modification

SELECT BUSINESS_UNIT 
 , LEDGER 
 , ACCOUNT 
 , ALTACCT 
 , OPERATING_UNIT 
 , DEPTID 
 , PRODUCT 
 , OBJECT_CODE 
 , AFFILIATE 
 , CURRENCY_CD 
 , FISCAL_YEAR 
 , ACCOUNTING_PERIOD 
 , MTD_BASE_AMT 
 , MTD_TRAN_DR 
 , MTD_TRAN_CR 
 , YTD_BASE_AMT_1 
 , YTD_TRAN_DR_1 
 , YTD_TRAN_CR_1 
 , ADJ_BASE_AMT 
 , ADJ_TRAN_DR 
 , ADJ_TRAN_CR 
 , ADJ_BASE_AMT_1 
 , ADJ_TRAN_DR_1 
 , ADJ_TRAN_CR_1 
 , BCF_BASE_AMT 
 , BCF_TRAN_CR 
 , BCF_TRAN_DR 
 , BASE_CURRENCY 
 , DTTM_STAMP_SEC 
 , LAST_MODIFIED 
  FROM PS_YTD_PARI_DTM

