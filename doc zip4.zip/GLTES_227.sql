select * from PS_OBJECTC_BDR_SG 
--where object_code like ('%;%','%|%','%,%')
;

-- Tables DTD charg�es

select * from PS_CHARTF1_TBL_DTD
--where object_code like ('%;%','%|%','%,%')
;

-- 73 PRF01 le 13/09/2016
select * from PS_CF_ATTR_TBL_DTD 
where FIELDNAME = 'OBJECT_CODE'
and (CHARTFIELD_VALUE like ('%;%') or chartfield_value like ('%|%')or chartfield_value like ('%,%'))
;
-- �a sert � quoi cf_attrib_value = 'FUT'
-- c'est un produit financier

-- rien � faire
select * from PS_CF_ATTR_VAL_DTD;

-- Tables EDT charg�es

select * from PS_CHARTF1_TBL_EDT
--where OBJECT_CODE like ('%;%','%|%','%,%')
;

select * from PS_CF_ATTR_TBL_EDT where FIELDNAME = 'OBJECT_CODE' ;
--and CHARTFIELD_VALUE like ('%;%','%|%','%,%');

-- rien � faire
select * from PS_CF_ATTR_VAL_EDT;

-- Tables FT charg�es

select * from PS_CHARTFIELD1_TBL ;
--where object_code like ('%;%','%|%','%,%');

select * from PS_CF_ATTRIB_TBL; 
--where CHARTFIELD_VALUE like ('%;%','%|%','%,%');

-- rien � faire - aucune decription ds DESCR60 pour les object_code
select * from PS_CF_ATTRIB_VALUE;

-- rien � faire ? rien concernant CF_attribute 'FUT'
select * from PS_CHARTF1_SAV_SG;

select * from PS_OBJECTC_BDR_SG;
--where object_code like ('%;%','%|%','%,%');

select * from PS_MIG_HEADER_SG
where FIELD_MIG_SG = 'OBJECT_CODE'
and (OLDVALUE like '%;%' OR NEWVALUE like ('%;%','%|%','%,%'));
select * from PS_IAM_ERR_TBL_SG;


select * from PS_CF_ATTR_VAL_DTD;