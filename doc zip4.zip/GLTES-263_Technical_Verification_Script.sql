


INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) SELECT  '201701A', 'GLTES-263' as CO_Num, systimestamp, 'A', 'Remove PS_RAN_SG Elim business units' as Descr, 'PS_RAN_SG' as tablename, ( CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'KO' END) Remarks FROM  PS_RAN_SG WHERE business_unit IN (SELECT business_unit FROM PS_BUS_UNIT_TBL_GL WHERE elims_only = 'Y'); 
COMMIT;
/