-- requete du JIRA 219
select oprid, prcsname, (rundttm - begindttm) from ps_pmn_prcslist
where prcsname = 'RCN_EXT_SG'
and runcntlid like '%SG_RUN_GL1RC%'
and prcsinstance > 8557322
order by 3 ASC;

-- sur PRF on a jou� entre le 07/10/2016 20 h et le 08/10/2016 7h au matin le J3 de PRD
/*select a.rundttm - a.begindttm, a.oprid, a.*  from ps_pmn_prcslist a
where RQSTDTTM between TO_TIMESTAMP ('07-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('08-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
and prcsname = 'RCN_EXT_SG'
 and runcntlid like '%SG_RUN_GL1RC%'
order by 2 asc ;*/


select PRCSINSTANCE, oprid, prcsname, (rundttm - begindttm) from ps_pmn_prcslist
where prcsname = 'RCN_EXT_SG'
and runcntlid like '%SG_RUN_GL1RC%'
and RQSTDTTM between TO_TIMESTAMP ('07-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('08-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
order by 2 ASC;
-- duree_latence_prf.xls

-- voir la dur�e de la chaine batch par oprid sur PRF
-- entre le 07/10/2016 20 h et le 08/10/2016 7h au matin (J3 de PRD)
select oprid, min(rundttm ), max(rundttm), (max(rundttm)-min(rundttm)), (max(BEGINDTTM)- min(BEGINDTTM))from ps_pmn_prcslist
where RQSTDTTM between TO_TIMESTAMP ('07-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('08-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
group by oprid
order by 1 ASC;
-- duree_batch_prf.xls


-- est ce que chaque process_instance pr�c�dent a g�n�r� des lignes de matching ? 
-- sur PRF g�n�ration de 24004 lignes ds ps_JRNL_RECON_SG

select a.process_instance, count(*) from ps_JRNL_RECON_SG a
where a.process_instance in (select b.PRCSINSTANCE from ps_pmn_prcslist b
where b.prcsname = 'RCN_EXT_SG'
and b.runcntlid like '%SG_RUN_GL1RC%'
and b.RQSTDTTM between TO_TIMESTAMP ('07-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('08-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
)group by A.PROCESS_INSTANCE;

-- ======= --
-- sur PRD --
-- ======= --
-- je dois regarder le J3 soit entre le 5/10 20h et le 6/10 � 7h du matin

/*select a.rundttm - a.begindttm, a.*  from ps_pmn_prcslist a
where  RQSTDTTM between TO_TIMESTAMP ('05-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('06-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
and prcsname = 'RCN_EXT_SG'
 and runcntlid like '%SG_RUN_GL1RC%'
order by 14 asc ;*/

select PRCSINSTANCE, oprid, prcsname, (rundttm - begindttm) from ps_pmn_prcslist
where prcsname = 'RCN_EXT_SG'
and runcntlid like '%SG_RUN_GL1RC%'
and RQSTDTTM between TO_TIMESTAMP ('05-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('06-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
order by 2 ASC;
-- duree_latence_prd.xls


-- voir la dur�e de la chaine batch par oprid sur PRD
-- entre le  le 5/10 20h et le 6/10 � 7h du matin

select oprid, min(rundttm ), max(rundttm), (max(rundttm)-min(rundttm)), (max(BEGINDTTM)- min(BEGINDTTM))from ps_pmn_prcslist
where RQSTDTTM between TO_TIMESTAMP ('05-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('06-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
group by oprid
order by 1 ASC;
-- duree_batch_prd.xls

-- pivots and compare

-- est ce que chaque process_instance pr�c�dent a g�n�r� des lignes de matching ? 
-- sur PRF g�n�ration de 22886 lignes ds ps_JRNL_RECON_SG

select a.process_instance, count(*) from ps_JRNL_RECON_SG a
where a.process_instance in (select b.PRCSINSTANCE from ps_pmn_prcslist b
where b.prcsname = 'RCN_EXT_SG'
and b.runcntlid like '%SG_RUN_GL1RC%'
and b.RQSTDTTM between TO_TIMESTAMP ('05-OCT-16 20:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')and TO_TIMESTAMP ('06-OCT-16 07:00:00.000000', 'DD-Mon-RR HH24:MI:SS.FF')
)group by A.PROCESS_INSTANCE;


--=================================--
/*select *  from ps_pmn_prcslist a
where --RQSTDTTM between to_char('08-OCT-2016 01:00:00')and to_char('08-OCT-2016 07:00:00')
--and 
oprid = 'BATCHSGEU';*/




