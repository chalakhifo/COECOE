SELECT * from PSPROJECTDEFN  where projectname ='SG_LOT1076';

SELECT * from PSPROJECTITEM  where projectname ='SG_LOT1076';

