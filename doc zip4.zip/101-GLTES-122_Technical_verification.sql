INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A', 'GLTES-122' as CO_Num, systimestamp,'A','[TAX] New Pivot extraction on G0001 to SCORE' as DESCR,'PS_PVT_PLT_EXT_TBL ' as TABLENAME, (case when COUNT(*) = 1 then 'OK' else 'KO' end) REMARKS from PS_PVT_PLT_EXT_TBL where REPORT_NAME='G0001_BAL_AGG_SCORE_ABP';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A', 'GLTES-122' as CO_Num, systimestamp,'A','[TAX] New Pivot extraction on G0001 to SCORE' as DESCR,'PS_PVT_PLT_CRIT_SG ' as TABLENAME, (case when COUNT(*) = 5 then 'OK' else 'KO' end) REMARKS from PS_PVT_PLT_CRIT_SG where REPORT_NAME='G0001_BAL_AGG_SCORE_ABP';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A', 'GLTES-122' as CO_Num, systimestamp,'A','[TAX] New Pivot extraction on G0001 to SCORE' as DESCR,'PS_PVT_PLT_SEL_TBL ' as TABLENAME, (case when COUNT(*) = 3 then 'OK' else 'KO' end) REMARKS from PS_PVT_PLT_SEL_TBL where REPORT_NAME='G0001_BAL_AGG_SCORE_ABP';

INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A', 'GLTES-122' as CO_Num, systimestamp,'A','[TAX] New Pivot extraction on G0001 to SCORE' as DESCR,'PS_PVT_RUN_EXCT_SG ' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_EXCT_SG where OPRID='BATCHPM' and RUN_CNTL_ID='SG_PVT_G0001_SCORE_MONTHLY_AGG' and REPORT_NAME='G0001_BAL_AGG_SCORE_ABP';
INSERT INTO PS_MEE_CHECK_SG (release_id_sg, co_num_sg, exec_time, status, descr_control, context_sg, results) 
SELECT '201603A', 'GLTES-122' as CO_Num, systimestamp,'A','[TAX] New Pivot extraction on G0001 to SCORE' as DESCR,'PS_PVT_RUN_FTB_SG ' as TABLENAME, (case when COUNT(*) = 1 then 'OK' else 'KO' end) REMARKS from PS_PVT_RUN_FTB_SG where OPRID='BATCHPM' and RUN_CNTL_ID='SG_PVT_G0001_SCORE_MONTHLY_AGG' and REPORT_NAME='G0001_BAL_AGG_SCORE_ABP';
