
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLTEXTDEFN_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTDEFN_SG where SQLID like 'CHK128%' ;
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLVALUESET_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLVALUESET_SG where SQLID like 'CHK128%';
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLPARMVALUE_SG' as TABLENAME, (case when COUNT(*) = 0  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLPARMVALUE_SG where SQLID like 'CHK128%';
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLCOLDEFN_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLCOLDEFN_SG where SQLID like 'CHK128%';
--details-----;
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLTEXTDEFN_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTDEFN_SG where SQLID like 'DET128%' ;
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLVALUESET_SG' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLVALUESET_SG where SQLID like 'DET128%';
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLPARMVALUE_SG' as TABLENAME, (case when COUNT(*) = 0  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLPARMVALUE_SG where SQLID like 'DET128%';
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLCOLDEFN_SG' as TABLENAME, (case when COUNT(*) = 4  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLCOLDEFN_SG where SQLID like 'DET128%';

select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLTEXTINFO_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTINFO_SG where SQLID like '%128%';
select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQLTEXTINFO_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQLTEXTINFO_SG where SQLID like '%126%';

select 'GLTES-255' as JIRA_ID,'Check Process with Active Trace' as DESCR,'PS_SQL_RUN_LINE_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_SQL_RUN_LINE_SG where SQLID like '%128%';
