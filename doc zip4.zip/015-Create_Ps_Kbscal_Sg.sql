CREATE OR REPLACE PACKAGE Ps_Kbscal_Sg AS
-- ############################################################################
-- SYNOPSIS
--    Interface which provide batch stream functional calendar
--
-- REMARKS:
--    All input and output dates are in YYYYMMDD format.
--
-- RELEASE
--    03/2013 M. Llopis: Creation
--    03/2016 Mahmoud HEBBACHE 
--                 replace PS_BSCAL_RULE_SCHED_SG with PS_BSCAL_RL_SCD_SG
--                         PS_BSCAL_RULE_EXC_SG with PS_BSCAL_RL_EXC_SG
-- ############################################################################

   -- Define Types and Records
   SUBTYPE calItem IS VARCHAR2(255);
   TYPE rd_cal IS RECORD ( item calItem );
   TYPE td_cal IS TABLE OF rd_cal;

   TYPE rd_viewcal IS RECORD (
      cal_date       VARCHAR2(8)
    , cal_day        VARCHAR2(10)
    , day_of_week    NUMBER(1)
    , acct_rule      VARCHAR2(15)
    , working_day    VARCHAR2(3)
    , first_day      VARCHAR2(3)
    , interim_day    VARCHAR2(3)
    , close_day      VARCHAR2(3)
    , year_close_day VARCHAR2(3)
    , phase3_day     VARCHAR2(3)
    , monthly_day    VARCHAR2(3)
    , phase2_day     VARCHAR2(3)
    , fiscal_year    NUMBER(4)
    , acct_period    NUMBER(4)
    , acct_close_dt  VARCHAR2(8)
   );

   TYPE td_viewcal IS TABLE OF rd_viewcal;

   TYPE rd_rule IS RECORD (
      cal_date       VARCHAR2(8)
    , cal_day        VARCHAR2(10)
    , day_of_week    NUMBER(1)
    , working_day    VARCHAR2(3)
    , sched_name     PS_BSCAL_RL_SCD_SG.sched_name_sg%TYPE
    , rule_name      PS_BSCAL_RL_SCD_SG.rule_name_sg%TYPE
    , message        VARCHAR2(254)
   );

   TYPE td_rules IS TABLE OF rd_rule;

   FUNCTION GetCalendar (
      pDate        IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pBusUnit     IN VARCHAR2 DEFAULT 'ALL'
    , pZone        IN VARCHAR2 DEFAULT 'ALL'
   ) RETURN td_viewcal PIPELINED;

   FUNCTION GetCalValues (
      pDate        IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pBusUnit     IN VARCHAR2 DEFAULT 'ALL'
    , pZone        IN VARCHAR2 DEFAULT 'ALL'
   ) RETURN td_cal PIPELINED;

   FUNCTION GetSchedule(
      pDate      IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pSchedName IN PS_BSCAL_RL_SCD_SG.sched_name_sg%TYPE DEFAULT 'NONE'
   ) RETURN td_rules PIPELINED;

   FUNCTION GetSchedValues (
      pDate      IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pSchedName IN PS_BSCAL_RL_SCD_SG.sched_name_sg%TYPE DEFAULT 'NONE'
   ) RETURN td_cal PIPELINED;

-- ## End Package Declaration #################################################
END Ps_Kbscal_Sg;
/
CREATE OR REPLACE PACKAGE BODY Ps_Kbscal_Sg AS
-- ## Start Package Body Declaration ##########################################

   -- ------------------------------------------------------------ CONSTANTS --

   -- *************************************************************************
   -- *************************************************************************
   PROCEDURE assert (
      pExpr        IN BOOLEAN
    , pErrMsg      IN VARCHAR2
   ) IS
   -- ------------------------------------------------------------ Variables --
   -- ---------------------------------------------------------------- Start --
   BEGIN
      IF pExpr OR pExpr IS NULL THEN
         RAISE_APPLICATION_ERROR(
            -20001, 'ERROR::AssertException:'||pErrMsg, TRUE
         );
      END IF;
   -- ------------------------------------------------------------ Exception --
   -- ------------------------------------------------------------------ End --
   END assert;

   -- *************************************************************************
   PROCEDURE assertDate(dt IN VARCHAR2, fmt IN VARCHAR2 DEFAULT 'YYYYMMDD') IS
   -- ------------------------------------------------------------ Variables --
      t_date       DATE;
   -- ---------------------------------------------------------------- Start --
   BEGIN
      assert( dt IS NULL, 'assertDate: no such date (dt) argument' );
      t_date := TO_DATE(dt, fmt);
   -- ------------------------------------------------------------ Exception --
   EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(
            -20001, 'ERROR::assertDate: date='||dt||', format='||fmt
                ||' [ERRM: '||SQLERRM||']', TRUE
         );
   -- ------------------------------------------------------------------ End --
   END assertDate;

   -- *************************************************************************
   -- *************************************************************************
   FUNCTION GetCalendar (
      pDate        IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pBusUnit     IN VARCHAR2 DEFAULT 'ALL'
    , pZone        IN VARCHAR2 DEFAULT 'ALL'
   ) RETURN td_viewcal PIPELINED IS
   -- ------------------------------------------------------------ Variables --
      lDate        DATE;
      rd_items     rd_viewcal;
   -- ---------------------------------------------------------------- Start --
   BEGIN

      /* ***** Control arguments ***** */
      assert(pBusUnit IS NULL, 'GetCalendar: No such parameter [pBusUnit]');
      assert(pZone IS NULL, 'GetCalendar: No such parameter [pZone]');

      FOR dl IN (
         WITH myCalendar AS (
            SELECT c.calendar_id, c.calendar_date
                 , TO_CHAR(c.calendar_date, 'DAY', 'NLS_DATE_LANGUAGE=AMERICAN') AS weekday
                 , TO_CHAR(c.calendar_date, 'd', 'NLS_DATE_LANGUAGE=AMERICAN') dayofweek
                 , bu.business_unit_grp, c.evt_rule_cd_sg
                 , c.fiscal_year, c.accounting_period
                 , CASE WHEN c.acc_period_type_sg IN ('SA', 'SM') THEN 'SU'
                        WHEN c.acc_period_type_sg IN ('XC') AND c.SOURCE = 'QTU' THEN 'XC'
                        ELSE c.acc_period_type_sg
                   END AS acc_period_type_sg
              FROM PS_ME_RF_BU_GRP_SG bu
                   JOIN PS_BDR_CALENDAR_SG  c
                     ON ( c.business_unit = bu.business_unit AND c.calendar_id = '01' )
             WHERE
                   NOT (c.acc_period_type_sg = 'XC' AND c.SOURCE != 'QTU')
               AND c.calendar_date BETWEEN TRUNC(TO_DATE(pDate, 'YYYYMMDD'), 'MM')
                                       AND LAST_DAY(TO_DATE(pDate, 'YYYYMMDD'))
               AND TO_DATE(pDate, 'YYYYMMDD') BETWEEN bu.dt_deb_efft_sg
                                       AND NVL(bu.dt_fin_efft_sg, TO_DATE(pDate, 'YYYYMMDD'))
               AND bu.business_unit_grp LIKE ( CASE WHEN pBusUnit = 'ALL'
                                                    THEN '%' ELSE pBusUnit END )
               AND bu.zone_sg LIKE ( CASE WHEN pZone = 'ALL'
                                          THEN '%' ELSE pZone END )
         )
         SELECT calendar_date, weekday, dayofweek
              , MAX(evt_rule_cd_sg) AS evt_rule_cd_sg
              , MAX(acc_period_type_sg) AS acc_period_type_sg
              , MIN(fiscal_year) KEEP (
                     DENSE_RANK FIRST
                     ORDER BY acc_period_type_sg DESC, fiscal_year
                ) AS fiscal_year
              , MIN(accounting_period) KEEP (
                     DENSE_RANK FIRST
                     ORDER BY acc_period_type_sg DESC, fiscal_year
                ) AS accounting_period
              , MIN(a.first_open_day) AS first_open_day
              , MIN(last_open_day) AS last_open_day
              , MIN(b.first_sup_day) AS first_sup_day
              , MIN(b.last_sup_day) AS last_sup_day
              , MIN(c.first_xc_day) AS first_xc_day
              , MIN(c.last_xc_day) AS last_xc_day
           FROM myCalendar
                JOIN (
                   SELECT MIN(calendar_date) AS first_open_day
                        , MAX(calendar_date) AS last_open_day
                     FROM myCalendar
                    WHERE acc_period_type_sg != ' '
                ) a ON ( 1 = 1 )
                LEFT OUTER JOIN (
                   SELECT MIN(calendar_date) AS first_sup_day
                        , MAX(calendar_date) AS last_sup_day
                     FROM myCalendar
                    WHERE acc_period_type_sg = 'SU'
                ) b ON ( 1 = 1 )
                LEFT OUTER JOIN (
                   SELECT MIN(calendar_date) AS first_xc_day
                        , MAX(calendar_date) AS last_xc_day
                     FROM myCalendar
                    WHERE acc_period_type_sg = 'XC'
                ) c ON ( 1 = 1 )
          GROUP BY calendar_date, weekday, dayofweek
          ORDER BY 1
      ) LOOP
         rd_items.cal_date      := TO_CHAR(dl.calendar_date, 'YYYYMMDD');
         rd_items.cal_day       := dl.weekday;
         rd_items.day_of_week   := dl.dayofweek;

         rd_items.working_day   := ( CASE WHEN dl.acc_period_type_sg != ' '
                                               THEN 'YES' ELSE  'NO' END );

         rd_items.first_day     := ( CASE WHEN rd_items.working_day = 'YES'
                                               AND dl.calendar_date = dl.first_open_day
                                          THEN 'YES' ELSE  'NO' END );

         rd_items.interim_day   := ( CASE WHEN rd_items.working_day = 'YES'
                                               AND dl.calendar_date
                                                   BETWEEN dl.first_open_day
                                                       AND NVL(dl.last_sup_day, dl.first_open_day)-1
                                          THEN 'YES' ELSE  'NO' END );

         rd_items.monthly_day   := ( CASE WHEN rd_items.working_day = 'YES'
                                               AND dl.calendar_date = dl.last_open_day
                                          THEN 'YES' ELSE  'NO' END );

         rd_items.close_day     := ( CASE WHEN rd_items.working_day = 'YES'
                                               AND dl.calendar_date = dl.last_sup_day
                                               AND dl.last_sup_day IS NOT NULL
                                          THEN 'YES' ELSE  'NO' END );

         rd_items.year_close_day := ( CASE WHEN rd_items.working_day = 'YES'
                                               AND dl.calendar_date = dl.last_sup_day
                                               AND dl.last_sup_day IS NOT NULL
                                               AND dl.accounting_period = 12
                                           THEN 'YES' ELSE  'NO' END );

         rd_items.phase3_day := ( CASE WHEN rd_items.working_day = 'YES'
                                            AND dl.acc_period_type_sg = 'XC'
                                       THEN 'YES' ELSE  'NO' END );

         rd_items.phase2_day := ( CASE WHEN rd_items.working_day = 'YES'
                                            AND ( rd_items.interim_day = 'YES'
                                                  OR  rd_items.close_day = 'YES' )
                                       THEN 'YES' ELSE  'NO' END );

         IF rd_items.working_day = 'YES' THEN
            rd_items.acct_rule     := dl.evt_rule_cd_sg;
            rd_items.acct_period   := dl.accounting_period;
            rd_items.fiscal_year   := dl.fiscal_year;

            IF dl.accounting_period BETWEEN 1 AND 9 THEN
               lDate := TO_DATE(dl.fiscal_year||'0'||dl.accounting_period||'01', 'YYYYMMDD');
            ELSE
               lDate := TO_DATE(dl.fiscal_year||dl.accounting_period||'01', 'YYYYMMDD');
            END IF;

            rd_items.acct_close_dt := TO_CHAR(LAST_DAY(lDate), 'YYYYMMDD');
         ELSE
            rd_items.acct_rule     := NULL;
            rd_items.acct_period   := NULL;
            rd_items.fiscal_year   := NULL;
            rd_items.acct_close_dt := NULL;
         END IF;

         PIPE ROW(rd_items);
      END LOOP;

   -- ------------------------------------------------------------ EXCEPTION --
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(
            -20999, 'ERROR::sqlException:GetCalendar: '||SQLERRM, TRUE
         );
   -- ------------------------------------------------------------------ END --
   END GetCalendar;

   -- *************************************************************************
   -- *************************************************************************
   FUNCTION GetCalValues (
      pDate        IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pBusUnit     IN VARCHAR2 DEFAULT 'ALL'
    , pZone        IN VARCHAR2 DEFAULT 'ALL'
   ) RETURN td_cal PIPELINED IS
   -- -------------------------------------------------------LOCAL VARIABLES --
      rd_items     rd_cal;
   -- ---------------------------------------------------------------- START --
   BEGIN

      FOR rd_items IN (
          SELECT CASE WHEN l_row = 1 THEN 'RESULT:CAL_DATE:'||cal_date
                      WHEN l_row = 2 THEN 'RESULT:CAL_DAY:'||cal_day
                      WHEN l_row = 3 THEN 'RESULT:DAY_OF_WEEK:'||day_of_week
                      WHEN l_row = 4 THEN 'RESULT:WORK_DAY:'||working_day
                      WHEN l_row = 5 THEN 'RESULT:FIRST_DAY:'||first_day
                      WHEN l_row = 6 THEN 'RESULT:INTERIM_DAY:'||interim_day
                      WHEN l_row = 7 THEN 'RESULT:CLOSE_DAY:'||close_day
                      WHEN l_row = 8 THEN 'RESULT:YEAR_CLOSE_DAY:'||year_close_day
                      WHEN l_row = 9 THEN 'RESULT:PHASE3_DAY:'||phase3_day
                      WHEN l_row = 10 THEN 'RESULT:MONTHLY_DAY:'||monthly_day
                      WHEN l_row = 11 THEN 'RESULT:PHASE2_DAY:'||phase2_day
                      WHEN l_row = 12 THEN 'RESULT:FISCAL_YEAR:'||fiscal_year
                      WHEN l_row = 13 THEN 'RESULT:ACCT_PERIOD:'||acct_period
                      WHEN l_row = 14 THEN 'RESULT:ACCT_CLOSE_DT:'||acct_close_dt
                 END
            FROM TABLE(GetCalendar(pDate, pBusUnit, pZone))
                 CROSS JOIN ( SELECT LEVEL AS l_row FROM DUAL CONNECT BY LEVEL <= 14 )
           WHERE cal_date = pDate
      ) LOOP
         PIPE ROW(rd_items);
      END LOOP;

   -- ------------------------------------------------------------ EXCEPTION --
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(
            -20999, 'ERROR::SQLException:GetCalValues: '||SQLERRM, TRUE
         );
   -- ------------------------------------------------------------------ END --
   END GetCalValues;

   -- *************************************************************************
   FUNCTION GetSchedule(
      pDate      IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pSchedName IN PS_BSCAL_RL_SCD_SG.sched_name_sg%TYPE DEFAULT 'NONE'
   ) RETURN td_rules PIPELINED IS
   -- ------------------------------------------------------------ Variables --
      t_exist     NUMBER(1) := 0;
      l_date      DATE;

      r_rule      rd_rule;
   -- ---------------------------------------------------------------- Start --
   BEGIN

      -- ***** Validate arguments *****
      assertDate(pDate);

      SELECT COUNT(*) INTO t_exist FROM PS_BSCAL_RL_SCD_SG
       WHERE sched_name_sg = pSchedName AND ROWNUM <= 1;

      assert( t_exist = 0, 'GetSchedule: No such schedule name: '||pSchedName);


      l_date := TRUNC(TO_DATE(pDate, 'YYYYMMDD'), 'MM');

      FOR c IN (
         WITH myDate AS (
            SELECT l_date + LEVEL -1 AS ref_date
                 , RTRIM(TO_CHAR(l_date + LEVEL -1, 'DAY', 'NLS_DATE_LANGUAGE=AMERICAN'), ' ') AS ref_day_name
                 , TO_CHAR(l_date + LEVEL -1, 'd', 'NLS_DATE_LANGUAGE=AMERICAN') AS ref_day_of_week
                 , EXTRACT(DAY FROM l_date + LEVEL -1) AS ref_day
                 , EXTRACT(MONTH FROM l_date + LEVEL -1) AS ref_month
                 , EXTRACT(YEAR FROM l_date + LEVEL -1) AS ref_year
              FROM DUAL
            CONNECT BY LEVEL <= LAST_DAY(l_date) - TRUNC(l_date, 'MM') + 1
            ORDER BY 1
         )
         SELECT TO_CHAR(dt.ref_date, 'YYYYMMDD') AS ref_date
              , dt.ref_day_name, dt.ref_day_of_week
              , sch.sched_name_sg AS sched_name
              , sch.rule_name_sg AS rule_name
              , ctr.rule_day_open_sg AS rule_day_open
              , ctd.rule_day_open_sg AS date_day_open
              , rul.rule_day_open AS week_day_open
           FROM PS_BSCAL_RL_SCD_SG sch
                JOIN myDate dt ON (1 = 1)
           LEFT OUTER JOIN PS_BSCAL_RULE_WEEK_VW_SG rul
             ON ( rul.rule_name_sg = sch.rule_name_sg
                  AND rul.day_name = dt.ref_day_name
                  AND rul.rule_status_sg = 'A' )
           LEFT OUTER JOIN PS_BSCAL_RL_EXC_SG ctr
             ON ( ctr.rule_day_sg = dt.ref_day
                  AND ctr.rule_month_sg = dt.ref_month
                  AND ctr.rule_name_sg = sch.rule_name_sg
                  AND ctr.day_type_sg = 'R')
           LEFT OUTER JOIN PS_BSCAL_RL_EXC_SG ctd
             ON ( ctd.rule_day_sg = dt.ref_day
                  AND ctd.rule_month_sg = dt.ref_month
                  AND ctd.rule_year_sg = dt.ref_year
                  AND sch.rule_name_sg = ctd.rule_name_sg
                  AND ctd.day_type_sg = 'D')
          WHERE 1 = 1
            AND sch.sched_name_sg = pSchedName
            AND sch.sched_status_sg = 'A'
         ORDER BY 1
      ) LOOP

         r_rule.cal_date    := c.ref_date ;
         r_rule.cal_day     := c.ref_day_name ;
         r_rule.day_of_week := c.ref_day_of_week ;
         r_rule.sched_name  := c.sched_name ;
         r_rule.rule_name   := c.rule_name ;

         r_rule.working_day    := 'NO' ;

         IF c.date_day_open = 'Y' THEN
            r_rule.working_day := 'YES';
            r_rule.message  := 'Exception date: day open';
         ELSIF c.date_day_open = 'N' THEN
            r_rule.working_day := 'NO';
            r_rule.message  := 'Exception date: day closed';
         ELSIF c.rule_day_open = 'N' THEN
            r_rule.working_day := 'NO';
            r_rule.message  := 'Exception rule: day closed';
         ELSIF c.rule_day_open = 'Y' THEN
            r_rule.working_day := 'YES';
            r_rule.message  := 'Exception rule: day open';
         ELSIF c.week_day_open = 'Y' THEN
            r_rule.working_day := 'YES';
            r_rule.message  := 'Week day open';
         ELSE
            r_rule.working_day := 'NO';
            r_rule.message  := 'Week day closed.';
         END IF;

         PIPE ROW(r_rule);

      END LOOP;

   -- ------------------------------------------------------------ Exception --
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(
            -20999, 'ERROR::sqlException:GetSchedule: '||SQLERRM, TRUE
         );
   -- ------------------------------------------------------------------ End --
   END GetSchedule;

   -- *************************************************************************
   FUNCTION GetSchedValues (
      pDate      IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYYMMDD')
    , pSchedName IN PS_BSCAL_RL_SCD_SG.sched_name_sg%TYPE DEFAULT 'NONE'
   ) RETURN td_cal PIPELINED IS
   -- ------------------------------------------------------------ Variables --
      rd_items     rd_cal;
   -- ---------------------------------------------------------------- Start --
   BEGIN

      FOR rd_items IN (
         SELECT CASE WHEN l_row = 1 THEN 'RESULT:CAL_DATE:'||cal_date
                     WHEN l_row = 2 THEN 'RESULT:CAL_DAY:'||cal_day
                     WHEN l_row = 3 THEN 'RESULT:DAY_OF_WEEK:'||day_of_week
                     WHEN l_row = 4 THEN 'RESULT:WORK_DAY:'||working_day
                END
           FROM TABLE(GetSchedule(pDate, pSchedName))
                CROSS JOIN ( SELECT LEVEL AS l_row FROM DUAL CONNECT BY LEVEL <= 4 )
          WHERE cal_date = pDate
      ) LOOP
         PIPE ROW(rd_items);
      END LOOP;

   -- ------------------------------------------------------------ Exception --
   EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(
            -20999, 'ERROR::sqlException:GetScheduleValues: '||SQLERRM, TRUE
         );
   -- ------------------------------------------------------------------ End --
   END GetSchedValues;

-- ## END Package Body Declaration ############################################
END Ps_Kbscal_Sg;
/
