CREATE OR REPLACE PACKAGE Ps_Kdaas_Sg AS

   TYPE jrnl_vw_typ IS TABLE OF PS_JRNL_VW_SG%ROWTYPE;
    
   FUNCTION GET_JRNL_BY_POSTDATE ( 
      bus_unit   IN VARCHAR2
    , src     IN VARCHAR2
    , as_of_date IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE-1, 'YYYYMMDD')
   )
  RETURN jrnl_vw_typ PIPELINED;

END Ps_Kdaas_Sg;
/
CREATE OR REPLACE PACKAGE BODY Ps_Kdaas_Sg AS

   FUNCTION GET_JRNL_BY_POSTDATE ( 
      bus_unit   IN VARCHAR2
    , src        IN VARCHAR2
    , as_of_date IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE-1, 'YYYYMMDD')
   )
   RETURN jrnl_vw_typ PIPELINED IS
   -- ------------------------------------------------------------ Variables --
      post_date  DATE;
      min_jrnl_date DATE;
      max_jrnl_date DATE;
   BEGIN
      
      post_date := TO_DATE(as_of_date, 'YYYYMMDD');
      
      SELECT MIN(journal_date) AS MIN_JRNL_DT, MAX(journal_date) AS MAX_JRNL_DT
         INTO  min_jrnl_date, max_jrnl_date
              FROM PS_JRNL_HEADER 
             WHERE posted_date = post_date
               AND fiscal_year = EXTRACT(YEAR FROM post_date)
               AND accounting_period BETWEEN EXTRACT(MONTH FROM ADD_MONTHS(post_date, -1)) 
                                         AND EXTRACT(MONTH FROM post_date) 
               AND business_unit = bus_unit
               AND SOURCE = src;
      
      
      FOR res IN (
         SELECT PS_JRNL_VW_SG.* 
           FROM PS_JRNL_VW_SG
          WHERE business_unit = bus_unit
            AND SOURCE = src
            AND posted_date = post_date 
            AND journal_date BETWEEN min_jrnl_date AND max_jrnl_date 
      ) LOOP
         PIPE ROW(res); 
      END LOOP;

   END GET_JRNL_BY_POSTDATE;

END Ps_Kdaas_Sg;
/


create public synonym Ps_Kdaas_Sg for Ps_Kdaas_Sg
/
 
