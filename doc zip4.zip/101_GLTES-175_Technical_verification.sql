INSERT INTO PS_MEE_CHECK_SG
            (release_id_sg, co_num_sg, exec_time, status, descr_control,
             context_sg, results)
   SELECT '201606A', 'GLTES-175' AS co_num, SYSTIMESTAMP, 'A',
          'GLTES-175 - [Dolce US] Sending SGAS Monthly Pivot balances extract to GOLD'
                                                                     AS descr,
          'PS_PVT_RUN_FTB_SG' AS tablename,
          (CASE
              WHEN COUNT (*) = 2
                 THEN 'OK'
              ELSE 'KO'
           END) remarks
     FROM PS_PVT_RUN_FTB_SG
    WHERE oprid = 'BATCHBETAA'
      AND run_cntl_id = 'SG_PVT_S8308_MONTHLY_BAL'
      AND report_name IN
                  ('S8308_BAL_FRI_M_ACTUALS_NY', 'S8308_BAL_LOC_M_ACTLOC_NY')
      AND ftp_folder_sg = 'GLD';
