/* GLTES-255_VDE */

SELECT CASE
          WHEN COUNT (*) > 0
             THEN 'YES'
          ELSE 'NO'
       END, COUNT (*)
  FROM PS_PRCSDEFN
 WHERE PARMLISTTYPE = '3' AND PARMLIST like '%TRACE%';
 
 SELECT PRCSTYPE, PRCSNAME, PARMLIST, PARMLISTTYPE FROM PS_PRCSDEFN 
WHERE PARMLISTTYPE = '3' AND PARMLIST LIKE '%TRACE%';

select * from ps_PRCSDEFN where PARMLISTTYPE <> '0';

/* det */
select * from ps_PRCSDEFN 
where PRCSTYPE = 'Application Engine'
and PARMLISTTYPE = '3'
AND PARMLIST LIKE '%TRACE%'
union all
select * from ps_PRCSDEFN 
where PRCSTYPE like 'SQR%'
and PARMLISTTYPE = '3'
AND PARMLIST LIKE '%debug%'
union all 
select * from ps_PRCSDEFN 
where PRCSTYPE like 'COBOL%'
and PARMLISTTYPE = '1';

SELECT PRCSTYPE,
  PRCSNAME,
  PARMLIST,
  PARMLISTTYPE
FROM ps_PRCSDEFN
WHERE (PRCSTYPE  = 'Application Engine'
AND PARMLISTTYPE = '3'
AND PARMLIST LIKE '%TRACE%')
OR ( PRCSTYPE LIKE 'SQR%'
AND PARMLISTTYPE = '3'
AND PARMLIST LIKE '%debug%')
OR ( PRCSTYPE LIKE 'COBOL%'
AND PARMLISTTYPE = '1');
/* fin det*/


/* chk */
SELECT CASE
          WHEN COUNT (*) > 0
             THEN 'YES'
          ELSE 'NO'
       END, COUNT (*)
  FROM PS_PRCSDEFN
 WHERE PRCSTYPE = 'Application Engine'
and PARMLISTTYPE = '3'
AND PARMLIST LIKE '%TRACE%'
union all
SELECT CASE
          WHEN COUNT (*) > 0
             THEN 'YES'
          ELSE 'NO'
       END, COUNT (*)
from ps_PRCSDEFN 
where PRCSTYPE like 'SQR%'
and PARMLISTTYPE = '3'
AND PARMLIST LIKE '%debug%'
union all 
SELECT CASE
          WHEN COUNT (*) > 0
             THEN 'YES'
          ELSE 'NO'
       END, COUNT (*)
from ps_PRCSDEFN 
where PRCSTYPE like 'COBOL%'
and PARMLISTTYPE = '1';


SELECT
  CASE
    WHEN COUNT (*) > 0
    THEN 'YES'
    ELSE 'NO'
  END,
  COUNT (*)
FROM PS_PRCSDEFN
WHERE (PRCSTYPE  = 'Application Engine'
AND PARMLISTTYPE = '3'
AND PARMLIST LIKE '%TRACE%')
OR ( PRCSTYPE LIKE 'SQR%'
AND PARMLISTTYPE = '3'
AND PARMLIST LIKE '%debug%')
OR (PRCSTYPE LIKE 'COBOL%'
AND PARMLISTTYPE = '1');
/* fin chk */




SELECT PRCSTYPE, PRCSNAME, PARMLIST, PARMLISTTYPE FROM PS_PRCSDEFN 
WHERE PARMLISTTYPE = '3' AND PARMLIST LIKE '%TRACE%';



/* en prd AE074_SG IT006_SG IT017_SG ont tourn� cette ann�e */
select * from psprcsrqst where PRCSNAME in ('AE013B_SG','AE074_SG','AE094_SG','IT006_SG','IT017_SG')
order by rundttm desc;

select distinct prcstype , max(rundttm) from psprcsrqst
group by PRCSTYPE;

select * from psprcsrqst
where PRCSTYPE like '%PSJob%'
order by rundttm desc;

select * from ps_PRCSDEFN 
where PRCSTYPE like '%PSJob%'
and PRCSNAME in ('JRNL_ME','RAN_FULL');
