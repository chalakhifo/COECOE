--E2K - Setup BU--;

SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_RT_REV_TYPE_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_RT_REV_TYPE_SG where BUSINESS_UNIT='G4670' AND BDR_TEMPO_SG = 'ADJ';

--Change the AE071_SG run control-E2K INIT SETUP--;

SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_RUN_AE071_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_RUN_AE071_SG WHERE OPRID = 'BATCHG4670' AND RUN_CNTL_ID = 'G4670_SELLDOWN';

SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_RUN_AE071STP_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_RUN_AE071STP_SG WHERE OPRID = 'BATCHG4670' AND RUN_CNTL_ID = 'G4670_SELLDOWN';

--Creation of dedicated Rate Types;

SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_RT_TYPE_TBL' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_RT_TYPE_TBL WHERE RT_TYPE = 'DTCES';

--Insert a line in PS_BUS_UNIT_IDS_GL;

SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_BUS_UNIT_IDS_GL' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_BUS_UNIT_IDS_GL WHERE BUSINESs_UNIT = 'G4670' AND STD_ID_NUM_QUAL = 'RTC';

--Creation of the Sell Down configuration--collector mapping--;

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_CES_DEPT_BU_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from PS_CES_DEPT_BU_SG where business_unit = 'G4670';

--Creation of the AE091_SG run control--load amount sell down--;

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_RUN_CESS_LED_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from PS_RUN_CESS_LED_SG WHERE BUSINESs_UNIT  = 'G4670' AND RUN_CNTL_ID = 'SG_SELLDOWN_LOAD'; 

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' as DESCR,'PS_LED_AE091_SG' as TABLENAME, (case when COUNT(*) = 2  then 'OK' else 'PROBLEM' end) REMARKS from PS_LED_AE091_SG where OPRID  = 'BATCHG4670' and RUN_CNTL_ID = 'SG_SELLDOWN_LOAD';

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' as DESCR,'PS_PRCSRUNCNTL' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_PRCSRUNCNTL where OPRID='BATCHG4670' and RUN_CNTL_ID = 'SG_SELLDOWN_LOAD';

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' as DESCR,'PSPRCSRUNCNTLS' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PSPRCSRUNCNTLS where OPRID='BATCHG4670' and  RUNCNTLID = 'SG_SELLDOWN_LOAD';

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' as DESCR,'PS_PRCSRUNCNTLDTL' as TABLENAME, (case when COUNT(*) = 1  then 'OK' else 'PROBLEM' end) REMARKS from PS_PRCSRUNCNTLDTL where  OPRID='BATCHG4670' and RUNCNTLID = 'SG_SELLDOWN_LOAD';

--Update of the Ticket generation run control;

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_RUN_CESSION_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from PS_RUN_CESSION_SG where BUSINESS_UNIT  = 'G4670';

--Security;

SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_CESSION_SECU_SG' AS tablename, (CASE WHEN COUNT(*) = 4  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_CESSION_SECU_SG WHERE DEPTID = 'FCES2';

--Check the ANS (TFA) process--REQUEST ALLOCATION--;
--no changes
--Check if the allocation steps are properly set up;
select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_JRNL_EDIT_REQ' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks from PS_JRNL_EDIT_REQ where OPRID = 'BATCHG4670' and RUN_CNTL_ID = 'SG_REV_ANS_EDIT' AND PROCESS_FREQUENCY = 'A';

--Check if the SellDown Products are properly set up;
--NOCHANGES--;

--Batch stream $U;
--NOCHANGES--;

--Email sending set up;

select 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_SPHX_TICK_BU_SG' AS tablename, (CASE WHEN COUNT(*) = 6  THEN 'OK' ELSE 'PROBLEM' END) Remarks from PS_SPHX_TICK_BU_SG WHERE BUSINESS_UNIT = 'G4670';
SELECT 'GLTES-89' as JIRA_ID,'[Descartes Lot 2] Add the selldown process' AS Descr,'PS_SPHX_TICKET_SG' AS tablename, (CASE WHEN COUNT(*) = 1  THEN 'OK' ELSE 'PROBLEM' END) Remarks FROM PS_SPHX_TICKET_SG WHERE BUSINESS_UNIT = 'G4670';

