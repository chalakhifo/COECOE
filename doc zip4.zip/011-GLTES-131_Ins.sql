TRUNCATE TABLE PS_JL_FLDS_LOG_SG
/
--lines to be inserted into  PS_JL_FLDS_LOG_SG with a value post_utc_dttm_sg not null
INSERT /*+ append   */ INTO PS_JL_FLDS_LOG_SG
            (business_unit, journal_id, journal_date, unpost_seq, num_rows,
             in_seconds, oprid, post_utc_dttm_sg, unpost_utc_dttm_sg)
   SELECT /*+ full(PS_JRNL_HEADER) parallel(PS_JRNL_HEADER,8) */ business_unit, journal_id, journal_date, unpost_seq,
          jrnl_total_lines, '0', oprid, CAST (dttm_stamp_sec AS TIMESTAMP) AT TIME ZONE 'UTC', NULL
     FROM PS_JRNL_HEADER
    WHERE jrnl_hdr_status = 'P'
/
Commit
/
--lines to be inserted into  PS_JL_FLDS_LOG_SG with a value unpost_utc_dttm_sg not null
INSERT /*+ append   */ INTO PS_JL_FLDS_LOG_SG
            (business_unit, journal_id, journal_date, unpost_seq, num_rows,
             in_seconds, oprid, post_utc_dttm_sg, unpost_utc_dttm_sg)
   SELECT /*+ full(PS_JRNL_HEADER) parallel(PS_JRNL_HEADER,8) */ business_unit, journal_id, journal_date, unpost_seq,
          jrnl_total_lines, '0', oprid, NULL, CAST (dttm_stamp_sec AS TIMESTAMP) AT TIME ZONE 'UTC'
     FROM PS_JRNL_HEADER
    WHERE jrnl_hdr_status = 'U'
/
Commit
/