SELECT  * from PS_SOURCE_TBL WHERE setid = 'SHARE' and source  ='IPM';
